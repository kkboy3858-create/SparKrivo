import { useState, useRef } from 'react'
import { posts as initialPosts, currentUser, storyUsers as initialStoryUsers, getRichProfile, type Post, type StoryUser, type StorySlide } from '../data/mockData'
import { StoryRing } from '../stories/StoryRing'
import StoryViewer from '../stories/StoryViewer'
import StoryCreator from '../stories/StoryCreator'
import NewPostModal from '../components/NewPostModal'
import UserProfileView, { type ViewableUser } from '../components/UserProfileView'

interface Props {
  onSearchOpen?: () => void
  onNotifOpen?: () => void
  notifCount?: number
}

export default function FeedPage({ onSearchOpen, onNotifOpen, notifCount = 0 }: Props) {
  /* ── Post state ─────────────────────────────── */
  const [posts, setPosts] = useState<Post[]>(initialPosts)
  const [showNewPost, setShowNewPost] = useState(false)
  const [activeComments, setActiveComments] = useState<string | null>(null)
  const [viewingProfile, setViewingProfile] = useState<ViewableUser | null>(null)
  const [commentInput, setCommentInput] = useState('')

  /* ── Story state ────────────────────────────── */
  const [storyUsers, setStoryUsers] = useState<StoryUser[]>(initialStoryUsers)
  const [viewerOpen, setViewerOpen] = useState(false)
  const [viewerStart, setViewerStart] = useState(0)
  const [creatorOpen, setCreatorOpen] = useState(false)

  /* ── Open a story ───────────────────────────── */
  const openStory = (idx: number) => {
    const user = storyUsers[idx]
    // If own story with no slides → open creator
    if (user.isOwn && user.slides.length === 0) {
      setCreatorOpen(true)
      return
    }
    setViewerStart(idx)
    setViewerOpen(true)
  }

  /* ── Mark story as seen ─────────────────────── */
  const handleUserSeen = (userId: string) => {
    setStoryUsers(prev => prev.map(u => u.id === userId ? { ...u, seen: true } : u))
  }

  /* ── Publish new story slide ────────────────── */
  const handlePublishStory = (slide: StorySlide) => {
    setStoryUsers(prev => prev.map(u =>
      u.isOwn ? { ...u, slides: [...u.slides, slide], seen: false } : u
    ))
    setCreatorOpen(false)
    // Immediately open the viewer on own story
    setTimeout(() => { setViewerStart(0); setViewerOpen(true) }, 150)
  }

  /* ── Posts helpers ──────────────────────────── */
  const toggleLike = (postId: string) => {
    setPosts(prev => prev.map(p =>
      p.id === postId ? { ...p, liked: !p.liked, likes: p.liked ? p.likes - 1 : p.likes + 1 } : p
    ))
  }

  const addComment = (postId: string) => {
    if (!commentInput.trim()) return
    setPosts(prev => prev.map(p => {
      if (p.id !== postId) return p
      return {
        ...p,
        comments: p.comments + 1,
        commentList: [...(p.commentList || []), {
          id: Date.now().toString(),
          userId: 'me',
          userName: 'You',
          userAvatar: currentUser.avatar,
          text: commentInput.trim(),
          timeAgo: 'just now',
        }],
      }
    }))
    setCommentInput('')
  }

  const handlePublishPost = (post: Post) => {
    setPosts(prev => [post, ...prev])
    setShowNewPost(false)
  }

  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ background: 'var(--feed-bg)' }}>
      {/* ── Header ── */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-b" style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        <div className="flex items-center gap-2">
          <svg width="22" height="20" viewBox="0 0 24 22" fill="#ff4d6d">
            <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
          </svg>
          <span className="text-[22px] font-bold text-[#ff4d6d]">Spark</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={onSearchOpen} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform text-gray-500">
            <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
          </button>
          <button onClick={onNotifOpen} className="relative w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform text-gray-500">
            <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
            </svg>
            {notifCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-[#ff4d6d] text-white text-[9px] font-bold rounded-full min-w-[16px] h-4 flex items-center justify-center px-0.5 badge-pop">
                {notifCount > 99 ? '99+' : notifCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* ── Scrollable body ── */}
      <div className="flex-1 overflow-y-auto">

        {/* ── Stories row ── */}
        <div className="mb-1" style={{ borderBottom: '1px solid var(--color-border)', background: 'var(--color-surface)' }}>
          <div className="px-3 pt-3 pb-2 flex gap-3 overflow-x-auto scrollbar-none">
            {storyUsers.map((user, idx) => (
              <StoryRing
                key={user.id}
                user={user}
                onClick={() => openStory(idx)}
              />
            ))}
          </div>

          {/* New post button */}
          <div className="flex justify-end px-4 pb-2.5">
            <button
              onClick={() => setShowNewPost(true)}
              className="flex items-center gap-2 px-5 py-2 rounded-full text-white text-sm font-semibold shadow-md active:scale-95 transition-transform"
              style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
              </svg>
              New post
            </button>
          </div>
        </div>

        {/* ── Posts ── */}
        <div className="pb-4">
          {posts.map(post => (
            <PostCard
              key={post.id}
              post={post}
              onLike={toggleLike}
              activeComments={activeComments}
              setActiveComments={setActiveComments}
              commentInput={commentInput}
              setCommentInput={setCommentInput}
              onAddComment={addComment}
              onViewProfile={() => {
                const rich = getRichProfile(post.userName, { id: post.userId, name: post.userName, avatar: post.userAvatar, isVip: post.isVip })
                setViewingProfile(rich ?? { id: post.userId, name: post.userName, avatar: post.userAvatar, isVip: post.isVip })
              }}
            />
          ))}
        </div>
      </div>

      {/* ── New Post modal ── */}
      {showNewPost && (
        <NewPostModal
          onPublish={handlePublishPost}
          onClose={() => setShowNewPost(false)}
        />
      )}

      {/* ── Story Viewer ── */}
      {viewerOpen && (
        <StoryViewer
          users={storyUsers}
          startIndex={viewerStart}
          onClose={() => setViewerOpen(false)}
          onUserSeen={handleUserSeen}
        />
      )}

      {/* ── Story Creator ── */}
      {creatorOpen && (
        <StoryCreator
          onPublish={handlePublishStory}
          onClose={() => setCreatorOpen(false)}
        />
      )}

      {/* ── User Profile Viewer ── */}
      {viewingProfile && (
        <UserProfileView
          user={viewingProfile}
          onClose={() => setViewingProfile(null)}
        />
      )}
    </div>
  )
}

/* ── VideoPost — inline feed video player ─────────────────────────────────── */
function VideoPost({ src }: { src: string }) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [playing, setPlaying] = useState(false)
  const [muted, setMuted] = useState(true)

  const toggle = () => {
    if (!videoRef.current) return
    if (playing) {
      videoRef.current.pause()
    } else {
      videoRef.current.play().catch(() => {})
    }
  }

  return (
    <div className="relative w-full h-full bg-black cursor-pointer" onClick={toggle}>
      <video
        ref={videoRef}
        src={src}
        className="w-full h-full object-contain"
        playsInline
        muted={muted}
        loop
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
      />

      {/* Play/pause overlay */}
      {!playing && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-black/50 backdrop-blur flex items-center justify-center shadow-xl">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="white" style={{ marginLeft: 3 }}>
              <polygon points="5 3 19 12 5 21 5 3"/>
            </svg>
          </div>
        </div>
      )}

      {/* Controls row bottom-right */}
      <div className="absolute bottom-3 right-3 flex items-center gap-2">
        {/* Mute toggle */}
        <button
          onClick={e => { e.stopPropagation(); setMuted(m => !m); if (videoRef.current) videoRef.current.muted = !muted }}
          className="w-8 h-8 rounded-full bg-black/50 backdrop-blur flex items-center justify-center active:scale-90 transition-transform"
        >
          {muted ? (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
              <line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>
            </svg>
          ) : (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
              <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>
            </svg>
          )}
        </button>

        {/* 🎬 video badge */}
        <div className="flex items-center gap-1 px-2 py-1 bg-black/50 backdrop-blur rounded-full">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
          </svg>
          <span className="text-white text-[10px] font-bold">Video</span>
        </div>
      </div>
    </div>
  )
}
/* ── PostCard subcomponent ──────────────────────────────────── */
interface PostCardProps {
  post: Post
  onLike: (id: string) => void
  activeComments: string | null
  setActiveComments: (id: string | null) => void
  commentInput: string
  setCommentInput: (v: string) => void
  onAddComment: (id: string) => void
  onViewProfile: () => void
}

function PostCard({ post, onLike, activeComments, setActiveComments, commentInput, setCommentInput, onAddComment, onViewProfile }: PostCardProps) {
  return (
    <div
      className="mx-3 my-2 rounded-2xl overflow-hidden"
      style={{
        background: 'var(--color-surface)',
        boxShadow: '0 2px 12px rgba(255,77,109,0.07), 0 1px 3px rgba(0,0,0,0.05)',
        border: '1px solid var(--color-border)',
      }}
    >
      {/* Header — tap avatar or name to view profile */}
      <div className="flex items-center gap-3 px-4 py-3">
        <button
          onClick={onViewProfile}
          className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 active:scale-90 transition-transform ring-2 ring-transparent hover:ring-[#ff4d6d]/30"
        >
          <img src={post.userAvatar} alt={post.userName} className="w-full h-full object-cover" />
        </button>
        <button onClick={onViewProfile} className="flex-1 text-left active:opacity-70 transition-opacity">
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-sm text-gray-900">{post.userName}</span>
            {post.isVip && (
              <span className="px-1.5 py-0.5 bg-amber-100 text-amber-700 text-[9px] font-bold rounded-full">👑 VIP</span>
            )}
          </div>
          <span className="text-xs text-gray-400">{post.timeAgo}</span>
        </button>
        <button className="text-gray-400 w-8 h-8 flex items-center justify-center">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/>
          </svg>
        </button>
      </div>

      {/* Media — image or video */}
      {(post.image || post.video) && (
        <div className="w-full bg-black overflow-hidden" style={{ aspectRatio: '4/5', maxHeight: 520 }}>
          {post.video ? (
            <VideoPost src={post.video} />
          ) : (
            <img src={post.image} alt="" className="w-full h-full object-cover" />
          )}
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-4 px-4 py-3">
        <button onClick={() => onLike(post.id)} className="flex items-center gap-1.5 active:scale-90 transition-transform">
          <svg width="24" height="22" viewBox="0 0 24 22" fill={post.liked ? '#ff4d6d' : 'none'} stroke={post.liked ? '#ff4d6d' : '#374151'} strokeWidth="1.8">
            <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
          </svg>
          <span className={`text-sm font-semibold ${post.liked ? 'text-[#ff4d6d]' : 'text-gray-700'}`}>{post.likes}</span>
        </button>
        <button onClick={() => setActiveComments(activeComments === post.id ? null : post.id)} className="flex items-center gap-1.5">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <span className="text-sm font-semibold text-gray-700">{post.comments}</span>
        </button>
        <div className="flex-1" />
        <button className="text-gray-400">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
            <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
          </svg>
        </button>
      </div>

      {/* Caption */}
      <div className="px-4 pb-2">
        <span className="font-bold text-sm text-gray-900">{post.userName} </span>
        <span className="text-sm text-gray-700">{post.caption}</span>
      </div>

      {/* Comments */}
      {activeComments === post.id && (
        <div className="px-4 pb-3 space-y-2">
          {(post.commentList || []).map(c => (
            <div key={c.id} className="flex items-start gap-2">
              <img src={c.userAvatar} alt="" className="w-7 h-7 rounded-full object-cover flex-shrink-0" />
              <div className="flex-1 bg-gray-50 rounded-2xl px-3 py-2">
                <span className="font-semibold text-xs text-gray-900">{c.userName} </span>
                <span className="text-xs text-gray-700">{c.text}</span>
              </div>
            </div>
          ))}
          <div className="flex items-center gap-2 mt-2">
            <img src={currentUser.avatar} alt="" className="w-7 h-7 rounded-full object-cover flex-shrink-0" />
            <div className="flex-1 flex items-center bg-gray-100 rounded-full px-3 py-1.5 gap-2">
              <input
                value={commentInput}
                onChange={e => setCommentInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && onAddComment(post.id)}
                placeholder="Add a comment..."
                className="flex-1 bg-transparent text-xs outline-none text-gray-700 placeholder-gray-400"
              />
              <button onClick={() => onAddComment(post.id)} className="text-[#ff4d6d]">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}
      <div className="h-2" />
    </div>
  )
}
