import { useState, useMemo, useRef, useEffect } from 'react'
import { discoverProfiles, getRichProfile, type Profile } from '../data/mockData'
import { usePrivacy } from '../privacy/PrivacyContext'
import { UserOptionsSheet, ReportFlow, BlockConfirmSheet } from '../privacy/PrivacySettings'
import UserProfileView from '../components/UserProfileView'

/* ─────────────────────────────────────────────────────────────────
   TYPES
───────────────────────────────────────────────────────────────── */
type MenuState = 'none' | 'options' | 'report' | 'block' | 'profile'

interface Filters {
  minAge: number
  maxAge: number
  maxDistance: number       // km
  genders: string[]
  interests: string[]
  onlineOnly: boolean
  vipOnly: boolean
}

const DEFAULT_FILTERS: Filters = {
  minAge: 18,
  maxAge: 45,
  maxDistance: 50,
  genders: [],
  interests: [],
  onlineOnly: false,
  vipOnly: false,
}

const ALL_INTERESTS = [
  'Travel', 'Music', 'Fitness', 'Art', 'Reading',
  'Gaming', 'Cooking', 'Dancing', 'Hiking', 'Photography',
  'Sports', 'Movies', 'Fashion', 'Food',
]
const ALL_GENDERS = ['Male', 'Female', 'Non-binary']

// parse "2 km away" → 2
function kmFromDistance(d: string) {
  return parseInt(d) || 999
}

/* ─────────────────────────────────────────────────────────────────
   SEARCH OVERLAY
───────────────────────────────────────────────────────────────── */
interface SearchOverlayProps {
  profiles: Profile[]
  onClose: () => void
  onSelect: (p: Profile) => void
}

function SearchOverlay({ profiles, onClose, onSelect }: SearchOverlayProps) {
  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => { setTimeout(() => inputRef.current?.focus(), 80) }, [])

  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return profiles.slice(0, 8)
    return profiles.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.location.toLowerCase().includes(q) ||
      p.interests.some(i => i.toLowerCase().includes(q)) ||
      String(p.age).includes(q)
    )
  }, [query, profiles])

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-white animate-slide-in-right">
      {/* Search bar */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-3 border-b border-gray-100">
        <button
          onClick={onClose}
          className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform flex-shrink-0"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>

        <div className="flex-1 flex items-center bg-gray-100 rounded-2xl px-4 py-2.5 gap-2">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search by name, location, interest…"
            className="flex-1 bg-transparent text-sm outline-none text-gray-800 placeholder-gray-400"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-gray-400 active:scale-90 transition-transform">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* Hint label */}
      <div className="px-4 pt-3 pb-1">
        <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
          {query ? `${results.length} result${results.length !== 1 ? 's' : ''}` : 'Suggested'}
        </p>
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
        {results.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center px-8">
            <div className="text-5xl mb-4">🔍</div>
            <p className="font-bold text-gray-800 mb-1">No results for "{query}"</p>
            <p className="text-sm text-gray-400">Try a name, city or interest</p>
          </div>
        ) : (
          results.map(p => (
            <button
              key={p.id}
              onClick={() => { onSelect(p); onClose() }}
              className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-rose-50/40 active:bg-rose-50 transition-colors text-left"
            >
              <div className="relative flex-shrink-0">
                <img src={p.avatar} alt={p.name} className="w-14 h-14 rounded-2xl object-cover shadow-sm" />
                {p.isVip && (
                  <div className="absolute -top-1 -right-1 w-5 h-5 bg-amber-400 rounded-full flex items-center justify-center text-[10px] border-2 border-white">
                    👑
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="font-bold text-gray-900 text-sm">{p.name}</span>
                  <span className="text-gray-400 text-sm">·</span>
                  <span className="text-gray-500 text-sm">{p.age}</span>
                </div>
                <p className="text-xs text-gray-400 truncate">📍 {p.location} · {p.distance}</p>
                {p.interests.length > 0 && (
                  <div className="flex gap-1 mt-1 flex-wrap">
                    {p.interests.slice(0, 3).map(i => (
                      <span key={i} className="px-2 py-0.5 bg-rose-50 text-[#ff4d6d] text-[10px] font-medium rounded-full">{i}</span>
                    ))}
                  </div>
                )}
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          ))
        )}
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   FILTER PANEL
───────────────────────────────────────────────────────────────── */
interface FilterPanelProps {
  filters: Filters
  activeCount: number
  onApply: (f: Filters) => void
  onClose: () => void
}

function FilterPanel({ filters, activeCount, onApply, onClose }: FilterPanelProps) {
  const [draft, setDraft] = useState<Filters>({ ...filters })

  const up = <K extends keyof Filters>(k: K, v: Filters[K]) =>
    setDraft(prev => ({ ...prev, [k]: v }))

  const toggleArr = (key: 'genders' | 'interests', val: string) =>
    setDraft(prev => {
      const arr = prev[key] as string[]
      return { ...prev, [key]: arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val] }
    })

  const reset = () => setDraft({ ...DEFAULT_FILTERS })

  const changed =
    draft.minAge !== DEFAULT_FILTERS.minAge ||
    draft.maxAge !== DEFAULT_FILTERS.maxAge ||
    draft.maxDistance !== DEFAULT_FILTERS.maxDistance ||
    draft.genders.length > 0 ||
    draft.interests.length > 0 ||
    draft.onlineOnly ||
    draft.vipOnly

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-white animate-slide-up">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3.5 border-b border-gray-100">
        <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform text-gray-500">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>

        <div className="text-center">
          <h2 className="font-bold text-gray-900 text-base">Filter Profiles</h2>
          {changed && (
            <p className="text-[11px] text-[#ff4d6d] font-semibold">{activeCount} filter{activeCount !== 1 ? 's' : ''} active</p>
          )}
        </div>

        <button
          onClick={reset}
          className="text-sm font-semibold text-gray-400 hover:text-gray-600 transition-colors px-2"
        >
          Reset
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-7">

        {/* Age range */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800 text-sm">Age Range</h3>
            <span className="text-sm font-bold text-[#ff4d6d] bg-rose-50 px-3 py-1 rounded-full">
              {draft.minAge} – {draft.maxAge}
            </span>
          </div>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs text-gray-400 mb-1">
                <span>Min age</span><span>{draft.minAge}</span>
              </div>
              <input
                type="range" min={18} max={draft.maxAge - 1} value={draft.minAge}
                onChange={e => up('minAge', +e.target.value)}
                className="w-full accent-[#ff4d6d] h-2"
              />
            </div>
            <div>
              <div className="flex justify-between text-xs text-gray-400 mb-1">
                <span>Max age</span><span>{draft.maxAge}</span>
              </div>
              <input
                type="range" min={draft.minAge + 1} max={70} value={draft.maxAge}
                onChange={e => up('maxAge', +e.target.value)}
                className="w-full accent-[#ff4d6d] h-2"
              />
            </div>
          </div>
        </section>

        {/* Distance */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800 text-sm">Maximum Distance</h3>
            <span className="text-sm font-bold text-[#ff4d6d] bg-rose-50 px-3 py-1 rounded-full">
              {draft.maxDistance === 200 ? 'Any' : `${draft.maxDistance} km`}
            </span>
          </div>
          <input
            type="range" min={1} max={200} value={draft.maxDistance}
            onChange={e => up('maxDistance', +e.target.value)}
            className="w-full accent-[#ff4d6d] h-2"
          />
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>1 km</span><span>Any</span>
          </div>
        </section>

        {/* Gender */}
        <section>
          <h3 className="font-bold text-gray-800 text-sm mb-3">Show Me</h3>
          <div className="flex gap-2 flex-wrap">
            {ALL_GENDERS.map(g => {
              const on = draft.genders.includes(g)
              return (
                <button
                  key={g}
                  onClick={() => toggleArr('genders', g)}
                  className={`px-4 py-2.5 rounded-2xl text-sm font-semibold border-2 transition-all active:scale-95 ${
                    on ? 'bg-[#ff4d6d] text-white border-[#ff4d6d] shadow-sm shadow-rose-200'
                       : 'bg-gray-50 text-gray-600 border-gray-200 hover:border-rose-300'
                  }`}
                >
                  {g === 'Male' ? '👨 ' : g === 'Female' ? '👩 ' : '🧑 '}{g}
                </button>
              )
            })}
            {draft.genders.length > 0 && (
              <button onClick={() => up('genders', [])} className="px-3 py-2.5 rounded-2xl text-xs text-gray-400 border border-dashed border-gray-300">
                Clear
              </button>
            )}
          </div>
          {draft.genders.length === 0 && (
            <p className="text-xs text-gray-400 mt-2 pl-1">Showing everyone (no filter)</p>
          )}
        </section>

        {/* Interests */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800 text-sm">Interests</h3>
            {draft.interests.length > 0 && (
              <button onClick={() => up('interests', [])} className="text-xs text-[#ff4d6d] font-semibold">Clear</button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {ALL_INTERESTS.map(i => {
              const on = draft.interests.includes(i)
              return (
                <button
                  key={i}
                  onClick={() => toggleArr('interests', i)}
                  className={`px-3.5 py-2 rounded-full text-xs font-semibold border-2 transition-all active:scale-95 ${
                    on ? 'bg-[#ff4d6d] text-white border-[#ff4d6d]'
                       : 'bg-gray-50 text-gray-600 border-gray-200 hover:border-rose-300'
                  }`}
                >
                  {i}
                </button>
              )
            })}
          </div>
        </section>

        {/* Quick toggles */}
        <section className="space-y-2">
          <h3 className="font-bold text-gray-800 text-sm mb-3">Quick Filters</h3>
          <QuickToggle
            label="Online now only"
            sub="Show only users currently active"
            emoji="🟢"
            value={draft.onlineOnly}
            onChange={v => up('onlineOnly', v)}
          />
          <QuickToggle
            label="VIP members only"
            sub="Show only verified VIP profiles"
            emoji="👑"
            value={draft.vipOnly}
            onChange={v => up('vipOnly', v)}
          />
        </section>
      </div>

      {/* Apply button */}
      <div className="flex-shrink-0 px-4 py-4 border-t border-gray-100 bg-white">
        <button
          onClick={() => { onApply(draft); onClose() }}
          className="w-full py-4 rounded-2xl text-white font-bold text-base active:scale-[0.98] transition-transform shadow-lg shadow-rose-200"
          style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
        >
          {changed ? `Apply Filters${activeCount > 0 ? ` (${activeCount})` : ''}` : 'Show All Profiles'}
        </button>
      </div>
    </div>
  )
}

function QuickToggle({ label, sub, emoji, value, onChange }: {
  label: string; sub: string; emoji: string; value: boolean; onChange: (v: boolean) => void
}) {
  return (
    <div className={`flex items-center gap-3 px-4 py-3.5 rounded-2xl transition-colors ${value ? 'bg-rose-50 border-2 border-[#ff4d6d]/30' : 'bg-gray-50 border-2 border-transparent'}`}>
      <span className="text-xl">{emoji}</span>
      <div className="flex-1">
        <p className="font-semibold text-gray-800 text-sm">{label}</p>
        <p className="text-xs text-gray-400">{sub}</p>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`relative w-12 h-6 rounded-full transition-colors duration-200 flex-shrink-0 ${value ? 'bg-[#ff4d6d]' : 'bg-gray-300'}`}
      >
        <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform duration-200 ${value ? 'translate-x-6' : 'translate-x-0.5'}`} />
      </button>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   MAIN DISCOVER PAGE
───────────────────────────────────────────────────────────────── */
export default function DiscoverPage() {
  const { blockUser, isBlocked, submitReport } = usePrivacy()

  const [allProfiles] = useState(discoverProfiles)
  const [currentIdx, setCurrentIdx] = useState(0)
  const [swipeAnim, setSwipeAnim] = useState<'left' | 'right' | null>(null)
  const [showMatch, setShowMatch] = useState(false)
  const [matchedProfile, setMatchedProfile] = useState<Profile | null>(null)
  const [menuState, setMenuState] = useState<MenuState>('none')

  const [showSearch, setShowSearch] = useState(false)
  const [showFilter, setShowFilter] = useState(false)
  const [filters, setFilters] = useState<Filters>({ ...DEFAULT_FILTERS })
  const [highlightProfile, setHighlightProfile] = useState<Profile | null>(null)

  // Count active filters
  const activeFilterCount = useMemo(() => {
    let n = 0
    if (filters.minAge !== DEFAULT_FILTERS.minAge) n++
    if (filters.maxAge !== DEFAULT_FILTERS.maxAge) n++
    if (filters.maxDistance !== DEFAULT_FILTERS.maxDistance) n++
    if (filters.genders.length > 0) n++
    if (filters.interests.length > 0) n++
    if (filters.onlineOnly) n++
    if (filters.vipOnly) n++
    return n
  }, [filters])

  // Apply filters + skip blocked
  const filteredProfiles = useMemo(() => {
    return allProfiles.filter(p => {
      if (isBlocked(p.id)) return false
      if (p.age < filters.minAge || p.age > filters.maxAge) return false
      if (kmFromDistance(p.distance) > filters.maxDistance && filters.maxDistance < 200) return false
      if (filters.vipOnly && !p.isVip) return false
      if (filters.genders.length > 0) {
        // no gender field in Profile — skip gender filter gracefully
      }
      if (filters.interests.length > 0) {
        const hasAll = filters.interests.every(fi =>
          p.interests.some(pi => pi.toLowerCase().includes(fi.toLowerCase()))
        )
        if (!hasAll) return false
      }
      return true
    })
  }, [allProfiles, filters, isBlocked])

  // If a search result was tapped, pin it first
  const displayProfiles = useMemo(() => {
    if (!highlightProfile) return filteredProfiles
    const rest = filteredProfiles.filter(p => p.id !== highlightProfile.id)
    return [highlightProfile, ...rest]
  }, [filteredProfiles, highlightProfile])

  const visibleCurrent = displayProfiles[currentIdx] ?? null

  const handleSwipe = (dir: 'left' | 'right') => {
    setSwipeAnim(dir)
    if (dir === 'right' && visibleCurrent && Math.random() > 0.5) {
      setMatchedProfile(visibleCurrent)
      setTimeout(() => setShowMatch(true), 400)
    }
    setTimeout(() => {
      setSwipeAnim(null)
      setCurrentIdx(i => i + 1)
    }, 400)
  }

  const cardUser = visibleCurrent
    ? { id: visibleCurrent.id, name: visibleCurrent.name, avatar: visibleCurrent.avatar }
    : null

  return (
    <div className="flex flex-col h-full overflow-hidden relative" style={{ background: 'var(--discover-bg)' }}>

      {/* ── Header ── */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-b" style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        <div className="flex items-center gap-2">
          <svg width="22" height="20" viewBox="0 0 24 22" fill="#ff4d6d">
            <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
          </svg>
          <span className="text-[22px] font-bold text-[#ff4d6d]">Discover</span>
        </div>

        <div className="flex items-center gap-2">
          {/* 🔍 Search button */}
          <button
            onClick={() => setShowSearch(true)}
            className="w-9 h-9 rounded-full bg-gray-100 hover:bg-rose-100 active:scale-90 flex items-center justify-center text-gray-500 hover:text-[#ff4d6d] transition-all"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
          </button>

          {/* ≡ Filter button — badge shows active count */}
          <button
            onClick={() => setShowFilter(true)}
            className={`relative w-9 h-9 rounded-full active:scale-90 flex items-center justify-center transition-all ${
              activeFilterCount > 0
                ? 'bg-[#ff4d6d] text-white shadow-md shadow-rose-200'
                : 'bg-gray-100 hover:bg-rose-100 text-gray-500 hover:text-[#ff4d6d]'
            }`}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="4" y1="6" x2="20" y2="6"/>
              <line x1="8" y1="12" x2="16" y2="12"/>
              <line x1="10" y1="18" x2="14" y2="18"/>
            </svg>
            {activeFilterCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-white text-[#ff4d6d] text-[9px] font-black rounded-full flex items-center justify-center border border-rose-200 badge-pop">
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Active filter chips */}
      {activeFilterCount > 0 && (
        <div className="flex-shrink-0 flex gap-2 px-4 py-2 overflow-x-auto scrollbar-none border-b" style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
          {filters.genders.map(g => (
            <Chip key={g} label={g} onRemove={() => setFilters(f => ({ ...f, genders: f.genders.filter(x => x !== g) }))} />
          ))}
          {filters.interests.map(i => (
            <Chip key={i} label={i} onRemove={() => setFilters(f => ({ ...f, interests: f.interests.filter(x => x !== i) }))} />
          ))}
          {(filters.minAge !== 18 || filters.maxAge !== 45) && (
            <Chip label={`${filters.minAge}–${filters.maxAge} yrs`} onRemove={() => setFilters(f => ({ ...f, minAge: 18, maxAge: 45 }))} />
          )}
          {filters.maxDistance < 200 && (
            <Chip label={`≤${filters.maxDistance} km`} onRemove={() => setFilters(f => ({ ...f, maxDistance: 200 }))} />
          )}
          {filters.onlineOnly && (
            <Chip label="Online now" onRemove={() => setFilters(f => ({ ...f, onlineOnly: false }))} />
          )}
          {filters.vipOnly && (
            <Chip label="VIP only" onRemove={() => setFilters(f => ({ ...f, vipOnly: false }))} />
          )}
          <button
            onClick={() => setFilters({ ...DEFAULT_FILTERS })}
            className="flex-shrink-0 px-3 py-1 text-xs font-semibold text-gray-400 border border-dashed border-gray-300 rounded-full hover:text-red-500 hover:border-red-300 transition-colors"
          >
            Clear all
          </button>
        </div>
      )}

      {/* ── Card area ── */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-4 overflow-hidden">
        {visibleCurrent ? (
          <div className="relative w-full max-w-sm">
            {/* Background stack hint */}
            {displayProfiles[currentIdx + 1] && (
              <div className="absolute inset-0 top-2 mx-2 scale-[0.96] bg-white rounded-3xl shadow-sm" />
            )}
            {displayProfiles[currentIdx + 2] && (
              <div className="absolute inset-0 top-4 mx-4 scale-[0.92] bg-white rounded-3xl shadow-sm" />
            )}

            {/* Main card */}
            <div
              className={`relative bg-white rounded-3xl shadow-xl overflow-hidden transition-all ${
                swipeAnim === 'left'  ? '-translate-x-[120%] -rotate-[15deg] opacity-0' :
                swipeAnim === 'right' ? 'translate-x-[120%] rotate-[15deg] opacity-0' : ''
              }`}
              style={{ transitionDuration: '380ms', transitionTimingFunction: 'cubic-bezier(0.4,0,0.2,1)' }}
            >
              <div className="relative aspect-[3/4]">
                <img src={visibleCurrent.avatar} alt={visibleCurrent.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />

                {/* VIP badge */}
                {visibleCurrent.isVip && (
                  <div className="absolute top-4 right-4 flex items-center gap-1 px-2.5 py-1 bg-amber-400 rounded-full shadow">
                    <span className="text-xs">👑</span>
                    <span className="text-white text-xs font-bold">VIP</span>
                  </div>
                )}

                {/* ··· options */}
                <button
                  onClick={() => setMenuState('options')}
                  className="absolute top-4 left-4 w-9 h-9 rounded-full bg-black/30 backdrop-blur flex items-center justify-center active:scale-90 transition-transform"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
                    <circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>
                  </svg>
                </button>

                {/* Profile info */}
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <h2 className="text-2xl font-black text-white mb-0.5">{visibleCurrent.name}, {visibleCurrent.age}</h2>
                  <p className="text-white/80 text-sm mb-1">📍 {visibleCurrent.distance}</p>
                  <p className="text-white/70 text-sm leading-relaxed line-clamp-2">{visibleCurrent.bio}</p>
                  <div className="flex flex-wrap gap-1.5 mt-2.5">
                    {visibleCurrent.interests.map(i => (
                      <span key={i} className="px-2.5 py-0.5 bg-white/20 backdrop-blur text-white text-xs font-medium rounded-full">{i}</span>
                    ))}
                  </div>
                </div>

                {/* Swipe hint overlays */}
                {swipeAnim === 'left' && (
                  <div className="absolute top-8 left-6 px-4 py-2 border-4 border-red-400 rounded-xl rotate-[-20deg]">
                    <span className="text-red-400 text-2xl font-black">NOPE</span>
                  </div>
                )}
                {swipeAnim === 'right' && (
                  <div className="absolute top-8 right-6 px-4 py-2 border-4 border-emerald-400 rounded-xl rotate-[20deg]">
                    <span className="text-emerald-400 text-2xl font-black">LIKE</span>
                  </div>
                )}
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center justify-center gap-5 mt-5">
              <button
                onClick={() => handleSwipe('left')}
                className="w-14 h-14 rounded-full bg-white shadow-lg flex items-center justify-center border border-gray-200 active:scale-90 transition-transform hover:border-red-300 hover:shadow-red-100"
              >
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2.5" strokeLinecap="round">
                  <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>

              <button
                onClick={() => handleSwipe('right')}
                className="w-16 h-16 rounded-full flex items-center justify-center shadow-xl active:scale-90 transition-transform hover:shadow-rose-300"
                style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
              >
                <svg width="28" height="26" viewBox="0 0 24 22" fill="white">
                  <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
                </svg>
              </button>

              <button className="w-14 h-14 rounded-full bg-white shadow-lg flex items-center justify-center border border-gray-200 active:scale-90 transition-transform hover:border-violet-300 hover:shadow-violet-100">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                </svg>
              </button>
            </div>

            {/* Profile counter + View Profile link */}
            <div className="flex items-center justify-between mt-3 px-1">
              <span className="text-xs text-gray-400 font-medium">
                {currentIdx + 1} / {displayProfiles.length} profiles
                {activeFilterCount > 0 && <span className="text-[#ff4d6d]"> · {activeFilterCount} filter{activeFilterCount !== 1 ? 's' : ''} on</span>}
              </span>
              <button
                onClick={() => setMenuState('profile')}
                className="text-xs font-semibold text-[#ff4d6d] flex items-center gap-1 hover:underline"
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
                </svg>
                View profile
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center px-6">
            <div className="w-20 h-20 rounded-full bg-rose-100 flex items-center justify-center mx-auto mb-4">
              <svg width="40" height="36" viewBox="0 0 24 22" fill="#ff4d6d">
                <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
              </svg>
            </div>
            {activeFilterCount > 0 ? (
              <>
                <p className="text-xl font-bold text-gray-800 mb-1">No profiles match your filters</p>
                <p className="text-gray-500 text-sm mb-5">Try widening your age range or distance</p>
                <button
                  onClick={() => setFilters({ ...DEFAULT_FILTERS })}
                  className="px-6 py-3 rounded-full text-white font-bold text-sm active:scale-95 transition-transform"
                  style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
                >
                  Clear Filters
                </button>
              </>
            ) : (
              <>
                <p className="text-xl font-bold text-gray-800 mb-1">No more profiles!</p>
                <p className="text-gray-500 text-sm">Check back later for more matches</p>
              </>
            )}
          </div>
        )}
      </div>

      {/* ── Match modal ── */}
      {showMatch && matchedProfile && (
        <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-50 p-6">
          <div className="bg-white rounded-3xl p-8 text-center w-full max-w-sm shadow-2xl">
            <div className="flex justify-center mb-5">
              <div className="flex -space-x-4">
                <img src={matchedProfile.avatar} alt="" className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-lg" />
              </div>
            </div>
            <div className="text-4xl mb-3">💕</div>
            <h2 className="text-2xl font-black text-[#ff4d6d] mb-1">It's a Match!</h2>
            <p className="text-gray-500 text-sm mb-6">You and <span className="font-bold text-gray-700">{matchedProfile.name}</span> liked each other</p>
            <div className="space-y-2.5">
              <button
                className="w-full py-3.5 rounded-full text-white font-bold active:scale-95 transition-transform"
                style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
                onClick={() => setShowMatch(false)}
              >
                💬 Send a Message
              </button>
              <button
                onClick={() => setShowMatch(false)}
                className="w-full py-3 text-gray-500 font-semibold text-sm active:scale-95 transition-transform"
              >
                Keep Swiping
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Search overlay ── */}
      {showSearch && (
        <SearchOverlay
          profiles={allProfiles.filter(p => !isBlocked(p.id))}
          onClose={() => setShowSearch(false)}
          onSelect={p => { setHighlightProfile(p); setCurrentIdx(0) }}
        />
      )}

      {/* ── Filter panel ── */}
      {showFilter && (
        <FilterPanel
          filters={filters}
          activeCount={activeFilterCount}
          onApply={f => { setFilters(f); setCurrentIdx(0) }}
          onClose={() => setShowFilter(false)}
        />
      )}

      {/* ── User options / block / report ── */}
      {menuState === 'options' && cardUser && (
        <UserOptionsSheet
          user={cardUser}
          isBlocked={isBlocked(cardUser.id)}
          onBlock={() => setMenuState('block')}
          onReport={() => setMenuState('report')}
          onClose={() => setMenuState('none')}
        />
      )}
      {menuState === 'block' && cardUser && (
        <BlockConfirmSheet
          user={cardUser}
          onBlock={() => { blockUser(cardUser); handleSwipe('left') }}
          onClose={() => setMenuState('none')}
        />
      )}
      {menuState === 'report' && cardUser && (
        <ReportFlow
          user={cardUser}
          onSubmit={(reason, detail) => { submitReport(cardUser, reason, detail); setMenuState('none') }}
          onClose={() => setMenuState('none')}
        />
      )}

      {/* ── Profile viewer ── */}
      {menuState === 'profile' && visibleCurrent && (
        <UserProfileView
          user={
            getRichProfile(visibleCurrent.name, {
              id: visibleCurrent.id,
              name: visibleCurrent.name,
              avatar: visibleCurrent.avatar,
              age: visibleCurrent.age,
              location: visibleCurrent.location,
              bio: visibleCurrent.bio,
              interests: visibleCurrent.interests,
              isVip: visibleCurrent.isVip,
              distance: visibleCurrent.distance,
              images: visibleCurrent.images,
            }) ?? {
              id: visibleCurrent.id,
              name: visibleCurrent.name,
              avatar: visibleCurrent.avatar,
              age: visibleCurrent.age,
              location: visibleCurrent.location,
              bio: visibleCurrent.bio,
              interests: visibleCurrent.interests,
              isVip: visibleCurrent.isVip,
              distance: visibleCurrent.distance,
              images: visibleCurrent.images,
            }
          }
          onClose={() => setMenuState('none')}
          onLike={() => handleSwipe('right')}
        />
      )}
    </div>
  )
}

/* ── Active filter chip ── */
function Chip({ label, onRemove }: { label: string; onRemove: () => void }) {
  return (
    <div className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 bg-rose-100 text-[#ff4d6d] rounded-full">
      <span className="text-xs font-bold">{label}</span>
      <button onClick={onRemove} className="active:scale-90 transition-transform">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>
  )
}
