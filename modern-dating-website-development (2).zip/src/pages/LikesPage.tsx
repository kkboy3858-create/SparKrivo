import { likedProfiles } from '../data/mockData'
import { useVip } from '../vip/VipContext'
import { VipBadge } from '../vip/VipBadge'
import VipModal from '../vip/VipModal'
import { useState } from 'react'
import UserProfileView, { type ViewableUser } from '../components/UserProfileView'

export default function LikesPage() {
  const { isVip } = useVip()
  const [showVip, setShowVip] = useState(false)
  const [viewingProfile, setViewingProfile] = useState<ViewableUser | null>(null)

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden relative">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 bg-white border-b border-gray-100">
        <div className="flex items-center gap-2">
          <svg width="22" height="20" viewBox="0 0 24 22" fill="#ff4d6d">
            <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
          </svg>
          <span className="text-[22px] font-bold text-[#ff4d6d]">Who Likes You</span>
        </div>
        <div className="flex items-center gap-2">
          {isVip
            ? <VipBadge size="sm" />
            : (
              <button
                onClick={() => setShowVip(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold text-white active:scale-95 transition-transform"
                style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}
              >
                👑 Go VIP
              </button>
            )
          }
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        {/* Counter */}
        <div className="text-center mb-5">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-rose-50 rounded-full">
            <svg width="16" height="14" viewBox="0 0 24 22" fill="#ff4d6d">
              <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
            </svg>
            <span className="text-sm font-bold text-[#ff4d6d]">{likedProfiles.length} people liked you</span>
          </div>
        </div>

        {/* Profile grid */}
        <div className="grid grid-cols-2 gap-3">
          {likedProfiles.map(profile => (
            <div
              key={profile.id}
              className="relative rounded-2xl overflow-hidden aspect-square bg-gray-100 cursor-pointer"
              onClick={() => {
                if (profile.isBlurred && !isVip) { setShowVip(true); return }
                setViewingProfile({
                  id: profile.id,
                  name: profile.name,
                  avatar: profile.avatar,
                  age: profile.age > 0 ? profile.age : undefined,
                  isVip: profile.isVip,
                })
              }}
            >
              <img
                src={profile.avatar}
                alt={profile.isBlurred ? '???' : profile.name}
                className={`w-full h-full object-cover transition-all ${profile.isBlurred && !isVip ? 'blur-[10px] scale-110' : ''}`}
              />

              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />

              {/* Info */}
              <div className="absolute bottom-0 left-0 right-0 p-3">
                {profile.isBlurred && !isVip ? (
                  <div className="text-center">
                    <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur flex items-center justify-center mx-auto mb-1">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                      </svg>
                    </div>
                    <p className="text-white text-xs font-bold">???</p>
                    <button
                      onClick={() => setShowVip(true)}
                      className="text-amber-300 text-[10px] font-bold mt-0.5 underline"
                    >
                      Go VIP to reveal
                    </button>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center gap-1">
                      <p className="text-white text-sm font-bold">{profile.name}</p>
                      {profile.isVip && <span className="text-xs">👑</span>}
                    </div>
                    {profile.age > 0 && <p className="text-white/70 text-xs">{profile.age} years old</p>}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* VIP promo card (free users only) */}
        {!isVip && (
          <button
            onClick={() => setShowVip(true)}
            className="mt-5 w-full rounded-2xl p-5 text-left active:scale-[0.98] transition-transform relative overflow-hidden"
            style={{ background: 'linear-gradient(135deg,#fef3c7,#fde68a)' }}
          >
            <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-amber-300/30 -translate-y-8 translate-x-8" />
            <div className="text-3xl mb-2">👑</div>
            <h3 className="font-black text-gray-900 mb-1">Unlock All {likedProfiles.filter(p => p.isBlurred).length} Hidden Likes</h3>
            <p className="text-gray-600 text-sm mb-3">See everyone who liked you, make voice & video calls, and unlock all premium features!</p>
            <div className="flex items-center gap-2">
              <span
                className="px-4 py-2 rounded-full text-white text-sm font-black"
                style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}
              >
                Get VIP — From $5/mo
              </span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#d97706" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </div>
          </button>
        )}

        {/* Sponsored ad (free users) */}
        {!isVip && (
          <div className="mt-4 rounded-2xl bg-gray-50 border border-gray-200 p-4 relative">
            <div className="absolute top-2 right-2 px-1.5 py-0.5 bg-gray-200 text-gray-400 text-[9px] font-bold rounded uppercase tracking-wide">
              Sponsored
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 to-violet-500 flex items-center justify-center text-xl flex-shrink-0">🌍</div>
              <div>
                <p className="font-bold text-gray-800 text-sm">Find your perfect match today</p>
                <p className="text-xs text-gray-400">SparkMatch VIP — unlimited connections</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* VIP modal */}
      {showVip && <VipModal onClose={() => setShowVip(false)} />}

      {/* Profile viewer */}
      {viewingProfile && (
        <UserProfileView
          user={viewingProfile}
          onClose={() => setViewingProfile(null)}
        />
      )}
    </div>
  )
}
