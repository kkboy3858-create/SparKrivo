import { useEffect, useState } from 'react'

interface Props {
  onDone: () => void
}

export default function SplashScreen({ onDone }: Props) {
  const [visible, setVisible] = useState(true)
  const [fadeOut, setFadeOut] = useState(false)

  useEffect(() => {
    const t1 = setTimeout(() => setFadeOut(true), 1800)
    const t2 = setTimeout(() => { setVisible(false); onDone() }, 2300)
    return () => { clearTimeout(t1); clearTimeout(t2) }
  }, [onDone])

  if (!visible) return null

  return (
    <div
      className="absolute inset-0 z-[999] flex flex-col items-center justify-center"
      style={{
        background: 'linear-gradient(160deg, #ff4d6d 0%, #ff8fa3 40%, #c0392b 100%)',
        opacity: fadeOut ? 0 : 1,
        transition: 'opacity 0.5s ease-out',
      }}
    >
      {/* Logo mark */}
      <div
        className="flex items-center justify-center mb-5"
        style={{
          width: 96, height: 96, borderRadius: 28,
          background: 'rgba(255,255,255,0.2)',
          backdropFilter: 'blur(12px)',
          boxShadow: '0 0 40px rgba(255,255,255,0.25)',
          animation: 'splashPulse 1.5s ease-in-out infinite',
        }}
      >
        <svg width="52" height="48" viewBox="0 0 24 22" fill="white">
          <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
        </svg>
      </div>

      {/* App name */}
      <h1 className="text-white font-black text-4xl tracking-tight mb-2">SparkMatch</h1>
      <p className="text-white/75 text-base font-medium">Connect & Flourish</p>

      {/* Loading dots */}
      <div className="flex items-center gap-2 mt-12">
        {[0, 1, 2].map(i => (
          <div
            key={i}
            className="w-2 h-2 rounded-full bg-white/60"
            style={{ animation: `splashDot 1.2s ease-in-out ${i * 0.2}s infinite` }}
          />
        ))}
      </div>

      <style>{`
        @keyframes splashPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.06); }
        }
        @keyframes splashDot {
          0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; }
          40% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  )
}
