import { createContext, useContext, useState, useEffect, type ReactNode } from 'react'

export type ThemeMode = 'light' | 'dark' | 'system'

interface ThemeCtx {
  mode: ThemeMode
  isDark: boolean
  setMode: (m: ThemeMode) => void
}

const Ctx = createContext<ThemeCtx>({ mode: 'light', isDark: false, setMode: () => {} })

const STORAGE_KEY = 'sparkmatch-theme'

function safeGet(): ThemeMode {
  try { return (localStorage.getItem(STORAGE_KEY) as ThemeMode) || 'light' } catch { return 'light' }
}

function safeSet(m: ThemeMode) {
  try { localStorage.setItem(STORAGE_KEY, m) } catch {}
}

function prefersDark(): boolean {
  try { return window.matchMedia('(prefers-color-scheme: dark)').matches } catch { return false }
}

function resolveIsDark(mode: ThemeMode): boolean {
  if (mode === 'dark') return true
  if (mode === 'light') return false
  return prefersDark()
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<ThemeMode>(() => safeGet())
  const [isDark, setIsDark] = useState<boolean>(() => resolveIsDark(safeGet()))

  useEffect(() => {
    try {
      const mq = window.matchMedia('(prefers-color-scheme: dark)')
      const update = () => setIsDark(resolveIsDark(mode))
      mq.addEventListener('change', update)
      return () => mq.removeEventListener('change', update)
    } catch { return undefined }
  }, [mode])

  const setMode = (m: ThemeMode) => {
    setModeState(m)
    safeSet(m)
    setIsDark(resolveIsDark(m))
  }

  return (
    <Ctx.Provider value={{ mode, isDark, setMode }}>
      {children}
    </Ctx.Provider>
  )
}

export function useTheme() {
  return useContext(Ctx)
}
