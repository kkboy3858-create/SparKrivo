import { useState } from 'react'
import { ThemeProvider, useTheme } from './theme/ThemeContext'
import { PrivacyProvider } from './privacy/PrivacyContext'
import { VipProvider } from './vip/VipContext'
import { CallProvider, useCall } from './calls/CallContext'
import VoiceCallScreen from './calls/VoiceCallScreen'
import VideoCallScreen from './calls/VideoCallScreen'
import IncomingCallPopup from './calls/IncomingCallPopup'
import FeedPage from './pages/FeedPage'
import DiscoverPage from './pages/DiscoverPage'
import LikesPage from './pages/LikesPage'
import MatchesPage from './pages/MatchesPage'
import ProfilePage from './pages/ProfilePage'
import BottomNav from './components/BottomNav'
import NotificationsPanel from './components/NotificationsPanel'
import SearchPanel from './components/SearchPanel'
import { ToastStack } from './notifications/NotifToast'
import { useNotificationStore } from './notifications/useNotificationStore'
import SplashScreen from './pages/SplashScreen'
import LandingPage from './pages/LandingPage'
import AuthPage from './pages/AuthPage'

export type TabType = 'discover' | 'feed' | 'likes' | 'matches' | 'profile'
type Screen = 'splash' | 'landing' | 'auth' | 'app'
type AuthMode = 'signin' | 'signup'

function getSession(): boolean {
  try { return !!localStorage.getItem('sm-session') } catch { return false }
}
function setSession(): void {
  try { localStorage.setItem('sm-session', '1') } catch {}
}
function deleteSession(): void {
  try { localStorage.removeItem('sm-session') } catch {}
}

export default function App() {
  return (
    <ThemeProvider>
      <AppShell />
    </ThemeProvider>
  )
}

function AppShell() {
  const { isDark, setMode } = useTheme()
  const [screen, setScreen] = useState<Screen>(() => {
    try { return getSession() ? 'app' : 'splash' } catch { return 'splash' }
  })
  const [authMode, setAuthMode] = useState<AuthMode>('signup')

  const toggleTheme = () => {
    try { setMode(isDark ? 'light' : 'dark') } catch {}
  }

  return (
    <div
      className="flex justify-center items-center min-h-screen"
      style={{ background: isDark ? '#09090f' : '#e5e7eb' }}
    >
      <div
        className={`relative w-full max-w-[430px] h-screen max-h-[932px] overflow-hidden flex flex-col shadow-2xl ${isDark ? 'dark' : ''}`}
        style={{ background: isDark ? '#0f0f14' : '#ffffff' }}
      >
        {screen === 'splash' && (
          <SplashScreen onDone={() => setScreen('landing')} />
        )}

        {screen === 'landing' && (
          <LandingPage
            onGetStarted={() => { setAuthMode('signup'); setScreen('auth') }}
            onSignIn={() => { setAuthMode('signin'); setScreen('auth') }}
          />
        )}

        {screen === 'auth' && (
          <AuthPage
            mode={authMode}
            onSuccess={() => { setSession(); setScreen('app') }}
            onBack={() => setScreen('landing')}
          />
        )}

        {screen === 'app' && (
          <VipProvider>
            <CallProvider>
              <PrivacyProvider>
                <MainApp
                  isDark={isDark}
                  onToggleTheme={toggleTheme}
                  onSignOut={() => { deleteSession(); setScreen('landing') }}
                />
              </PrivacyProvider>
            </CallProvider>
          </VipProvider>
        )}
      </div>
    </div>
  )
}

function MainApp({ isDark, onToggleTheme, onSignOut }: { isDark: boolean; onToggleTheme: () => void; onSignOut: () => void }) {
  const [activeTab, setActiveTab] = useState<TabType>('feed')
  const [showNotifications, setShowNotifications] = useState(false)
  const [showSearch, setShowSearch] = useState(false)

  const {
    notifications, badges, toastQueue, soundSettings,
    pushPermission, markAllRead, markRead, dismiss,
    dismissToast, requestPushPermission, updateSoundSettings,
  } = useNotificationStore(activeTab)

  const renderPage = () => {
    switch (activeTab) {
      case 'discover': return <DiscoverPage />
      case 'feed':
        return (
          <FeedPage
            onSearchOpen={() => { setShowSearch(true); setShowNotifications(false) }}
            onNotifOpen={() => { setShowNotifications(true); setShowSearch(false) }}
            notifCount={badges.total}
          />
        )
      case 'likes':   return <LikesPage />
      case 'matches': return <MatchesPage />
      case 'profile':
        return (
          <ProfilePage
            onNotifOpen={() => setShowNotifications(true)}
            soundSettings={soundSettings}
            onUpdateSound={updateSoundSettings}
            onSignOut={onSignOut}
            isDark={isDark}
            onToggleTheme={onToggleTheme}
          />
        )
      default:
        return (
          <FeedPage
            onSearchOpen={() => setShowSearch(true)}
            onNotifOpen={() => setShowNotifications(true)}
            notifCount={badges.total}
          />
        )
    }
  }

  return (
    <>
      {renderPage()}

      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} badges={badges} />

      <ToastStack toasts={toastQueue} onDismiss={dismissToast} />

      {showNotifications && (
        <NotificationsPanel
          notifications={notifications}
          unreadCount={notifications.filter(n => !n.isRead).length}
          onClose={() => setShowNotifications(false)}
          onMarkAllRead={markAllRead}
          onMarkRead={markRead}
          onDismiss={dismiss}
          soundSettings={soundSettings}
          pushPermission={pushPermission}
          onUpdateSound={updateSoundSettings}
          onRequestPush={requestPushPermission}
        />
      )}

      {showSearch && <SearchPanel onClose={() => setShowSearch(false)} />}

      <CallLayer />
    </>
  )
}

function CallLayer() {
  const { session, incomingCall } = useCall()
  const { state, type } = session
  const active = state === 'calling' || state === 'connected' || state === 'ended' || state === 'declined'
  return (
    <>
      {incomingCall && <IncomingCallPopup />}
      {active && type === 'voice' && <VoiceCallScreen />}
      {active && type === 'video' && <VideoCallScreen />}
    </>
  )
}
