// ── Story slide (one card inside a story) ──────────────────
export type StorySlideType = 'image' | 'video' | 'text'

export interface StorySlide {
  id: string
  type: StorySlideType
  mediaUrl?: string          // image / video URL
  textContent?: string       // for text-only slides
  textColor?: string         // hex
  bgGradient?: string        // tailwind gradient string
  overlayText?: string       // text drawn on top of image/video
  overlayTextColor?: string
  duration: number           // ms this slide shows (default 5000)
  createdAt: number          // ms timestamp (for 24h expiry)
}

// ── Story (one user's collection of slides) ─────────────────
export interface StoryUser {
  id: string
  name: string
  avatar: string
  isOwn?: boolean
  isVip?: boolean
  slides: StorySlide[]
  seen?: boolean             // current user has already seen this
}

// Legacy interface kept for any remaining usages
export interface Story {
  id: string
  name: string
  avatar: string
  isOwn?: boolean
  hasNew?: boolean
}

export interface Post {
  id: string
  userId: string
  userName: string
  userAvatar: string
  isVip?: boolean
  timeAgo: string
  image?: string           // URL for image posts
  video?: string           // URL for video posts
  mediaType?: 'image' | 'video'   // explicit type discriminator
  caption: string
  likes: number
  comments: number
  liked: boolean
  commentList?: Comment[]
}

export interface Comment {
  id: string
  userId: string
  userName: string
  userAvatar: string
  text: string
  timeAgo: string
}

export interface Profile {
  id: string
  name: string
  age: number
  location: string
  avatar: string
  bio: string
  isVip?: boolean
  images: string[]
  distance: string
  interests: string[]
}

export interface Match {
  id: string
  name: string
  avatar: string
  lastMessage: string
  timeAgo: string
  unread: number
  isOnline: boolean
  isVip?: boolean
}

export interface LikedProfile {
  id: string
  name: string
  age: number
  avatar: string
  isVip?: boolean
  isBlurred?: boolean
}

export const currentUser = {
  id: 'me',
  name: 'You',
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face',
  isVip: false,
}

export const stories: Story[] = [
  { id: 'own', name: 'Your story', avatar: currentUser.avatar, isOwn: true },
  { id: '1', name: 'Kevin',   avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face', hasNew: true },
  { id: '2', name: 'Olawale', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face', hasNew: true },
  { id: '3', name: 'View yours', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face', hasNew: false },
  { id: '4', name: 'Amara',  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face', hasNew: true },
  { id: '5', name: 'Tunde',  avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop&crop=face', hasNew: false },
]

const NOW = Date.now()
const H = 3600000 // 1 hour in ms

export const storyUsers: StoryUser[] = [
  /* ── 0: Your own story ─────────────────────────────── */
  {
    id: 'own', name: 'Your Story', isOwn: true, isVip: false,
    avatar: currentUser.avatar,
    seen: false,
    slides: [
      {
        id: 'own-s1', type: 'text', duration: 6000,
        textContent: 'Good morning! 🌅',
        bgGradient: 'from-rose-400 via-pink-500 to-fuchsia-500',
        textColor: '#ffffff',
        createdAt: NOW - H * 2,
      },
    ],
  },
  /* ── 1: Chisom ─────────────────────────────────────── */
  {
    id: 'u1', name: 'Chisom', isVip: false,
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    seen: false,
    slides: [
      {
        id: 'u1-s1', type: 'image', duration: 5000,
        mediaUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&h=1000&fit=crop',
        overlayText: 'Living my best life ✨',
        overlayTextColor: '#ffffff',
        createdAt: NOW - H * 1,
      },
      {
        id: 'u1-s2', type: 'image', duration: 5000,
        mediaUrl: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=600&h=1000&fit=crop',
        overlayText: 'Lagos sunsets 🌆',
        overlayTextColor: '#fff',
        createdAt: NOW - H * 0.5,
      },
      {
        id: 'u1-s3', type: 'text', duration: 4000,
        textContent: 'Anyone free this weekend? 🌺',
        bgGradient: 'from-orange-400 via-pink-500 to-rose-500',
        textColor: '#fff',
        createdAt: NOW - H * 0.2,
      },
    ],
  },
  /* ── 2: Kevin ──────────────────────────────────────── */
  {
    id: 'u2', name: 'Kevin', isVip: true,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    seen: false,
    slides: [
      {
        id: 'u2-s1', type: 'image', duration: 5000,
        mediaUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=1000&fit=crop',
        overlayText: 'Gym session 💪🔥',
        overlayTextColor: '#fff',
        createdAt: NOW - H * 3,
      },
      {
        id: 'u2-s2', type: 'text', duration: 5000,
        textContent: 'New PB today! 185kg deadlift 🏋️‍♂️',
        bgGradient: 'from-slate-800 via-gray-900 to-black',
        textColor: '#facc15',
        createdAt: NOW - H * 2.5,
      },
    ],
  },
  /* ── 3: Fatima ─────────────────────────────────────── */
  {
    id: 'u3', name: 'Fatima', isVip: true,
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=100&h=100&fit=crop&crop=face',
    seen: false,
    slides: [
      {
        id: 'u3-s1', type: 'image', duration: 5000,
        mediaUrl: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=600&h=1000&fit=crop',
        overlayText: '☕ Coffee & study',
        overlayTextColor: '#fff',
        createdAt: NOW - H * 5,
      },
      {
        id: 'u3-s2', type: 'image', duration: 5000,
        mediaUrl: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=600&h=1000&fit=crop',
        overlayText: 'Art museum 🎨',
        overlayTextColor: '#fff',
        createdAt: NOW - H * 4,
      },
      {
        id: 'u3-s3', type: 'text', duration: 4000,
        textContent: '3 more exams to go… 📚',
        bgGradient: 'from-blue-500 via-indigo-600 to-purple-700',
        textColor: '#fff',
        createdAt: NOW - H * 2,
      },
    ],
  },
  /* ── 4: Olawale ────────────────────────────────────── */
  {
    id: 'u4', name: 'Olawale', isVip: false,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face',
    seen: true,
    slides: [
      {
        id: 'u4-s1', type: 'image', duration: 5000,
        mediaUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&h=1000&fit=crop',
        overlayText: 'Bar TB 😂',
        overlayTextColor: '#fff',
        createdAt: NOW - H * 14,
      },
    ],
  },
  /* ── 5: Blessing ───────────────────────────────────── */
  {
    id: 'u5', name: 'Blessing', isVip: false,
    avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=100&h=100&fit=crop&crop=face',
    seen: false,
    slides: [
      {
        id: 'u5-s1', type: 'image', duration: 5000,
        mediaUrl: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=600&h=1000&fit=crop',
        overlayText: 'New artwork! 🎨✨',
        overlayTextColor: '#fff',
        createdAt: NOW - H * 6,
      },
      {
        id: 'u5-s2', type: 'text', duration: 5000,
        textContent: 'Commission open — DM me!',
        bgGradient: 'from-emerald-400 via-teal-500 to-cyan-600',
        textColor: '#fff',
        createdAt: NOW - H * 5,
      },
    ],
  },
]

export const posts: Post[] = [
  {
    id: '1',
    userId: '2',
    userName: 'Olawale',
    userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face',
    timeAgo: '14h ago',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&h=700&fit=crop',
    caption: 'Bar TB😂😂😂😂',
    likes: 3,
    comments: 3,
    liked: true,
    commentList: [
      { id: 'c1', userId: '1', userName: 'Kevin', userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=60&fit=crop&crop=face', text: 'Haha 😂', timeAgo: '13h ago' },
      { id: 'c2', userId: '3', userName: 'Amara', userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&h=60&fit=crop&crop=face', text: 'Looking good!', timeAgo: '10h ago' },
      { id: 'c3', userId: 'me', userName: 'You', userAvatar: currentUser.avatar, text: 'Lol 😂', timeAgo: '8h ago' },
    ],
  },
  {
    id: '2',
    userId: '1',
    userName: 'Kevin',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    isVip: true,
    timeAgo: '2h ago',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=700&fit=crop',
    caption: 'Beautiful Sunday morning ☀️ Feeling great!',
    likes: 12,
    comments: 5,
    liked: false,
    commentList: [
      { id: 'c4', userId: '2', userName: 'Olawale', userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=60&h=60&fit=crop&crop=face', text: 'Nice vibes!', timeAgo: '1h ago' },
    ],
  },
  {
    id: '3',
    userId: '4',
    userName: 'Amara',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    timeAgo: '5h ago',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600&h=700&fit=crop',
    caption: 'Weekend vibes 🌸✨',
    likes: 24,
    comments: 8,
    liked: false,
  },
]

export const discoverProfiles: Profile[] = [
  {
    id: '10',
    name: 'Chisom',
    age: 24,
    location: 'Lagos, NG',
    distance: '2 km away',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600&h=800&fit=crop',
    bio: 'Love adventures and good vibes ✨',
    isVip: false,
    interests: ['Travel', 'Music', 'Fitness'],
    images: [
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600&h=800&fit=crop',
      'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=600&h=800&fit=crop',
    ],
  },
  {
    id: '11',
    name: 'Fatima',
    age: 22,
    location: 'Abuja, NG',
    distance: '5 km away',
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=600&h=800&fit=crop',
    bio: 'Medical student | Foodie 🍕 | Dog lover 🐶',
    isVip: true,
    interests: ['Reading', 'Cooking', 'Hiking'],
    images: [
      'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=600&h=800&fit=crop',
    ],
  },
  {
    id: '12',
    name: 'Blessing',
    age: 26,
    location: 'Port Harcourt, NG',
    distance: '8 km away',
    avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=600&h=800&fit=crop',
    bio: 'Artist & creative soul 🎨',
    isVip: false,
    interests: ['Art', 'Dancing', 'Photography'],
    images: [
      'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=600&h=800&fit=crop',
    ],
  },
]

export const likedProfiles: LikedProfile[] = [
  { id: 'l1', name: 'Chisom', age: 24, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop', isVip: false },
  { id: 'l2', name: 'Fatima', age: 22, avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=200&h=200&fit=crop', isVip: true },
  { id: 'l3', name: '???', age: 0, avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=200&h=200&fit=crop', isBlurred: true },
  { id: 'l4', name: '???', age: 0, avatar: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=200&h=200&fit=crop', isBlurred: true },
  { id: 'l5', name: '???', age: 0, avatar: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=200&h=200&fit=crop', isBlurred: true },
]

// ── Notifications ────────────────────────────────────────────
export type NotifType = 'match' | 'like' | 'message' | 'comment' | 'superlike' | 'system'

export interface AppNotification {
  id: string
  type: NotifType
  avatar: string
  name: string
  text: string
  timeAgo: string
  isRead: boolean
  postImage?: string
}

export const notificationsData: AppNotification[] = [
  {
    id: 'n1', type: 'match',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    name: 'Chisom', text: 'You and Chisom matched! Say hello 👋', timeAgo: '2m ago', isRead: false,
  },
  {
    id: 'n2', type: 'like',
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=100&h=100&fit=crop&crop=face',
    name: 'Fatima', text: 'Fatima liked your profile ❤️', timeAgo: '15m ago', isRead: false,
  },
  {
    id: 'n3', type: 'message',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
    name: 'Kevin', text: 'Kevin sent you a message: "Hey! How are you?"', timeAgo: '1h ago', isRead: false,
  },
  {
    id: 'n4', type: 'comment',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face',
    name: 'Olawale', text: 'Olawale commented on your post: "Looking great! 🔥"', timeAgo: '2h ago', isRead: false,
    postImage: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80&h=80&fit=crop',
  },
  {
    id: 'n5', type: 'superlike',
    avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=100&h=100&fit=crop&crop=face',
    name: 'Blessing', text: 'Blessing super liked you ⭐', timeAgo: '3h ago', isRead: true,
  },
  {
    id: 'n6', type: 'like',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100&h=100&fit=crop&crop=face',
    name: 'Ngozi', text: 'Ngozi liked your post', timeAgo: '5h ago', isRead: true,
    postImage: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80&h=80&fit=crop',
  },
  {
    id: 'n7', type: 'match',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop&crop=face',
    name: 'Tunde', text: 'You and Tunde matched! 🎉', timeAgo: '1d ago', isRead: true,
  },
  {
    id: 'n8', type: 'system',
    avatar: '', name: 'SparkMatch',
    text: '🔥 Your profile got 3x more views today! Boost it now to get more matches.',
    timeAgo: '1d ago', isRead: true,
  },
  {
    id: 'n9', type: 'like',
    avatar: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=100&h=100&fit=crop&crop=face',
    name: 'Ada', text: 'Ada liked your profile ❤️', timeAgo: '2d ago', isRead: true,
  },
  {
    id: 'n10', type: 'message',
    avatar: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=100&h=100&fit=crop&crop=face',
    name: 'Sade', text: 'Sade sent you a voice note 🎤', timeAgo: '2d ago', isRead: true,
  },
]

// ── Search data (people + posts) ───────────────────────────
export interface SearchPerson {
  id: string
  name: string
  age: number
  avatar: string
  location: string
  isVip?: boolean
  isOnline?: boolean
  mutualInterests?: string[]
}

export const searchPeople: SearchPerson[] = [
  { id: 's1', name: 'Chisom', age: 24, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face', location: 'Lagos', isVip: false, isOnline: true, mutualInterests: ['Travel', 'Music'] },
  { id: 's2', name: 'Fatima', age: 22, avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=100&h=100&fit=crop&crop=face', location: 'Abuja', isVip: true, isOnline: true, mutualInterests: ['Reading'] },
  { id: 's3', name: 'Blessing', age: 26, avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=100&h=100&fit=crop&crop=face', location: 'Port Harcourt', isVip: false, isOnline: false, mutualInterests: ['Art', 'Photography'] },
  { id: 's4', name: 'Kevin', age: 27, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face', location: 'Lagos', isVip: true, isOnline: true, mutualInterests: ['Fitness'] },
  { id: 's5', name: 'Olawale', age: 25, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face', location: 'Lagos', isVip: false, isOnline: false, mutualInterests: [] },
  { id: 's6', name: 'Ngozi', age: 23, avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100&h=100&fit=crop&crop=face', location: 'Enugu', isVip: false, isOnline: true, mutualInterests: ['Cooking', 'Dancing'] },
  { id: 's7', name: 'Tunde', age: 28, avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop&crop=face', location: 'Ibadan', isVip: false, isOnline: false, mutualInterests: ['Sports'] },
  { id: 's8', name: 'Ada', age: 21, avatar: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=100&h=100&fit=crop&crop=face', location: 'Owerri', isVip: false, isOnline: true, mutualInterests: ['Movies', 'Fashion'] },
  { id: 's9', name: 'Sade', age: 24, avatar: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=100&h=100&fit=crop&crop=face', location: 'Lagos', isVip: false, isOnline: false, mutualInterests: ['Music'] },
  { id: 's10', name: 'Amara', age: 25, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face', location: 'Kano', isVip: true, isOnline: true, mutualInterests: ['Travel', 'Food'] },
]

// ── Rich profile data for UserProfileView ─────────────────────────────────
export interface RichProfile {
  id: string
  name: string
  avatar: string
  age: number
  gender: string
  location: string
  bio: string
  interests: string[]
  isVip: boolean
  isOnline: boolean
  distance?: string
  images: string[]
  coverUrl?: string
}

export const richProfileMap: Record<string, RichProfile> = {
  Chisom: {
    id: 'm1', name: 'Chisom', age: 24, gender: 'Female',
    location: 'Lagos, Nigeria', distance: '2 km away',
    bio: 'Love adventures and good vibes ✨ Always down for spontaneous plans, great food, and deep conversations. Let\'s explore Lagos together! 🌆',
    interests: ['Travel ✈️', 'Music 🎵', 'Fitness 💪', 'Food 🍕', 'Dancing 💃', 'Photography 📸'],
    isVip: false, isOnline: true,
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600&h=800&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600&h=800&fit=crop',
      'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=600&h=800&fit=crop',
    ],
    coverUrl: 'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=800&h=300&fit=crop',
  },
  Fatima: {
    id: 'm2', name: 'Fatima', age: 22, gender: 'Female',
    location: 'Abuja, Nigeria', distance: '5 km away',
    bio: 'Medical student by day, foodie by night 🍕 Dog lover 🐶 | Book club member 📚 | Looking for someone to explore Abuja\'s café scene with.',
    interests: ['Reading 📚', 'Cooking 🍳', 'Hiking 🏔️', 'Art 🎨', 'Movies 🎬'],
    isVip: true, isOnline: true,
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=600&h=800&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=600&h=800&fit=crop',
      'https://images.unsplash.com/photo-1502685104226-ee32379fefbe?w=600&h=800&fit=crop',
    ],
    coverUrl: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=800&h=300&fit=crop',
  },
  Blessing: {
    id: 'm3', name: 'Blessing', age: 26, gender: 'Female',
    location: 'Port Harcourt, Nigeria', distance: '8 km away',
    bio: 'Artist & creative soul 🎨 Turning emotions into paintings. Love the sea, sunset walks, and people who make me laugh till my stomach hurts 😂',
    interests: ['Art 🎨', 'Dancing 💃', 'Photography 📸', 'Movies 🎬', 'Travel ✈️'],
    isVip: false, isOnline: false,
    avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=600&h=800&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=600&h=800&fit=crop',
    ],
    coverUrl: 'https://images.unsplash.com/photo-1490750967868-88df5691cc25?w=800&h=300&fit=crop',
  },
  Kevin: {
    id: '2', name: 'Kevin', age: 27, gender: 'Male',
    location: 'Lagos, Nigeria', distance: '3 km away',
    bio: 'Gym is life 💪 New PB every week. Software engineer who unwinds with good music and weekend road trips. Looking for a partner in adventure.',
    interests: ['Fitness 💪', 'Music 🎵', 'Technology 💻', 'Travel ✈️', 'Food 🍕'],
    isVip: true, isOnline: true,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=800&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=800&fit=crop',
    ],
    coverUrl: 'https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=800&h=300&fit=crop',
  },
  Olawale: {
    id: '4', name: 'Olawale', age: 25, gender: 'Male',
    location: 'Lagos, Nigeria', distance: '1 km away',
    bio: 'Bar TB 😂 Just a chill guy who loves his people. Real estate agent by profession, comedian by nature. Life is too short not to laugh.',
    interests: ['Music 🎵', 'Sports ⚽', 'Food 🍕', 'Movies 🎬', 'Gaming 🎮'],
    isVip: false, isOnline: false,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&h=800&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&h=800&fit=crop',
    ],
    coverUrl: 'https://images.unsplash.com/photo-1444927714506-8492d94b4e3d?w=800&h=300&fit=crop',
  },
  Ngozi: {
    id: 'm4', name: 'Ngozi', age: 23, gender: 'Female',
    location: 'Enugu, Nigeria', distance: '12 km away',
    bio: 'Future lawyer ⚖️ | Passionate about justice & culture. I cook, I bake, and I\'ll argue you under the table. Looking for someone with depth.',
    interests: ['Cooking 🍳', 'Dancing 💃', 'Reading 📚', 'Fashion 👗', 'Travel ✈️'],
    isVip: false, isOnline: false,
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&h=800&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&h=800&fit=crop',
    ],
    coverUrl: 'https://images.unsplash.com/photo-1531379410502-63bfe8cdaf6f?w=800&h=300&fit=crop',
  },
}

export function getRichProfile(name: string, fallback: Partial<RichProfile> = {}): RichProfile | null {
  const known = richProfileMap[name]
  if (known) return known
  if (fallback.name) {
    return {
      id: fallback.id || name,
      name: fallback.name,
      avatar: fallback.avatar || '',
      age: fallback.age || 0,
      gender: fallback.gender || '',
      location: fallback.location || '',
      bio: fallback.bio || '',
      interests: fallback.interests || [],
      isVip: fallback.isVip || false,
      isOnline: fallback.isOnline || false,
      distance: fallback.distance,
      images: fallback.images || [],
      coverUrl: fallback.coverUrl,
    }
  }
  return null
}

export const matches: Match[] = [
  {
    id: 'm1',
    name: 'Chisom',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face',
    lastMessage: 'Hey! How are you doing? 😊',
    timeAgo: '2m ago',
    unread: 2,
    isOnline: true,
    isVip: false,
  },
  {
    id: 'm2',
    name: 'Fatima',
    avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=100&h=100&fit=crop&crop=face',
    lastMessage: 'That sounds amazing! Let\'s meet up',
    timeAgo: '1h ago',
    unread: 0,
    isOnline: true,
    isVip: true,
  },
  {
    id: 'm3',
    name: 'Blessing',
    avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=100&h=100&fit=crop&crop=face',
    lastMessage: 'I love that place too! 🎨',
    timeAgo: '3h ago',
    unread: 0,
    isOnline: false,
    isVip: false,
  },
  {
    id: 'm4',
    name: 'Ngozi',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100&h=100&fit=crop&crop=face',
    lastMessage: 'You seem really interesting 😍',
    timeAgo: '1d ago',
    unread: 1,
    isOnline: false,
    isVip: false,
  },
]
