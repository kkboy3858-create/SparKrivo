// ─── Central Privacy & Safety Store ───────────────────────────────────────
import { useState, useCallback } from 'react'

export type MessagePerm = 'everyone' | 'matches' | 'nobody'

export interface PrivacySettings {
  // Messaging
  messagePerm: MessagePerm

  // Visibility toggles
  hideAge: boolean
  hideLocation: boolean
  hideOnlineStatus: boolean
  hideLastSeen: boolean

  // Discovery
  showInDiscovery: boolean
  showInSearch: boolean

  // Content moderation
  aiModeration: boolean          // auto-blur flagged content
  safeContentOnly: boolean       // filter explicit content

  // Story
  storyVisibility: 'everyone' | 'matches' | 'nobody'
  storyReadReceipts: boolean
}

export interface BlockedUser {
  id: string
  name: string
  avatar: string
  blockedAt: number
}

export interface Report {
  id: string
  reportedUserId: string
  reportedUserName: string
  reportedUserAvatar: string
  reason: ReportReason
  detail: string
  submittedAt: number
  status: 'pending' | 'reviewed' | 'resolved'
}

export type ReportReason =
  | 'fake_profile'
  | 'harassment'
  | 'explicit_content'
  | 'spam'
  | 'underage'
  | 'scam'
  | 'hate_speech'
  | 'other'

export const REPORT_REASONS: { id: ReportReason; label: string; icon: string }[] = [
  { id: 'fake_profile',    label: 'Fake profile / Impersonation', icon: '🎭' },
  { id: 'harassment',      label: 'Harassment or bullying',        icon: '😡' },
  { id: 'explicit_content',label: 'Explicit / Inappropriate content', icon: '🔞' },
  { id: 'spam',            label: 'Spam or scam messages',         icon: '📢' },
  { id: 'underage',        label: 'Under 18',                      icon: '⚠️' },
  { id: 'scam',            label: 'Romance scam',                  icon: '💸' },
  { id: 'hate_speech',     label: 'Hate speech or discrimination', icon: '🚫' },
  { id: 'other',           label: 'Other',                         icon: '📝' },
]

// ── AI Content Moderation ──────────────────────────────────────────────────
// Client-side heuristic moderation (replace with real AI API in production)
const FLAGGED_WORDS = [
  'nude', 'naked', 'explicit', 'xxx', 'onlyfans', 'venmo me', 'cash app me',
  'send money', 'wire transfer', 'bitcoin', 'crypto payment', 'click this link',
  'bit.ly', 'tinyurl', 'follow me on', 'i am not real',
]

export interface ModerationResult {
  flagged: boolean
  reason?: string
  severity: 'none' | 'low' | 'medium' | 'high'
  autoBlurred?: boolean
}

export function moderateText(text: string): ModerationResult {
  const lower = text.toLowerCase()
  for (const word of FLAGGED_WORDS) {
    if (lower.includes(word)) {
      const severity = ['nude', 'naked', 'explicit', 'xxx'].includes(word) ? 'high'
        : ['scam', 'send money', 'wire transfer', 'bitcoin'].some(w => lower.includes(w)) ? 'high'
        : 'medium'
      return { flagged: true, reason: `Potentially inappropriate content detected`, severity }
    }
  }
  // Excessive ALL CAPS check
  const capsRatio = (text.match(/[A-Z]/g)?.length ?? 0) / Math.max(text.length, 1)
  if (capsRatio > 0.7 && text.length > 10) {
    return { flagged: true, reason: 'Message appears to be shouting (all caps)', severity: 'low' }
  }
  return { flagged: false, severity: 'none' }
}

export function moderateImage(_url: string): ModerationResult {
  // In production: call vision AI API (e.g. Google Vision SafeSearch)
  // For demo: always passes (0.5% chance of flag for simulation)
  if (Math.random() < 0.05) {
    return { flagged: true, reason: 'Image may contain inappropriate content', severity: 'medium', autoBlurred: true }
  }
  return { flagged: false, severity: 'none' }
}

// ── Hook ───────────────────────────────────────────────────────────────────
export function usePrivacyStore() {
  const [settings, setSettings] = useState<PrivacySettings>({
    messagePerm: 'matches',
    hideAge: false,
    hideLocation: false,
    hideOnlineStatus: false,
    hideLastSeen: false,
    showInDiscovery: true,
    showInSearch: true,
    aiModeration: true,
    safeContentOnly: false,
    storyVisibility: 'everyone',
    storyReadReceipts: true,
  })

  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([
    // seed one blocked user for demo
    {
      id: 'blocked-1',
      name: 'Unknown User',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop&crop=face',
      blockedAt: Date.now() - 86400000 * 3,
    },
  ])

  const [reports, setReports] = useState<Report[]>([])
  const [showPrivacy, setShowPrivacy] = useState(false)

  const updateSetting = useCallback(<K extends keyof PrivacySettings>(
    key: K, value: PrivacySettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }, [])

  const blockUser = useCallback((user: { id: string; name: string; avatar: string }) => {
    setBlockedUsers(prev => {
      if (prev.find(b => b.id === user.id)) return prev
      return [{ ...user, blockedAt: Date.now() }, ...prev]
    })
  }, [])

  const unblockUser = useCallback((userId: string) => {
    setBlockedUsers(prev => prev.filter(b => b.id !== userId))
  }, [])

  const isBlocked = useCallback((userId: string) => {
    return blockedUsers.some(b => b.id === userId)
  }, [blockedUsers])

  const submitReport = useCallback((
    reportedUser: { id: string; name: string; avatar: string },
    reason: ReportReason,
    detail: string
  ) => {
    const report: Report = {
      id: `rpt-${Date.now()}`,
      reportedUserId: reportedUser.id,
      reportedUserName: reportedUser.name,
      reportedUserAvatar: reportedUser.avatar,
      reason,
      detail,
      submittedAt: Date.now(),
      status: 'pending',
    }
    setReports(prev => [report, ...prev])
    return report
  }, [])

  const canMessage = useCallback((isMatch: boolean): boolean => {
    if (settings.messagePerm === 'nobody') return false
    if (settings.messagePerm === 'matches' && !isMatch) return false
    return true
  }, [settings.messagePerm])

  return {
    settings,
    blockedUsers,
    reports,
    showPrivacy,
    setShowPrivacy,
    updateSetting,
    blockUser,
    unblockUser,
    isBlocked,
    submitReport,
    canMessage,
  }
}
