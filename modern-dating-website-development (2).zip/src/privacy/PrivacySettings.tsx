import { useState } from 'react'
import type { PrivacySettings, BlockedUser, Report, MessagePerm } from './privacyStore'
import { format } from 'date-fns'

interface Props {
  settings: PrivacySettings
  blockedUsers: BlockedUser[]
  reports: Report[]
  onUpdate: <K extends keyof PrivacySettings>(key: K, value: PrivacySettings[K]) => void
  onUnblock: (userId: string) => void
  onClose: () => void
}

type Tab = 'privacy' | 'safety' | 'blocked' | 'reports'

export function PrivacySettingsPanel({ settings, blockedUsers, reports, onUpdate, onUnblock, onClose }: Props) {
  const [tab, setTab] = useState<Tab>('privacy')
  const [unblockConfirm, setUnblockConfirm] = useState<string | null>(null)

  const tabs: { id: Tab; label: string; icon: string }[] = [
    { id: 'privacy',  label: 'Privacy',  icon: '🔒' },
    { id: 'safety',   label: 'Safety',   icon: '🛡️' },
    { id: 'blocked',  label: 'Blocked',  icon: '🚫' },
    { id: 'reports',  label: 'Reports',  icon: '📋' },
  ]

  return (
    <div className="absolute inset-0 z-[80] flex flex-col bg-white animate-slide-up">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-4 border-b border-gray-100">
        <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform text-gray-500">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <div>
          <h2 className="font-bold text-gray-900 text-lg leading-tight">Privacy & Safety</h2>
          <p className="text-xs text-gray-400">Control who sees you and how you're contacted</p>
        </div>
        {/* Shield badge */}
        <div className="ml-auto w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
        </div>
      </div>

      {/* Tab bar */}
      <div className="flex-shrink-0 flex border-b border-gray-100">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 flex flex-col items-center gap-0.5 py-2.5 text-[10px] font-bold transition-colors border-b-2 ${
              tab === t.id ? 'text-[#ff4d6d] border-[#ff4d6d]' : 'text-gray-400 border-transparent'
            }`}
          >
            <span className="text-base">{t.icon}</span>
            {t.label}
            {t.id === 'blocked' && blockedUsers.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-red-100 text-red-600 text-[9px] font-bold -mt-0.5">
                {blockedUsers.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">

        {/* ── PRIVACY TAB ── */}
        {tab === 'privacy' && (
          <div className="px-4 py-4 space-y-6">

            {/* Messaging control */}
            <Section title="Messaging" icon="💬" desc="Control who can send you messages">
              {(['everyone', 'matches', 'nobody'] as MessagePerm[]).map(opt => (
                <SelectRow
                  key={opt}
                  selected={settings.messagePerm === opt}
                  onClick={() => onUpdate('messagePerm', opt)}
                  label={opt === 'everyone' ? 'Everyone' : opt === 'matches' ? 'Matches Only' : 'Nobody'}
                  sub={
                    opt === 'everyone' ? 'Any user can message you' :
                    opt === 'matches'  ? 'Only mutual matches can message you (recommended)' :
                    'No one can send you messages'
                  }
                  icon={opt === 'everyone' ? '🌍' : opt === 'matches' ? '💕' : '🔇'}
                />
              ))}
            </Section>

            {/* Profile visibility */}
            <Section title="Profile Visibility" icon="👁️" desc="Control what others see on your profile">
              <ToggleRow
                label="Hide my age"
                sub="Your age won't be shown on your profile"
                value={settings.hideAge}
                onChange={v => onUpdate('hideAge', v)}
                icon="🎂"
              />
              <ToggleRow
                label="Hide my location"
                sub="Others won't see your city or distance"
                value={settings.hideLocation}
                onChange={v => onUpdate('hideLocation', v)}
                icon="📍"
              />
              <ToggleRow
                label="Hide online status"
                sub="Others can't see when you're online"
                value={settings.hideOnlineStatus}
                onChange={v => onUpdate('hideOnlineStatus', v)}
                icon="🟢"
              />
              <ToggleRow
                label="Hide last seen"
                sub="Others won't see when you were last active"
                value={settings.hideLastSeen}
                onChange={v => onUpdate('hideLastSeen', v)}
                icon="⏰"
              />
            </Section>

            {/* Discovery */}
            <Section title="Discovery" icon="🔍" desc="Control how you appear in searches">
              <ToggleRow
                label="Show me in Discover"
                sub="Your profile appears in the swipe feed"
                value={settings.showInDiscovery}
                onChange={v => onUpdate('showInDiscovery', v)}
                icon="💫"
              />
              <ToggleRow
                label="Appear in search results"
                sub="Others can find your profile by name"
                value={settings.showInSearch}
                onChange={v => onUpdate('showInSearch', v)}
                icon="🔎"
              />
            </Section>

            {/* Story privacy */}
            <Section title="Story Privacy" icon="📖" desc="Who can view your stories">
              {(['everyone', 'matches', 'nobody'] as const).map(opt => (
                <SelectRow
                  key={opt}
                  selected={settings.storyVisibility === opt}
                  onClick={() => onUpdate('storyVisibility', opt)}
                  label={opt === 'everyone' ? 'Everyone' : opt === 'matches' ? 'Matches Only' : 'Nobody'}
                  sub={opt === 'everyone' ? 'Any user can watch your story' : opt === 'matches' ? 'Only your matches' : 'No one sees your story'}
                  icon={opt === 'everyone' ? '🌍' : opt === 'matches' ? '💕' : '🙈'}
                />
              ))}
              <ToggleRow
                label="Story read receipts"
                sub="Let people know you've viewed their story"
                value={settings.storyReadReceipts}
                onChange={v => onUpdate('storyReadReceipts', v)}
                icon="👀"
              />
            </Section>
          </div>
        )}

        {/* ── SAFETY TAB ── */}
        {tab === 'safety' && (
          <div className="px-4 py-4 space-y-6">

            {/* AI Moderation */}
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl p-4 border border-emerald-100">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center text-xl">🤖</div>
                <div>
                  <h3 className="font-bold text-gray-900 text-sm">AI Content Moderation</h3>
                  <p className="text-xs text-gray-500">Powered by smart content analysis</p>
                </div>
                <Toggle value={settings.aiModeration} onChange={v => onUpdate('aiModeration', v)} />
              </div>
              <ul className="space-y-1.5">
                {[
                  'Automatically flags harmful messages',
                  'Detects scam & phishing attempts',
                  'Blurs potentially explicit images',
                  'Warns before sending risky content',
                ].map(f => (
                  <li key={f} className="flex items-center gap-2 text-xs text-gray-600">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    {f}
                  </li>
                ))}
              </ul>
            </div>

            <Section title="Content Filtering" icon="🛡️" desc="Control what content you see">
              <ToggleRow
                label="Safe content only"
                sub="Automatically filter explicit or mature content"
                value={settings.safeContentOnly}
                onChange={v => onUpdate('safeContentOnly', v)}
                icon="🔞"
              />
            </Section>

            {/* Safety tips */}
            <Section title="Safety Tips" icon="💡" desc="Stay safe while connecting">
              {[
                { icon: '🚫', title: 'Never share financial info', desc: 'Don\'t send money or share bank details with anyone you\'ve just met.' },
                { icon: '📞', title: 'Video chat first', desc: 'Verify someone\'s identity with a video call before meeting in person.' },
                { icon: '📍', title: 'Meet in public', desc: 'Always meet a new person in a busy public place for your first date.' },
                { icon: '🔗', title: 'Don\'t click unknown links', desc: 'Scammers often send links to fake websites to steal your information.' },
                { icon: '📢', title: 'Report suspicious behaviour', desc: 'Use the Report button on any profile or message that makes you uncomfortable.' },
              ].map(tip => (
                <div key={tip.title} className="flex items-start gap-3 py-2.5 border-b border-gray-50 last:border-0">
                  <span className="text-xl flex-shrink-0 mt-0.5">{tip.icon}</span>
                  <div>
                    <p className="font-semibold text-gray-800 text-sm">{tip.title}</p>
                    <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">{tip.desc}</p>
                  </div>
                </div>
              ))}
            </Section>

            {/* Emergency */}
            <div className="bg-red-50 border border-red-100 rounded-2xl p-4">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-2xl">🆘</span>
                <div>
                  <h3 className="font-bold text-red-700 text-sm">Emergency Support</h3>
                  <p className="text-xs text-red-500">If you feel unsafe or threatened</p>
                </div>
              </div>
              <button
                className="w-full py-2.5 bg-red-500 text-white text-sm font-bold rounded-xl active:scale-[0.98] transition-transform"
                onClick={() => alert('In a real app, this would connect you to our 24/7 safety team.')}
              >
                Contact Safety Team
              </button>
            </div>
          </div>
        )}

        {/* ── BLOCKED TAB ── */}
        {tab === 'blocked' && (
          <div className="px-4 py-4">
            {blockedUsers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="text-5xl mb-4">🙌</div>
                <h3 className="font-bold text-gray-800 mb-1">No blocked users</h3>
                <p className="text-sm text-gray-400">Users you block will appear here</p>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-xs text-gray-400 font-medium mb-3">
                  Blocked users can't see your profile, message you, or find you in search.
                </p>
                {blockedUsers.map(u => (
                  <div key={u.id} className="flex items-center gap-3 bg-gray-50 rounded-2xl px-4 py-3">
                    <img src={u.avatar} alt={u.name} className="w-12 h-12 rounded-full object-cover flex-shrink-0 grayscale opacity-60" />
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-gray-700 text-sm">{u.name}</p>
                      <p className="text-xs text-gray-400">Blocked {format(new Date(u.blockedAt), 'MMM d, yyyy')}</p>
                    </div>
                    {unblockConfirm === u.id ? (
                      <div className="flex gap-2">
                        <button
                          onClick={() => { onUnblock(u.id); setUnblockConfirm(null) }}
                          className="px-3 py-1.5 bg-emerald-500 text-white text-xs font-bold rounded-full active:scale-95 transition-transform"
                        >
                          Confirm
                        </button>
                        <button
                          onClick={() => setUnblockConfirm(null)}
                          className="px-3 py-1.5 bg-gray-200 text-gray-600 text-xs font-bold rounded-full active:scale-95 transition-transform"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setUnblockConfirm(u.id)}
                        className="px-3 py-1.5 border border-gray-300 text-gray-600 text-xs font-semibold rounded-full active:scale-95 transition-transform"
                      >
                        Unblock
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── REPORTS TAB ── */}
        {tab === 'reports' && (
          <div className="px-4 py-4">
            {reports.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="text-5xl mb-4">📋</div>
                <h3 className="font-bold text-gray-800 mb-1">No reports submitted</h3>
                <p className="text-sm text-gray-400">Reports you submit will appear here</p>
              </div>
            ) : (
              <div className="space-y-3">
                {reports.map(r => (
                  <div key={r.id} className="bg-gray-50 rounded-2xl p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <img src={r.reportedUserAvatar} alt={r.reportedUserName} className="w-10 h-10 rounded-full object-cover grayscale opacity-70" />
                      <div className="flex-1">
                        <p className="font-bold text-gray-800 text-sm">{r.reportedUserName}</p>
                        <p className="text-xs text-gray-400">{format(new Date(r.submittedAt), 'MMM d, yyyy HH:mm')}</p>
                      </div>
                      <StatusBadge status={r.status} />
                    </div>
                    <p className="text-xs text-gray-600 bg-white rounded-xl px-3 py-2">{r.detail || 'No additional details provided.'}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

/* ── Report Flow ────────────────────────────────────────────────── */
interface ReportFlowProps {
  user: { id: string; name: string; avatar: string }
  onSubmit: (reason: import('./privacyStore').ReportReason, detail: string) => void
  onClose: () => void
}

export function ReportFlow({ user, onSubmit, onClose }: ReportFlowProps) {
  const { REPORT_REASONS } = require('./privacyStore') as typeof import('./privacyStore')
  const [step, setStep] = useState<'reason' | 'detail' | 'done'>('reason')
  const [selectedReason, setSelectedReason] = useState<import('./privacyStore').ReportReason | null>(null)
  const [detail, setDetail] = useState('')

  const handleSubmit = () => {
    if (!selectedReason) return
    onSubmit(selectedReason, detail.trim())
    setStep('done')
  }

  return (
    <div className="absolute inset-0 z-[90] flex flex-col bg-white animate-slide-up">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-4 border-b border-gray-100">
        {step !== 'done' ? (
          <button onClick={step === 'detail' ? () => setStep('reason') : onClose}
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-500">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>
        ) : <div className="w-9" />}
        <h2 className="font-bold text-gray-900">Report {user.name}</h2>
        <button onClick={onClose} className="ml-auto w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-400">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        {step === 'reason' && (
          <>
            <div className="flex items-center gap-3 mb-5">
              <img src={user.avatar} alt={user.name} className="w-12 h-12 rounded-full object-cover" />
              <div>
                <p className="font-bold text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500">Why are you reporting this user?</p>
              </div>
            </div>
            <div className="space-y-2">
              {REPORT_REASONS.map(r => (
                <button
                  key={r.id}
                  onClick={() => { setSelectedReason(r.id); setStep('detail') }}
                  className="w-full flex items-center gap-4 px-4 py-3.5 bg-gray-50 rounded-2xl hover:bg-rose-50 active:scale-[0.98] transition-all text-left"
                >
                  <span className="text-xl">{r.icon}</span>
                  <span className="font-semibold text-gray-800 text-sm flex-1">{r.label}</span>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="9 18 15 12 9 6"/>
                  </svg>
                </button>
              ))}
            </div>
          </>
        )}

        {step === 'detail' && (
          <div className="space-y-4">
            <div className="bg-rose-50 rounded-2xl p-4 flex items-center gap-3">
              <span className="text-2xl">{REPORT_REASONS.find(r => r.id === selectedReason)?.icon}</span>
              <p className="font-semibold text-rose-800 text-sm">{REPORT_REASONS.find(r => r.id === selectedReason)?.label}</p>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">
                Additional details (optional)
              </label>
              <textarea
                value={detail}
                onChange={e => setDetail(e.target.value)}
                placeholder="Describe what happened…"
                rows={5}
                maxLength={500}
                className="w-full px-4 py-3 bg-gray-50 rounded-xl text-sm text-gray-700 outline-none border border-gray-200 focus:border-[#ff4d6d] resize-none transition-colors"
              />
              <p className="text-right text-xs text-gray-400 mt-1">{detail.length}/500</p>
            </div>
            <div className="bg-amber-50 border border-amber-100 rounded-2xl p-3">
              <p className="text-xs text-amber-700 leading-relaxed">
                ⚠️ False reports may result in action against your account. Our team reviews all reports within 24 hours.
              </p>
            </div>
            <button
              onClick={handleSubmit}
              className="w-full py-3.5 rounded-full text-white font-bold active:scale-95 transition-transform"
              style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
            >
              Submit Report
            </button>
          </div>
        )}

        {step === 'done' && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center text-4xl mb-5">✅</div>
            <h3 className="font-bold text-gray-900 text-xl mb-2">Report Submitted</h3>
            <p className="text-gray-500 text-sm max-w-xs leading-relaxed mb-6">
              Thank you for keeping SparkMatch safe. Our safety team will review your report within 24 hours.
            </p>
            <button
              onClick={onClose}
              className="px-8 py-3 rounded-full text-white font-bold active:scale-95 transition-transform"
              style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

/* ── Block Confirm Sheet ─────────────────────────────────────────── */
interface BlockConfirmProps {
  user: { id: string; name: string; avatar: string }
  onBlock: () => void
  onClose: () => void
}

export function BlockConfirmSheet({ user, onBlock, onClose }: BlockConfirmProps) {
  return (
    <div className="absolute inset-x-0 bottom-0 z-[90] animate-slide-up">
      <div className="bg-white rounded-t-3xl px-5 pt-5 pb-10 shadow-2xl">
        <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-5" />
        <div className="flex flex-col items-center text-center mb-6">
          <img src={user.avatar} alt={user.name} className="w-20 h-20 rounded-full object-cover mb-3 grayscale opacity-60" />
          <h3 className="font-bold text-gray-900 text-xl">Block {user.name}?</h3>
          <p className="text-gray-500 text-sm mt-2 leading-relaxed max-w-xs">
            They won't be able to see your profile, send you messages, or find you in search. They won't be notified.
          </p>
        </div>
        <div className="space-y-2.5">
          {[
            '✅ They can\'t message you anymore',
            '✅ They disappear from your matches',
            '✅ They can\'t see your profile',
            '✅ They\'re not notified',
          ].map(p => (
            <p key={p} className="text-sm text-gray-600">{p}</p>
          ))}
        </div>
        <button
          onClick={() => { onBlock(); onClose() }}
          className="w-full mt-6 py-3.5 bg-red-500 text-white font-bold rounded-full active:scale-95 transition-transform"
        >
          Block {user.name}
        </button>
        <button
          onClick={onClose}
          className="w-full mt-2.5 py-3 text-gray-600 font-semibold text-sm active:scale-95 transition-transform"
        >
          Cancel
        </button>
      </div>
    </div>
  )
}

/* ── AI Moderation Warning ────────────────────────────────────────── */
interface ModerationWarningProps {
  reason: string
  severity: 'low' | 'medium' | 'high'
  onSendAnyway: () => void
  onCancel: () => void
}

export function ModerationWarning({ reason, severity, onSendAnyway, onCancel }: ModerationWarningProps) {
  const bg = severity === 'high' ? 'bg-red-50 border-red-200' : severity === 'medium' ? 'bg-amber-50 border-amber-200' : 'bg-yellow-50 border-yellow-200'
  const icon = severity === 'high' ? '🚫' : severity === 'medium' ? '⚠️' : '💡'
  const color = severity === 'high' ? 'text-red-700' : severity === 'medium' ? 'text-amber-700' : 'text-yellow-700'

  return (
    <div className="absolute inset-x-0 bottom-0 z-[90] animate-slide-up">
      <div className="bg-white rounded-t-3xl px-5 pt-5 pb-10 shadow-2xl">
        <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-5" />
        <div className={`rounded-2xl p-4 border mb-5 ${bg}`}>
          <div className="flex items-start gap-3">
            <span className="text-2xl">{icon}</span>
            <div>
              <h3 className={`font-bold text-sm mb-1 ${color}`}>AI Moderation Alert</h3>
              <p className={`text-sm ${color}`}>{reason}</p>
            </div>
          </div>
        </div>
        <p className="text-sm text-gray-500 mb-5 leading-relaxed">
          Our AI flagged your content. Sending harmful content may result in account suspension.
        </p>
        <div className="space-y-2.5">
          {severity !== 'high' && (
            <button
              onClick={onSendAnyway}
              className="w-full py-3 border-2 border-gray-200 text-gray-700 font-semibold rounded-full active:scale-95 transition-transform text-sm"
            >
              Send anyway
            </button>
          )}
          <button
            onClick={onCancel}
            className="w-full py-3.5 text-white font-bold rounded-full active:scale-95 transition-transform"
            style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
          >
            Edit message
          </button>
        </div>
      </div>
    </div>
  )
}

/* ── User Profile Options Sheet ─────────────────────────────────── */
interface UserOptionsProps {
  user: { id: string; name: string; avatar: string }
  isBlocked: boolean
  onBlock: () => void
  onReport: () => void
  onClose: () => void
}

export function UserOptionsSheet({ user, isBlocked, onBlock, onReport, onClose }: UserOptionsProps) {
  return (
    <div
      className="absolute inset-0 z-[85] flex flex-col justify-end bg-black/40"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-t-3xl px-5 pt-4 pb-10 animate-slide-up"
        onClick={e => e.stopPropagation()}
      >
        <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-4" />
        <div className="flex items-center gap-3 mb-5">
          <img src={user.avatar} alt={user.name} className="w-12 h-12 rounded-full object-cover" />
          <div>
            <p className="font-bold text-gray-900">{user.name}</p>
            <p className="text-xs text-gray-400">Profile actions</p>
          </div>
        </div>
        <div className="space-y-2">
          <OptionBtn
            emoji={isBlocked ? '✅' : '🚫'}
            label={isBlocked ? `Unblock ${user.name}` : `Block ${user.name}`}
            sub={isBlocked ? 'Allow this user to contact you again' : 'They won\'t be able to message or see you'}
            danger={!isBlocked}
            onClick={onBlock}
          />
          <OptionBtn
            emoji="🚩"
            label={`Report ${user.name}`}
            sub="Let us know about any harmful behaviour"
            danger
            onClick={onReport}
          />
          <OptionBtn
            emoji="❌"
            label="Cancel"
            sub=""
            onClick={onClose}
          />
        </div>
      </div>
    </div>
  )
}

/* ── Small reusable pieces ──────────────────────────────────────── */
function Section({ title, icon, desc, children }: { title: string; icon: string; desc: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-1">
        <span className="text-base">{icon}</span>
        <h3 className="font-bold text-gray-800 text-sm">{title}</h3>
      </div>
      <p className="text-xs text-gray-400 mb-3 pl-6">{desc}</p>
      <div className="bg-gray-50 rounded-2xl overflow-hidden divide-y divide-gray-100">
        {children}
      </div>
    </div>
  )
}

function ToggleRow({ label, sub, value, onChange, icon }: { label: string; sub: string; value: boolean; onChange: (v: boolean) => void; icon: string }) {
  return (
    <div className="flex items-center gap-3 px-4 py-3.5">
      <span className="text-lg flex-shrink-0">{icon}</span>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-gray-800 text-sm">{label}</p>
        <p className="text-xs text-gray-400 leading-snug">{sub}</p>
      </div>
      <Toggle value={value} onChange={onChange} />
    </div>
  )
}

function SelectRow({ selected, onClick, label, sub, icon }: { selected: boolean; onClick: () => void; label: string; sub: string; icon: string }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3.5 transition-colors ${selected ? 'bg-rose-50' : ''}`}
    >
      <span className="text-lg flex-shrink-0">{icon}</span>
      <div className="flex-1 text-left">
        <p className={`font-semibold text-sm ${selected ? 'text-[#ff4d6d]' : 'text-gray-800'}`}>{label}</p>
        <p className="text-xs text-gray-400">{sub}</p>
      </div>
      {selected && (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ff4d6d" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
      )}
    </button>
  )
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`relative w-12 h-6 rounded-full flex-shrink-0 transition-colors duration-200 ${value ? 'bg-[#ff4d6d]' : 'bg-gray-300'}`}
    >
      <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform duration-200 ${value ? 'translate-x-6' : 'translate-x-0.5'}`} />
    </button>
  )
}

function OptionBtn({ emoji, label, sub, danger, onClick }: { emoji: string; label: string; sub: string; danger?: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl active:scale-[0.98] transition-all ${danger ? 'bg-red-50' : 'bg-gray-50 hover:bg-gray-100'}`}
    >
      <span className="text-xl w-7 text-center">{emoji}</span>
      <div className="flex-1 text-left">
        <p className={`font-bold text-sm ${danger ? 'text-red-600' : 'text-gray-800'}`}>{label}</p>
        {sub && <p className="text-xs text-gray-400">{sub}</p>}
      </div>
    </button>
  )
}

function StatusBadge({ status }: { status: Report['status'] }) {
  const c = status === 'resolved' ? 'bg-emerald-100 text-emerald-700'
    : status === 'reviewed' ? 'bg-blue-100 text-blue-700'
    : 'bg-amber-100 text-amber-700'
  const l = status === 'resolved' ? '✓ Resolved' : status === 'reviewed' ? '👁 Reviewed' : '⏳ Pending'
  return <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${c}`}>{l}</span>
}
