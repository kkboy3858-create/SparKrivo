

interface Props {
  waveform: number[]    // 0-1 amplitudes
  progress: number      // 0-1 playback progress
  color?: string
  bgColor?: string
}

export function WaveformBars({ waveform, progress, color = '#fff', bgColor = 'rgba(255,255,255,0.35)' }: Props) {
  const bars = waveform.length > 0 ? waveform : Array.from({ length: 30 }, () => 0.3 + Math.random() * 0.5)
  const filled = Math.round(progress * bars.length)

  return (
    <div className="flex items-center gap-[2px]" style={{ height: 28 }}>
      {bars.map((amp, i) => (
        <div
          key={i}
          style={{
            width: 3,
            height: Math.max(4, amp * 28),
            borderRadius: 2,
            background: i < filled ? color : bgColor,
            transition: 'height 0.1s ease',
          }}
        />
      ))}
    </div>
  )
}

interface LiveProps {
  waveform: number[]
  color?: string
}

export function LiveWaveform({ waveform, color = '#ff4d6d' }: LiveProps) {
  const display = waveform.slice(-40)
  while (display.length < 40) display.unshift(0.1)
  return (
    <div className="flex items-center gap-[2px]" style={{ height: 30 }}>
      {display.map((amp, i) => (
        <div
          key={i}
          style={{
            width: 3,
            height: Math.max(4, amp * 30),
            borderRadius: 2,
            background: color,
            opacity: 0.4 + (i / display.length) * 0.6,
            transition: 'height 0.08s ease',
          }}
        />
      ))}
    </div>
  )
}
