import type { ReplyTo } from '../types'

interface Props {
  replyTo: ReplyTo
  onCancel?: () => void
  isMe?: boolean
}

export function ReplyBanner({ replyTo, onCancel, isMe }: Props) {
  return (
    <div
      className={`flex items-center gap-2 px-3 py-1.5 rounded-xl mb-1 text-xs ${
        isMe
          ? 'bg-white/20'
          : 'bg-gray-100'
      }`}
    >
      <div className={`w-0.5 h-8 rounded-full flex-shrink-0 ${isMe ? 'bg-white/60' : 'bg-[#ff4d6d]'}`} />
      <div className="flex-1 min-w-0">
        <p className={`font-bold truncate ${isMe ? 'text-white/90' : 'text-[#ff4d6d]'}`}>{replyTo.senderName}</p>
        <p className={`truncate ${isMe ? 'text-white/70' : 'text-gray-500'}`}>{replyTo.preview}</p>
      </div>
      {onCancel && (
        <button onClick={onCancel} className="text-gray-400 flex-shrink-0">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      )}
    </div>
  )
}
