import { useState, useRef, useEffect } from 'react'
import { WaveformBars } from './WaveformBars'

interface Props {
  url: string
  duration?: number
  waveform?: number[]
  isMe: boolean
}

export function VoiceMessageBubble({ url, duration = 0, waveform = [], isMe }: Props) {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [elapsed, setElapsed] = useState(0)
  const [speed, setSpeed] = useState(1)

  const togglePlay = () => {
    const audio = audioRef.current
    if (!audio) return
    if (playing) {
      audio.pause()
    } else {
      audio.playbackRate = speed
      audio.play().catch(() => {})
    }
  }

  const cycleSpeed = (e: React.MouseEvent) => {
    e.stopPropagation()
    const next = speed === 1 ? 1.5 : speed === 1.5 ? 2 : 1
    setSpeed(next)
    if (audioRef.current) audioRef.current.playbackRate = next
  }

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return
    const onPlay = () => setPlaying(true)
    const onPause = () => setPlaying(false)
    const onEnded = () => { setPlaying(false); setProgress(0); setElapsed(0) }
    const onTimeUpdate = () => {
      if (audio.duration) {
        setProgress(audio.currentTime / audio.duration)
        setElapsed(Math.floor(audio.currentTime))
      }
    }
    audio.addEventListener('play', onPlay)
    audio.addEventListener('pause', onPause)
    audio.addEventListener('ended', onEnded)
    audio.addEventListener('timeupdate', onTimeUpdate)
    return () => {
      audio.removeEventListener('play', onPlay)
      audio.removeEventListener('pause', onPause)
      audio.removeEventListener('ended', onEnded)
      audio.removeEventListener('timeupdate', onTimeUpdate)
    }
  }, [])

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
  const totalSecs = duration > 0 ? Math.floor(duration) : 0
  const displayTime = playing ? fmt(elapsed) : fmt(totalSecs)

  const bars = waveform.length >= 20 ? waveform : Array.from({ length: 30 }, (_, i) => 0.2 + Math.sin(i * 0.4) * 0.3 + Math.random() * 0.3)

  return (
    <div
      className={`flex items-center gap-2.5 px-3 py-2.5 rounded-2xl min-w-[190px] max-w-[250px] ${
        isMe ? 'rounded-br-sm' : 'rounded-bl-sm bg-white shadow-sm'
      }`}
      style={isMe ? { background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' } : {}}
    >
      <audio ref={audioRef} src={url} preload="metadata" />

      {/* Play/pause button */}
      <button
        onClick={togglePlay}
        className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-transform active:scale-90 ${
          isMe ? 'bg-white/20' : 'bg-[#ff4d6d]'
        }`}
      >
        {playing ? (
          <svg width="14" height="14" viewBox="0 0 24 24" fill={isMe ? 'white' : 'white'}>
            <rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>
          </svg>
        ) : (
          <svg width="14" height="14" viewBox="0 0 24 24" fill={isMe ? 'white' : 'white'} style={{ marginLeft: 2 }}>
            <polygon points="5 3 19 12 5 21 5 3"/>
          </svg>
        )}
      </button>

      {/* Waveform + time */}
      <div className="flex-1 flex flex-col gap-1 overflow-hidden">
        <WaveformBars
          waveform={bars}
          progress={progress}
          color={isMe ? 'white' : '#ff4d6d'}
          bgColor={isMe ? 'rgba(255,255,255,0.3)' : '#ffd6df'}
        />
        <div className="flex items-center justify-between">
          <span className={`text-[10px] font-medium ${isMe ? 'text-white/80' : 'text-gray-400'}`}>{displayTime}</span>
          <button
            onClick={cycleSpeed}
            className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
              isMe ? 'bg-white/20 text-white' : 'bg-rose-50 text-[#ff4d6d]'
            }`}
          >
            {speed}x
          </button>
        </div>
      </div>
    </div>
  )
}
