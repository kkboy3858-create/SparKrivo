import { useState, useRef } from 'react'
import { PRESET_WALLPAPERS, resolveWallpaperCss, type Wallpaper } from './wallpapers'

interface Props {
  matchName: string
  currentId: string | null
  currentCustomUrl: string | null
  onSelect: (wallpaperId: string | null, customUrl: string | null) => void
  onClose: () => void
}

const TABS = ['Gradients', 'Photos', 'My photo'] as const
type Tab = typeof TABS[number]

const GRADIENT_WALLPAPERS = PRESET_WALLPAPERS.filter(w => w.type === 'gradient' || w.type === 'pattern')
const IMAGE_WALLPAPERS    = PRESET_WALLPAPERS.filter(w => w.type === 'image')

// ── Thumbnail renders the actual CSS background for gradients ────────────────
function WallpaperThumb({
  wp, selected, onClick,
}: { wp: Wallpaper; selected: boolean; onClick: () => void }) {

  // Build the CSS for the thumbnail — always use `background` shorthand
  let bgStyle: React.CSSProperties = {}
  if (wp.type === 'image' && wp.thumb) {
    // Photo preset: use thumbnail URL
    bgStyle = {
      backgroundImage: `url("${wp.thumb}")`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
    }
  } else if (wp.css) {
    // Gradient/pattern: the css field IS a valid `background` shorthand
    bgStyle = { background: wp.css }
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className="relative rounded-2xl overflow-hidden active:scale-95 transition-all"
      style={{
        ...bgStyle,
        aspectRatio: '9/16',
        width: '100%',
        outline: selected ? '3px solid #ff4d6d' : '2px solid transparent',
        outlineOffset: selected ? '2px' : '0',
        boxShadow: selected
          ? '0 0 0 4px rgba(255,77,109,0.2), 0 4px 12px rgba(0,0,0,0.15)'
          : '0 2px 8px rgba(0,0,0,0.12)',
      }}
    >
      {/* Darken very light gradients slightly so label is readable */}
      <div className="absolute inset-0 bg-black/10 pointer-events-none" />
      {/* Label bar */}
      <div
        className="absolute bottom-0 left-0 right-0 px-1.5 py-1.5"
        style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.6), transparent)' }}
      >
        <p className="text-white text-[9px] font-bold text-center truncate leading-tight">{wp.label}</p>
      </div>
      {/* Selected checkmark */}
      {selected && (
        <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-[#ff4d6d] flex items-center justify-center shadow">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>
      )}
    </button>
  )
}

// ── Resolve preview background from current selection state ──────────────────
function getPreviewBg(id: string | null, customUrl: string | null): string {
  const { backgroundCss } = resolveWallpaperCss(id, customUrl)
  return backgroundCss
}

// ── Main component ────────────────────────────────────────────────────────────
export default function WallpaperPicker({ matchName, currentId, currentCustomUrl, onSelect, onClose }: Props) {
  const [tab, setTab] = useState<Tab>('Gradients')

  // Selected wallpaper state (preview only — not applied until Apply tapped)
  const [selId,        setSelId]        = useState<string | null>(currentId)
  const [selCustomUrl, setSelCustomUrl] = useState<string | null>(currentCustomUrl)

  const fileInputRef = useRef<HTMLInputElement>(null)

  // Compute live preview background
  const previewBg = getPreviewBg(selId, selCustomUrl)

  const pickPreset = (id: string) => {
    setSelId(id)
    setSelCustomUrl(null)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const url = URL.createObjectURL(file)
    setSelId(null)
    setSelCustomUrl(url)
    setTab('My photo')
    e.target.value = ''
  }

  const handleApply = () => {
    onSelect(selId, selCustomUrl)
    onClose()
  }

  const handleClear = () => {
    onSelect('default', null)
    onClose()
  }

  const hasWallpaper = (currentId && currentId !== 'default') || !!currentCustomUrl

  return (
    <div
      className="absolute inset-0 z-[250] flex flex-col"
      style={{ background: 'var(--color-bg)', animation: 'slideDownPanel 0.28s cubic-bezier(0.34,1.2,0.64,1) forwards' }}
    >
      {/* ── Header ── */}
      <div
        className="flex-shrink-0 flex items-center gap-3 px-4 py-3.5"
        style={{ background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }}
      >
        <button
          type="button"
          onClick={onClose}
          className="w-9 h-9 flex items-center justify-center rounded-full active:scale-90 transition-transform flex-shrink-0"
          style={{ background: 'var(--color-bg-tertiary)' }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--color-text-secondary)' }}>
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <div className="flex-1 min-w-0">
          <h2 className="font-bold text-base leading-tight" style={{ color: 'var(--color-text)' }}>Chat Wallpaper</h2>
          <p className="text-xs truncate" style={{ color: 'var(--color-text-secondary)' }}>Personalise your chat with {matchName}</p>
        </div>
        <button
          type="button"
          onClick={handleApply}
          className="flex-shrink-0 px-4 py-2 rounded-full text-white text-sm font-bold active:scale-95 transition-transform"
          style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
        >
          Apply ✓
        </button>
      </div>

      {/* ── Live preview ── */}
      <div
        className="flex-shrink-0 flex flex-col justify-end gap-2 px-4 pb-4 pt-3"
        style={{
          height: 150,
          // Use the backgroundCss string as `background` shorthand — handles both gradients and images
          background: previewBg,
          position: 'relative',
          flexShrink: 0,
        }}
      >
        {/* Scrim */}
        <div className="absolute inset-0 bg-black/10 pointer-events-none" />
        {/* Sample bubbles */}
        <div className="relative z-10 flex flex-col gap-2">
          <div className="flex justify-start">
            <div
              className="px-3.5 py-2 rounded-2xl rounded-bl-sm text-[13px] font-medium max-w-[70%]"
              style={{ background: 'rgba(255,255,255,0.92)', color: '#1f2937', boxShadow: '0 1px 6px rgba(0,0,0,0.15)', backdropFilter: 'blur(6px)' }}
            >
              Hey! 👋 How's your day?
            </div>
          </div>
          <div className="flex justify-end">
            <div
              className="px-3.5 py-2 rounded-2xl rounded-br-sm text-[13px] font-medium text-white max-w-[70%]"
              style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)', boxShadow: '0 1px 6px rgba(255,77,109,0.3)' }}
            >
              Amazing! I love this wallpaper ✨
            </div>
          </div>
        </div>
      </div>

      {/* ── Tabs ── */}
      <div
        className="flex-shrink-0 flex"
        style={{ background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }}
      >
        {TABS.map(t => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className="flex-1 py-2.5 text-sm font-bold transition-colors border-b-2"
            style={{
              color: tab === t ? '#ff4d6d' : 'var(--color-text-secondary)',
              borderColor: tab === t ? '#ff4d6d' : 'transparent',
              background: 'transparent',
            }}
          >
            {t}
          </button>
        ))}
      </div>

      {/* ── Content ── */}
      <div className="flex-1 overflow-y-auto scrollbar-none px-4 py-4 space-y-5">

        {/* GRADIENTS TAB */}
        {tab === 'Gradients' && (
          <>
            <Section label="Default">
              <div className="grid grid-cols-3 gap-2.5">
                {GRADIENT_WALLPAPERS.filter(w => w.id === 'default').map(wp => (
                  <WallpaperThumb
                    key={wp.id} wp={wp}
                    selected={selId === wp.id && !selCustomUrl}
                    onClick={() => pickPreset(wp.id)}
                  />
                ))}
              </div>
            </Section>
            <Section label="Colour Gradients">
              <div className="grid grid-cols-3 gap-2.5">
                {GRADIENT_WALLPAPERS.filter(w => w.id !== 'default').map(wp => (
                  <WallpaperThumb
                    key={wp.id} wp={wp}
                    selected={selId === wp.id && !selCustomUrl}
                    onClick={() => pickPreset(wp.id)}
                  />
                ))}
              </div>
            </Section>
          </>
        )}

        {/* PHOTOS TAB */}
        {tab === 'Photos' && (
          <Section label="Nature & Scenic">
            <div className="grid grid-cols-3 gap-2.5">
              {IMAGE_WALLPAPERS.map(wp => (
                <WallpaperThumb
                  key={wp.id} wp={wp}
                  selected={selId === wp.id && !selCustomUrl}
                  onClick={() => pickPreset(wp.id)}
                />
              ))}
            </div>
          </Section>
        )}

        {/* MY PHOTO TAB */}
        {tab === 'My photo' && (
          <div className="space-y-4">
            {/* Upload button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex flex-col items-center justify-center gap-3 rounded-2xl active:scale-[0.98] transition-transform"
              style={{
                border: '2px dashed #ff4d6d',
                background: 'var(--color-primary-bg)',
                minHeight: 140,
              }}
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl"
                style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
              >
                📷
              </div>
              <div className="text-center">
                <p className="font-bold text-sm" style={{ color: '#ff4d6d' }}>Upload from Gallery</p>
                <p className="text-xs mt-0.5" style={{ color: 'var(--color-text-tertiary)' }}>JPG, PNG, WEBP supported</p>
              </div>
            </button>

            {/* Camera option */}
            <button
              type="button"
              onClick={() => {
                if (fileInputRef.current) {
                  fileInputRef.current.setAttribute('capture', 'environment')
                  fileInputRef.current.click()
                }
              }}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl active:scale-[0.98] transition-all"
              style={{ background: 'var(--color-card-bg)', border: '1px solid var(--color-card-border)' }}
            >
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background: 'var(--color-bg-tertiary)' }}>📸</div>
              <div className="flex-1 text-left">
                <p className="font-bold text-sm" style={{ color: 'var(--color-text)' }}>Take a Photo</p>
                <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>Use your camera</p>
              </div>
            </button>

            {/* Current custom photo preview */}
            {selCustomUrl && (
              <Section label="Selected Photo">
                <div className="grid grid-cols-3 gap-2.5">
                  <button
                    type="button"
                    className="relative rounded-2xl overflow-hidden active:scale-95 transition-all"
                    style={{
                      backgroundImage: `url("${selCustomUrl}")`,
                      backgroundSize: 'cover',
                      backgroundPosition: 'center',
                      aspectRatio: '9/16',
                      outline: '3px solid #ff4d6d',
                      outlineOffset: '2px',
                      boxShadow: '0 0 0 4px rgba(255,77,109,0.2)',
                    }}
                    onClick={() => {}} // already selected
                  >
                    <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-[#ff4d6d] flex items-center justify-center shadow">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"/>
                      </svg>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 px-1.5 py-1.5" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.6), transparent)' }}>
                      <p className="text-white text-[9px] font-bold text-center">My Photo</p>
                    </div>
                  </button>
                </div>
              </Section>
            )}
          </div>
        )}

        {/* Remove wallpaper */}
        {hasWallpaper && (
          <button
            type="button"
            onClick={handleClear}
            className="w-full py-3 rounded-2xl text-sm font-bold active:scale-[0.98] transition-transform"
            style={{ background: 'var(--color-bg-tertiary)', color: 'var(--color-text-secondary)', border: '1px solid var(--color-border)' }}
          >
            🗑️ Remove Wallpaper
          </button>
        )}

        <div className="h-4" />
      </div>

      {/* Hidden file input — programmatic click only (fixes mobile browser security) */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png,image/webp"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  )
}

function Section({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-[11px] font-bold uppercase tracking-wide mb-2.5" style={{ color: 'var(--color-text-tertiary)' }}>
        {label}
      </p>
      {children}
    </div>
  )
}
