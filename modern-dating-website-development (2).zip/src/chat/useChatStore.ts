import { useState, useCallback } from 'react'
import type { ChatMessage, MessageType, ReplyTo } from './types'

function makeId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36)
}

function nowStr() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function generateWaveform(n = 30): number[] {
  return Array.from({ length: n }, () => 0.2 + Math.random() * 0.8)
}

export function useChatStore(matchId: string) {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const seed: ChatMessage[] = []
    if (matchId === 'm1') {
      seed.push(
        { id: 'x1', senderId: matchId, type: 'text', text: 'Hey! How are you doing? 😊', status: 'seen', time: '2:04 PM', timestamp: Date.now() - 60000 * 60 },
        { id: 'x2', senderId: 'me', type: 'text', text: 'I\'m great, thanks! You look amazing btw 🔥', status: 'seen', time: '2:06 PM', timestamp: Date.now() - 60000 * 58 },
        { id: 'x3', senderId: matchId, type: 'text', text: 'Aww thank you 😍 Are you free this weekend?', status: 'seen', time: '2:08 PM', timestamp: Date.now() - 60000 * 55 },
      )
    } else if (matchId === 'm2') {
      seed.push(
        { id: 'y1', senderId: 'me', type: 'text', text: 'Hi! I loved your profile ✨', status: 'seen', time: 'Yesterday', timestamp: Date.now() - 86400000 },
        { id: 'y2', senderId: matchId, type: 'text', text: 'That sounds amazing! Let\'s meet up 🌸', status: 'seen', time: 'Yesterday', timestamp: Date.now() - 86400000 + 5000 },
        { id: 'y3', senderId: 'me', type: 'text', text: 'Yes! How about Saturday evening? 🌅', status: 'seen', time: 'Yesterday', timestamp: Date.now() - 86400000 + 10000 },
        { id: 'y4', senderId: matchId, type: 'text', text: 'Perfect! Can\'t wait 💕', status: 'sent', time: 'Yesterday', timestamp: Date.now() - 86400000 + 15000 },
      )
    } else if (matchId === 'm3') {
      seed.push(
        { id: 'z1', senderId: matchId, type: 'text', text: 'I love that place too! 🎨', status: 'seen', time: '3h ago', timestamp: Date.now() - 60000 * 180 },
        { id: 'z2', senderId: 'me', type: 'text', text: 'We should go together sometime 🙂', status: 'seen', time: '3h ago', timestamp: Date.now() - 60000 * 179 },
        { id: 'z3', senderId: matchId, type: 'text', text: 'Definitely!! Here\'s a pic I took there last week', status: 'seen', time: '3h ago', timestamp: Date.now() - 60000 * 178 },
        {
          id: 'z4', senderId: matchId, type: 'image',
          mediaUrl: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=600&h=400&fit=crop',
          status: 'seen', time: '3h ago', timestamp: Date.now() - 60000 * 177
        },
      )
    } else {
      seed.push(
        { id: 'w1', senderId: matchId, type: 'text', text: 'You seem really interesting 😍', status: 'seen', time: '1d ago', timestamp: Date.now() - 86400000 * 1.5 },
      )
    }
    return seed
  })

  const [isOtherTyping, setIsOtherTyping] = useState(false)

  const simulateTypingReply = useCallback((replyText: string, delay = 2000) => {
    setIsOtherTyping(true)
    setTimeout(() => {
      setIsOtherTyping(false)
      setMessages(prev => [
        ...prev,
        {
          id: makeId(),
          senderId: matchId,
          type: 'text',
          text: replyText,
          status: 'sent',
          time: nowStr(),
          timestamp: Date.now(),
        },
      ])
    }, delay)
  }, [matchId])

  const addMessage = useCallback((msg: ChatMessage) => {
    setMessages(prev => [...prev, msg])
  }, [])

  const updateMessage = useCallback((id: string, patch: Partial<ChatMessage>) => {
    setMessages(prev => prev.map(m => m.id === id ? { ...m, ...patch } : m))
  }, [])

  const deleteMessage = useCallback((id: string) => {
    setMessages(prev => prev.map(m => m.id === id ? { ...m, deleted: true } : m))
  }, [])

  const markSeen = useCallback(() => {
    setMessages(prev => prev.map(m =>
      m.senderId !== 'me' && m.status !== 'seen' ? { ...m, status: 'seen' } : m
    ))
  }, [])

  const sendText = useCallback((text: string, replyTo?: ReplyTo) => {
    const id = makeId()
    const msg: ChatMessage = {
      id,
      senderId: 'me',
      type: 'text',
      text,
      status: 'sending',
      time: nowStr(),
      timestamp: Date.now(),
      replyTo,
    }
    setMessages(prev => [...prev, msg])
    setTimeout(() => {
      setMessages(prev => prev.map(m => m.id === id ? { ...m, status: 'sent' } : m))
    }, 600)
    // Auto-reply simulation
    const replies = [
      '😊 That\'s so sweet!',
      'Haha totally agree 😂',
      '❤️ You\'re amazing!',
      'Tell me more!',
      'Can\'t stop smiling 😁',
      '🔥🔥🔥',
      'Miss you already ✨',
    ]
    simulateTypingReply(replies[Math.floor(Math.random() * replies.length)], 1500 + Math.random() * 2000)
    return id
  }, [simulateTypingReply])

  const sendMedia = useCallback(async (
    file: File,
    type: MessageType,
    replyTo?: ReplyTo,
    waveform?: number[],
    voiceDuration?: number,
  ) => {
    const id = makeId()
    const localUrl = URL.createObjectURL(file)
    const msg: ChatMessage = {
      id,
      senderId: 'me',
      type,
      mediaUrl: localUrl,
      mediaMimeType: file.type,
      mediaName: file.name,
      mediaSize: file.size,
      uploadProgress: 0,
      status: 'sending',
      time: nowStr(),
      timestamp: Date.now(),
      replyTo,
      waveform: waveform ?? (type === 'voice' ? generateWaveform() : undefined),
      voiceDuration,
    }
    setMessages(prev => [...prev, msg])

    // Simulate upload progress
    let progress = 0
    const interval = setInterval(() => {
      progress += Math.random() * 25
      if (progress >= 100) {
        progress = 100
        clearInterval(interval)
        setMessages(prev => prev.map(m =>
          m.id === id ? { ...m, uploadProgress: 100, status: 'sent' } : m
        ))
        const replies = ['Wow nice! 😍', '❤️', 'Love it!', 'So beautiful 🌸', '🔥🔥']
        simulateTypingReply(replies[Math.floor(Math.random() * replies.length)], 1800)
      } else {
        setMessages(prev => prev.map(m =>
          m.id === id ? { ...m, uploadProgress: Math.min(progress, 99) } : m
        ))
      }
    }, 300)

    return id
  }, [simulateTypingReply])

  return {
    messages,
    isOtherTyping,
    addMessage,
    updateMessage,
    deleteMessage,
    markSeen,
    sendText,
    sendMedia,
  }
}
