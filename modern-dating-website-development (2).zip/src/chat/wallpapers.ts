// ─── Preset Chat Wallpapers ──────────────────────────────────────────────────

export interface Wallpaper {
  id: string
  label: string
  type: 'gradient' | 'pattern' | 'image'
  // For gradient/pattern: CSS background string
  css?: string
  // For Unsplash images
  url?: string
  // Thumbnail (small, fast to load)
  thumb?: string
  // Whether text bubbles need light or dark foreground
  tone: 'light' | 'dark'
}

export const PRESET_WALLPAPERS: Wallpaper[] = [
  // ── Gradients ──────────────────────────────────────────────
  {
    id: 'default',
    label: 'Default',
    type: 'gradient',
    css: 'linear-gradient(160deg, #fce8ef 0%, #fce4ec 50%, #f8bbd0 100%)',
    tone: 'dark',
  },
  {
    id: 'rose-glow',
    label: 'Rose Glow',
    type: 'gradient',
    css: 'linear-gradient(160deg, #fce4ec 0%, #f8bbd0 40%, #fce4ec 100%)',
    tone: 'dark',
  },
  {
    id: 'sunset',
    label: 'Sunset',
    type: 'gradient',
    css: 'linear-gradient(160deg, #ff9a9e 0%, #fad0c4 50%, #ffecd2 100%)',
    tone: 'dark',
  },
  {
    id: 'ocean',
    label: 'Ocean',
    type: 'gradient',
    css: 'linear-gradient(160deg, #a1c4fd 0%, #c2e9fb 100%)',
    tone: 'dark',
  },
  {
    id: 'aurora',
    label: 'Aurora',
    type: 'gradient',
    css: 'linear-gradient(160deg, #0f0c29 0%, #302b63 50%, #24243e 100%)',
    tone: 'light',
  },
  {
    id: 'mint',
    label: 'Mint',
    type: 'gradient',
    css: 'linear-gradient(160deg, #d4fc79 0%, #96e6a1 100%)',
    tone: 'dark',
  },
  {
    id: 'peach',
    label: 'Peach',
    type: 'gradient',
    css: 'linear-gradient(160deg, #ffeaa7 0%, #fab1a0 100%)',
    tone: 'dark',
  },
  {
    id: 'midnight',
    label: 'Midnight',
    type: 'gradient',
    css: 'linear-gradient(160deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%)',
    tone: 'light',
  },
  {
    id: 'lavender',
    label: 'Lavender',
    type: 'gradient',
    css: 'linear-gradient(160deg, #e8d5f5 0%, #d4a8f0 50%, #e8d5f5 100%)',
    tone: 'dark',
  },
  {
    id: 'gold',
    label: 'Gold',
    type: 'gradient',
    css: 'linear-gradient(160deg, #f6d365 0%, #fda085 100%)',
    tone: 'dark',
  },
  {
    id: 'forest',
    label: 'Forest',
    type: 'gradient',
    css: 'linear-gradient(160deg, #134e5e 0%, #71b280 100%)',
    tone: 'light',
  },
  {
    id: 'bubblegum',
    label: 'Bubblegum',
    type: 'gradient',
    css: 'linear-gradient(160deg, #ff9ff3 0%, #ffeaa7 100%)',
    tone: 'dark',
  },

  // ── Pattern overlays ────────────────────────────────────────
  {
    id: 'hearts',
    label: 'Hearts',
    type: 'pattern',
    css: `radial-gradient(circle, #ff4d6d22 1px, transparent 1px),
          linear-gradient(160deg, #fff0f4 0%, #fce8ef 100%)`,
    tone: 'dark',
  },
  {
    id: 'dots',
    label: 'Dots',
    type: 'pattern',
    css: `radial-gradient(circle, #ff4d6d18 1px, transparent 1px),
          linear-gradient(160deg, #f5f0ff 0%, #ede7ff 100%)`,
    tone: 'dark',
  },
  {
    id: 'stars',
    label: 'Stars',
    type: 'pattern',
    css: `radial-gradient(ellipse at 20% 50%, #1a1a2e 0%, #0d0d18 100%)`,
    tone: 'light',
  },

  // ── Nature photos ──────────────────────────────────────────
  {
    id: 'flowers',
    label: 'Flowers',
    type: 'image',
    url: 'https://images.unsplash.com/photo-1490750967868-88df5691cc25?w=800&h=1400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1490750967868-88df5691cc25?w=120&h=200&fit=crop',
    tone: 'light',
  },
  {
    id: 'sunset-beach',
    label: 'Beach',
    type: 'image',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=1400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=120&h=200&fit=crop',
    tone: 'light',
  },
  {
    id: 'galaxy',
    label: 'Galaxy',
    type: 'image',
    url: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=800&h=1400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=120&h=200&fit=crop',
    tone: 'light',
  },
  {
    id: 'autumn',
    label: 'Autumn',
    type: 'image',
    url: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=800&h=1400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=120&h=200&fit=crop',
    tone: 'light',
  },
  {
    id: 'mountains',
    label: 'Mountains',
    type: 'image',
    url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=1400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=120&h=200&fit=crop',
    tone: 'light',
  },
  {
    id: 'cherry',
    label: 'Cherry',
    type: 'image',
    url: 'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=800&h=1400&fit=crop',
    thumb: 'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=120&h=200&fit=crop',
    tone: 'light',
  },
]

// ── Wallpaper storage (per match, in localStorage) ─────────────────────────
const STORAGE_KEY = 'sparkmatch-wallpapers'

function loadWallpapers(): Record<string, string> {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') } catch { return {} }
}

function saveWallpapers(map: Record<string, string>) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(map))
}

export function getWallpaperForMatch(matchId: string): string | null {
  return loadWallpapers()[matchId] || null
}

export function setWallpaperForMatch(matchId: string, wallpaperId: string) {
  const map = loadWallpapers()
  map[matchId] = wallpaperId
  saveWallpapers(map)
}

export function clearWallpaperForMatch(matchId: string) {
  const map = loadWallpapers()
  delete map[matchId]
  saveWallpapers(map)
}

// Resolve a wallpaper id → inline CSS background value
// Returns a string safe for inline style `background:` property
export function resolveWallpaperCss(
  wallpaperId: string | null,
  customUrl: string | null
): { backgroundCss: string; tone: 'light' | 'dark' } {
  // Custom uploaded photo
  if (customUrl) {
    return {
      backgroundCss: `url("${customUrl}") center/cover no-repeat`,
      tone: 'light',
    }
  }
  // No wallpaper or explicit default → use the CSS variable (fine for inline style `background`)
  if (!wallpaperId || wallpaperId === 'default' || wallpaperId === '__custom__') {
    return { backgroundCss: 'var(--chat-bg)', tone: 'dark' }
  }
  const preset = PRESET_WALLPAPERS.find(w => w.id === wallpaperId)
  if (!preset) return { backgroundCss: 'var(--chat-bg)', tone: 'dark' }

  // Photo preset
  if (preset.type === 'image' && preset.url) {
    return {
      backgroundCss: `url("${preset.url}") center/cover no-repeat`,
      tone: preset.tone,
    }
  }
  // Gradient / pattern preset — css field is a valid background shorthand value
  return {
    backgroundCss: preset.css || 'var(--chat-bg)',
    tone: preset.tone,
  }
}
