import { useState, useRef, useCallback } from 'react'
import { processFile, validateFile } from '../lib/mediaUpload'

interface Props {
  currentUrl: string
  name: string
  size?: number
  onUploaded: (url: string) => void
}

export default function AvatarUploader({ currentUrl, name, size = 80, onUploaded }: Props) {
  const [preview, setPreview] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)


  // Two separate inputs for gallery vs camera
  const galleryRef = useRef<HTMLInputElement>(null)
  const cameraRef  = useRef<HTMLInputElement>(null)

  const displayUrl = preview ?? currentUrl
  const circumference = 2 * Math.PI * 37
  const inputId = `avatar-input-${size}` // unique per instance

  const handleFile = useCallback(async (file: File) => {
    setError(null)
    const err = validateFile(file, 'avatar')
    if (err) { setError(err); return }

    const local = URL.createObjectURL(file)
    setPreview(local)
    setUploading(true)

    try {
      const result = await processFile(file, 'avatar', setProgress)
      onUploaded(result.remoteUrl)
    } catch {
      setError('Upload failed')
      setPreview(null)
    } finally {
      setUploading(false)
      setProgress(0)
    }
  }, [onUploaded])

  const badgeSize = Math.max(22, Math.round(size * 0.33))
  const iconSize  = Math.max(10, Math.round(size * 0.19))

  return (
    <div className="flex flex-col items-center gap-1">
      {/* Avatar circle */}
      <div className="relative" style={{ width: size, height: size }}>

        {/* Circular progress ring */}
        {uploading && (
          <svg
            className="absolute inset-0 -rotate-90 pointer-events-none"
            width={size} height={size} viewBox="0 0 80 80"
          >
            <circle cx="40" cy="40" r="37" fill="none" stroke="#fecdd3" strokeWidth="5" />
            <circle
              cx="40" cy="40" r="37"
              fill="none" stroke="#ff4d6d" strokeWidth="5"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={circumference * (1 - progress / 100)}
              style={{ transition: 'stroke-dashoffset 0.12s linear' }}
            />
          </svg>
        )}

        {/* Avatar photo */}
        <img
          src={displayUrl}
          alt={name}
          className="rounded-full object-cover border-4 border-white shadow-md"
          style={{ width: size, height: size, opacity: uploading ? 0.65 : 1 }}
        />

        {/* Camera badge — use <label> so tapping directly opens file picker on mobile */}
        {!uploading ? (
          <label
            htmlFor={inputId}
            className="absolute bottom-0 right-0 rounded-full flex items-center justify-center border-2 border-white shadow-lg cursor-pointer active:scale-90 transition-transform"
            style={{
              width: badgeSize,
              height: badgeSize,
              background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)',
            }}
            title="Change photo"
          >
            <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
              <circle cx="12" cy="13" r="4"/>
            </svg>
          </label>
        ) : (
          <div
            className="absolute bottom-0 right-0 rounded-full flex items-center justify-center border-2 border-white bg-gray-400"
            style={{ width: badgeSize, height: badgeSize }}
          >
            <div className="w-3 h-3 rounded-full border-2 border-white/40 border-t-white animate-spin" />
          </div>
        )}
      </div>

      {/* Progress % */}
      {uploading && (
        <span className="text-[11px] font-bold text-[#ff4d6d]">{Math.round(progress)}%</span>
      )}

      {/* Error */}
      {error && (
        <span className="text-[10px] text-red-500 text-center max-w-[100px] leading-tight">{error}</span>
      )}

      {/* Hidden gallery input — tied to label above */}
      <input
        id={inputId}
        ref={galleryRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png,image/webp"
        className="hidden"
        onChange={e => {
          const f = e.target.files?.[0]
          if (f) handleFile(f)
          e.target.value = ''
        }}
      />

      {/* Hidden camera input (used programmatically if needed) */}
      <input
        ref={cameraRef}
        type="file"
        accept="image/*"
        capture="user"
        className="hidden"
        onChange={e => {
          const f = e.target.files?.[0]
          if (f) handleFile(f)
          e.target.value = ''
        }}
      />
    </div>
  )
}
