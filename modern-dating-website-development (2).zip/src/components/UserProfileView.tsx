import { useState } from 'react'
import { usePrivacy } from '../privacy/PrivacyContext'
import { ReportFlow, BlockConfirmSheet } from '../privacy/PrivacySettings'
import { VipBadge } from '../vip/VipBadge'

export interface ViewableUser {
  id: string
  name: string
  avatar: string
  age?: number
  location?: string
  bio?: string
  gender?: string
  interests?: string[]
  isVip?: boolean
  isOnline?: boolean
  distance?: string
  images?: string[]
  coverUrl?: string
}

interface Props {
  user: ViewableUser
  onClose: () => void
  onMessage?: () => void
  onLike?: () => void
}

type MenuState = 'none' | 'report' | 'block'

// Fallback cover gradients when no cover photo exists
const COVER_GRADIENTS = [
  'from-rose-300 via-pink-400 to-fuchsia-500',
  'from-violet-400 via-purple-500 to-indigo-600',
  'from-amber-300 via-orange-400 to-rose-500',
  'from-emerald-400 via-teal-500 to-cyan-600',
  'from-blue-400 via-indigo-500 to-violet-600',
]

function pickGradient(name: string) {
  const idx = name.charCodeAt(0) % COVER_GRADIENTS.length
  return COVER_GRADIENTS[idx]
}

export default function UserProfileView({ user, onClose, onMessage, onLike }: Props) {
  const { blockUser, isBlocked, submitReport } = usePrivacy()
  const [menuState, setMenuState] = useState<MenuState>('none')
  const [liked, setLiked] = useState(false)
  const [activeImg, setActiveImg] = useState(0)

  const blocked = isBlocked(user.id)
  const privacyUser = { id: user.id, name: user.name, avatar: user.avatar }

  // Gallery: prefer images array, fall back to single avatar
  const gallery = user.images && user.images.length > 0 ? user.images : []

  // Fake stats derived from name hash (makes each profile feel unique)
  const hash = user.name.split('').reduce((a, c) => a + c.charCodeAt(0), 0)
  const stats = [
    { label: 'Matches', value: `${10 + (hash % 40)}` },
    { label: 'Likes',   value: `${20 + (hash % 80)}` },
    { label: 'Views',   value: `${(100 + hash % 900).toLocaleString()}` },
  ]

  return (
    <div className="absolute inset-0 z-[150] flex flex-col bg-white animate-slide-up overflow-hidden">

      {/* ─── Header bar (matches ProfilePage style) ─── */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 bg-white border-b border-gray-100 z-20">
        {/* Back */}
        <button
          onClick={onClose}
          className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform text-gray-500"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>

        {/* Name as title */}
        <span className="font-bold text-gray-900 text-base truncate max-w-[180px]">{user.name}</span>

        {/* More ⋯ */}
        <button
          onClick={() => setMenuState('block')}
          className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform text-gray-500"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>
          </svg>
        </button>
      </div>

      {/* ─── Scrollable body ─── */}
      <div className="flex-1 overflow-y-auto">

        {/* ── Cover photo ── */}
        <div
          className={`relative w-full bg-gradient-to-br ${pickGradient(user.name)} flex-shrink-0`}
          style={{ height: 160 }}
        >
          {user.coverUrl && (
            <img src={user.coverUrl} alt="cover" className="absolute inset-0 w-full h-full object-cover" />
          )}
          {/* Subtle scrim */}
          <div className="absolute inset-0 bg-black/10 pointer-events-none" />

          {/* Gallery mini-dots (top, if multiple photos) */}
          {gallery.length > 1 && (
            <div className="absolute top-3 left-0 right-0 flex justify-center gap-1.5 z-10">
              {gallery.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImg(i)}
                  className="rounded-full transition-all"
                  style={{
                    width: i === activeImg ? 18 : 6,
                    height: 4,
                    background: i === activeImg ? 'white' : 'rgba(255,255,255,0.5)',
                  }}
                />
              ))}
            </div>
          )}
        </div>

        {/* ── Avatar + name row (overlaps cover) ── */}
        <div className="flex items-end gap-4 px-4 -mt-11 mb-2 relative z-10">
          {/* Avatar */}
          <div className="relative flex-shrink-0">
            <div
              className="rounded-full p-0.5 border-4 border-white shadow-lg"
              style={{ background: user.isVip ? 'linear-gradient(135deg,#f59e0b,#fbbf24)' : 'white' }}
            >
              {gallery.length > 0 ? (
                <div className="relative">
                  <img
                    src={gallery[activeImg]}
                    alt={user.name}
                    className="w-20 h-20 rounded-full object-cover"
                  />
                  {/* Tap zones for gallery */}
                  {gallery.length > 1 && (
                    <div className="absolute inset-0 rounded-full flex">
                      <div className="w-1/2" onClick={() => setActiveImg(i => Math.max(0, i - 1))} />
                      <div className="w-1/2" onClick={() => setActiveImg(i => Math.min(gallery.length - 1, i + 1))} />
                    </div>
                  )}
                </div>
              ) : (
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-20 h-20 rounded-full object-cover"
                />
              )}
            </div>

            {/* Online dot */}
            {user.isOnline && (
              <div className="absolute bottom-1 right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white" />
            )}
          </div>

          {/* Name block */}
          <div className="flex-1 min-w-0 pb-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-black text-gray-900 leading-tight truncate">{user.name}</h2>
              {user.age && <span className="text-gray-500 font-medium">{user.age}</span>}
              {user.isVip && <VipBadge size="sm" animated />}
            </div>
            {user.location && (
              <p className="text-sm text-gray-500 mt-0.5">📍 {user.location}{user.distance ? ` · ${user.distance}` : ''}</p>
            )}
            {user.gender && (
              <p className="text-sm text-gray-500">
                {user.gender === 'Male' ? '👨' : user.gender === 'Female' ? '👩' : '🧑'} {user.gender}
              </p>
            )}
          </div>
        </div>

        <div className="px-4 pb-6 space-y-4">

          {/* ── Stats row ── */}
          <div className="grid grid-cols-3 gap-3">
            {stats.map(stat => (
              <div key={stat.label} className="bg-rose-50 rounded-2xl p-3 text-center">
                <p className="text-xl font-bold text-[#ff4d6d]">{stat.value}</p>
                <p className="text-xs text-gray-500 mt-0.5">{stat.label}</p>
              </div>
            ))}
          </div>

          {/* ── About Me ── */}
          {user.bio && (
            <div className="bg-gray-50 rounded-2xl p-4">
              <h3 className="font-bold text-gray-800 text-sm mb-2">About Me</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{user.bio}</p>
            </div>
          )}

          {/* ── Interests ── */}
          {user.interests && user.interests.length > 0 && (
            <div>
              <h3 className="font-bold text-gray-800 text-sm mb-3">Interests</h3>
              <div className="flex flex-wrap gap-2">
                {user.interests.map(i => (
                  <span key={i} className="px-3 py-1.5 bg-rose-50 text-[#ff4d6d] text-xs font-medium rounded-full border border-rose-100">
                    {i}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* ── Photo gallery strip (if multiple) ── */}
          {gallery.length > 1 && (
            <div>
              <h3 className="font-bold text-gray-800 text-sm mb-3">Photos</h3>
              <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
                {gallery.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImg(i)}
                    className={`flex-shrink-0 rounded-2xl overflow-hidden border-2 transition-all ${
                      i === activeImg ? 'border-[#ff4d6d] shadow-md' : 'border-transparent'
                    }`}
                    style={{ width: 100, height: 130 }}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ── Online status ── */}
          {user.isOnline && (
            <div className="flex items-center gap-2 bg-green-50 border border-green-100 rounded-2xl px-4 py-2.5">
              <div className="w-2.5 h-2.5 rounded-full bg-green-400 animate-pulse" />
              <p className="text-sm font-semibold text-green-700">Active now</p>
            </div>
          )}

          {/* ── Safety notice ── */}
          <div className="bg-gray-50 rounded-2xl p-3 flex items-center gap-2.5">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <p className="text-xs text-gray-500">Always meet in public for first dates. Stay safe 💚</p>
          </div>

          {/* ── Report link ── */}
          <div className="flex justify-center pt-1">
            <button
              onClick={() => setMenuState('report')}
              className="text-xs text-gray-400 hover:text-red-400 transition-colors underline underline-offset-2"
            >
              🚩 Report {user.name}
            </button>
          </div>
        </div>
      </div>

      {/* ─── Pinned action bar ─── */}
      <div className="flex-shrink-0 bg-white border-t border-gray-100 px-4 py-4 safe-bottom">
        <div className="flex items-center gap-3">

          {/* Like button */}
          <button
            onClick={() => { setLiked(v => !v); onLike?.() }}
            className={`w-13 h-13 w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 border-2 transition-all active:scale-90 ${
              liked
                ? 'bg-[#ff4d6d] border-[#ff4d6d] shadow-lg shadow-rose-200'
                : 'border-gray-200 bg-white hover:border-rose-200'
            }`}
          >
            <svg width="20" height="18" viewBox="0 0 24 22"
              fill={liked ? 'white' : 'none'}
              stroke={liked ? 'none' : '#ff4d6d'}
              strokeWidth="1.8"
              style={{ transition: 'all 0.18s ease', transform: liked ? 'scale(1.15)' : 'scale(1)' }}
            >
              <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
            </svg>
          </button>

          {/* Message CTA */}
          <button
            onClick={() => { onClose(); onMessage?.() }}
            disabled={blocked}
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl text-white font-bold text-sm active:scale-[0.98] transition-transform disabled:opacity-40 shadow-lg shadow-rose-200"
            style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            {blocked ? 'Blocked' : `Message ${user.name.split(' ')[0]}`}
          </button>

          {/* Block button */}
          <button
            onClick={() => setMenuState('block')}
            className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 border-2 transition-all active:scale-90 ${
              blocked ? 'bg-red-50 border-red-300' : 'border-gray-200 bg-white hover:border-red-200'
            }`}
            title={blocked ? 'Unblock' : 'Block user'}
          >
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke={blocked ? '#ef4444' : '#9ca3af'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"/>
              <line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>
            </svg>
          </button>
        </div>
      </div>

      {/* ─── Block sheet ─── */}
      {menuState === 'block' && (
        <BlockConfirmSheet
          user={privacyUser}
          onBlock={() => { blockUser(privacyUser); setMenuState('none') }}
          onClose={() => setMenuState('none')}
        />
      )}

      {/* ─── Report flow ─── */}
      {menuState === 'report' && (
        <ReportFlow
          user={privacyUser}
          onSubmit={(reason, detail) => { submitReport(privacyUser, reason, detail); setMenuState('none') }}
          onClose={() => setMenuState('none')}
        />
      )}
    </div>
  )
}
