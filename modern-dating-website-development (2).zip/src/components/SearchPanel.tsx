import { useState, useRef, useEffect } from 'react'
import { searchPeople, posts, type SearchPerson } from '../data/mockData'

interface Props {
  onClose: () => void
}

const RECENT_SEARCHES = ['Chisom', 'Lagos singles', 'Fatima', 'photographers']
const TRENDING = ['#Lagos 🌴', '#AbujaDating 💕', '#ArtLovers 🎨', '#FitFam 💪', '#Foodies 🍕']

export default function SearchPanel({ onClose }: Props) {
  const [query, setQuery] = useState('')
  const [activeFilter, setActiveFilter] = useState<'people' | 'posts'>('people')
  const [recentSearches, setRecentSearches] = useState(RECENT_SEARCHES)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    // Auto-focus input when panel opens
    setTimeout(() => inputRef.current?.focus(), 80)
  }, [])

  const trimmed = query.trim().toLowerCase()

  const filteredPeople = trimmed
    ? searchPeople.filter(
        p =>
          p.name.toLowerCase().includes(trimmed) ||
          p.location.toLowerCase().includes(trimmed) ||
          p.mutualInterests?.some(i => i.toLowerCase().includes(trimmed))
      )
    : searchPeople

  const filteredPosts = trimmed
    ? posts.filter(
        p =>
          p.userName.toLowerCase().includes(trimmed) ||
          p.caption.toLowerCase().includes(trimmed)
      )
    : posts

  const handleSearch = (q: string) => {
    setQuery(q)
    if (q.trim() && !recentSearches.includes(q.trim())) {
      setRecentSearches(prev => [q.trim(), ...prev].slice(0, 6))
    }
  }

  const clearRecent = () => setRecentSearches([])
  const removeRecent = (s: string) => setRecentSearches(prev => prev.filter(r => r !== s))

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-white animate-slide-in-right">
      {/* ── Search bar ── */}
      <div className="flex-shrink-0 px-4 pt-4 pb-3 bg-white border-b border-gray-100">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-1.5 -ml-1.5 rounded-full hover:bg-gray-100 active:scale-90 transition-transform flex-shrink-0"
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>

          <div className="flex-1 flex items-center bg-gray-100 rounded-2xl px-4 py-2.5 gap-2">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2.5" strokeLinecap="round">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
            <input
              ref={inputRef}
              value={query}
              onChange={e => handleSearch(e.target.value)}
              placeholder="Search people, interests…"
              className="flex-1 bg-transparent text-sm outline-none text-gray-800 placeholder-gray-400"
            />
            {query && (
              <button onClick={() => setQuery('')} className="text-gray-400 active:scale-90 transition-transform">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                  <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
            )}
          </div>
        </div>

        {/* People / Posts filter — only show when searching */}
        {trimmed && (
          <div className="flex gap-2 mt-3">
            {(['people', 'posts'] as const).map(f => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-colors capitalize ${
                  activeFilter === f
                    ? 'text-white'
                    : 'bg-gray-100 text-gray-500'
                }`}
                style={activeFilter === f ? { background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' } : {}}
              >
                {f}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── Scrollable body ── */}
      <div className="flex-1 overflow-y-auto">
        {!trimmed ? (
          /* Empty state — show recents + trending */
          <div className="px-4 pt-4 space-y-6">
            {/* Recent searches */}
            {recentSearches.length > 0 && (
              <section>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-gray-800 text-sm">Recent</h3>
                  <button
                    onClick={clearRecent}
                    className="text-xs text-[#ff4d6d] font-semibold"
                  >
                    Clear all
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {recentSearches.map(s => (
                    <div
                      key={s}
                      className="flex items-center gap-2 px-3 py-2 bg-gray-100 rounded-2xl"
                    >
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round">
                        <polyline points="12 8 12 12 14 14"/><circle cx="12" cy="12" r="10"/>
                      </svg>
                      <button
                        className="text-sm text-gray-700"
                        onClick={() => handleSearch(s)}
                      >
                        {s}
                      </button>
                      <button
                        onClick={() => removeRecent(s)}
                        className="text-gray-400"
                      >
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Trending */}
            <section>
              <h3 className="font-bold text-gray-800 text-sm mb-3">🔥 Trending</h3>
              <div className="space-y-0 divide-y divide-gray-50">
                {TRENDING.map((t, i) => (
                  <button
                    key={t}
                    onClick={() => handleSearch(t)}
                    className="w-full flex items-center justify-between py-3 text-left hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 text-xs text-gray-400 font-bold text-center">{i + 1}</span>
                      <span className="text-sm font-semibold text-gray-800">{t}</span>
                    </div>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="9 18 15 12 9 6"/>
                    </svg>
                  </button>
                ))}
              </div>
            </section>

            {/* Suggested people */}
            <section>
              <h3 className="font-bold text-gray-800 text-sm mb-3">✨ Suggested for you</h3>
              <div className="space-y-1">
                {searchPeople.slice(0, 5).map(p => (
                  <PersonRow key={p.id} person={p} />
                ))}
              </div>
            </section>
          </div>
        ) : activeFilter === 'people' ? (
          /* People results */
          <div className="px-4 pt-3">
            {filteredPeople.length === 0 ? (
              <EmptySearch query={query} />
            ) : (
              <div className="space-y-1">
                <p className="text-xs text-gray-400 font-medium mb-3">{filteredPeople.length} result{filteredPeople.length !== 1 ? 's' : ''}</p>
                {filteredPeople.map(p => (
                  <PersonRow key={p.id} person={p} highlight={trimmed} />
                ))}
              </div>
            )}
          </div>
        ) : (
          /* Post results */
          <div className="px-4 pt-3">
            {filteredPosts.length === 0 ? (
              <EmptySearch query={query} />
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-gray-400 font-medium">{filteredPosts.length} result{filteredPosts.length !== 1 ? 's' : ''}</p>
                {filteredPosts.map(p => (
                  <div key={p.id} className="flex items-center gap-3 py-2 border-b border-gray-50">
                    <img
                      src={p.userAvatar}
                      alt={p.userName}
                      className="w-10 h-10 rounded-full object-cover flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-gray-900">{p.userName}</p>
                      <p className="text-sm text-gray-500 truncate">{p.caption}</p>
                      <p className="text-[11px] text-gray-400">{p.timeAgo} · ❤️ {p.likes}</p>
                    </div>
                    {p.image && (
                      <img
                        src={p.image}
                        alt=""
                        className="w-14 h-14 rounded-xl object-cover flex-shrink-0"
                      />
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

function PersonRow({ person, highlight }: { person: SearchPerson; highlight?: string }) {
  return (
    <div className="flex items-center gap-3 py-2.5 px-1 rounded-xl hover:bg-gray-50 active:bg-gray-100 transition-colors cursor-pointer">
      {/* Avatar */}
      <div className="relative flex-shrink-0">
        <img
          src={person.avatar}
          alt={person.name}
          className="w-12 h-12 rounded-full object-cover"
        />
        {person.isOnline && (
          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 rounded-full border-2 border-white" />
        )}
        {person.isVip && (
          <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 flex items-center justify-center text-[9px]">
            👑
          </div>
        )}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="font-bold text-sm text-gray-900">
            {highlight
              ? highlightText(person.name, highlight)
              : person.name}
          </span>
          <span className="text-gray-400 text-xs">·</span>
          <span className="text-gray-500 text-xs">{person.age}</span>
        </div>
        <p className="text-xs text-gray-400 truncate">
          📍 {person.location}
          {person.mutualInterests && person.mutualInterests.length > 0 && (
            <> · {person.mutualInterests.slice(0, 2).join(', ')}</>
          )}
        </p>
      </div>

      {/* Connect button */}
      <button
        className="flex-shrink-0 text-xs font-bold px-3 py-1.5 rounded-full border-2 border-[#ff4d6d] text-[#ff4d6d] hover:bg-rose-50 active:scale-90 transition-transform"
        onClick={e => e.stopPropagation()}
      >
        Connect
      </button>
    </div>
  )
}

function highlightText(text: string, query: string) {
  const idx = text.toLowerCase().indexOf(query.toLowerCase())
  if (idx === -1) return <>{text}</>
  return (
    <>
      {text.slice(0, idx)}
      <span className="text-[#ff4d6d]">{text.slice(idx, idx + query.length)}</span>
      {text.slice(idx + query.length)}
    </>
  )
}

function EmptySearch({ query }: { query: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="text-5xl mb-4">🔍</div>
      <h3 className="font-bold text-gray-800 mb-1">No results for "{query}"</h3>
      <p className="text-sm text-gray-400">Try a different name, location, or interest</p>
    </div>
  )
}
