import { useState, useCallback } from 'react'
import { processFile, validateFile } from '../lib/mediaUpload'

interface Props {
  currentUrl: string | null
  onUploaded: (url: string | null) => void
}

const PRESET_COVERS = [
  { url: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=800&h=400&fit=crop', label: 'Flowers' },
  { url: 'https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?w=800&h=400&fit=crop', label: 'Nature' },
  { url: 'https://images.unsplash.com/photo-1490750967868-88df5691cc25?w=800&h=400&fit=crop', label: 'Roses' },
  { url: 'https://images.unsplash.com/photo-1444927714506-8492d94b4e3d?w=800&h=400&fit=crop', label: 'Sunset' },
  { url: 'https://images.unsplash.com/photo-1531379410502-63bfe8cdaf6f?w=800&h=400&fit=crop', label: 'Purple' },
  { url: 'https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=800&h=400&fit=crop', label: 'City' },
  { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=400&fit=crop', label: 'Mountains' },
  { url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=400&fit=crop', label: 'Abstract' },
  { url: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=800&h=400&fit=crop', label: 'Ocean' },
]

export default function CoverUploader({ currentUrl, onUploaded }: Props) {
  const [preview, setPreview] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [showPresets, setShowPresets] = useState(false)

  const displayUrl = preview ?? currentUrl

  const handleFile = useCallback(async (file: File) => {
    setError(null)
    const err = validateFile(file, 'image')
    if (err) { setError(err); return }
    const local = URL.createObjectURL(file)
    setPreview(local)
    setUploading(true)
    try {
      const result = await processFile(file, 'image', setProgress)
      onUploaded(result.remoteUrl)
    } catch {
      setError('Upload failed. Try again.')
      setPreview(null)
    } finally {
      setUploading(false)
      setProgress(0)
    }
  }, [onUploaded])

  const pickPreset = (url: string) => {
    setPreview(url)
    onUploaded(url)
    setShowPresets(false)
  }

  return (
    /* Outer wrapper — position:relative so the preset panel can overlay absolutely */
    <div className="w-full relative">

      {/* ── Cover banner ── */}
      <div
        className="w-full overflow-hidden bg-gradient-to-br from-rose-300 via-pink-400 to-fuchsia-500"
        style={{ height: 160 }}
      >
        {/* Photo */}
        {displayUrl && (
          <img
            src={displayUrl}
            alt="Cover"
            className="w-full h-full object-cover"
            style={{ opacity: uploading ? 0.55 : 1 }}
          />
        )}
      </div>

      {/* Upload progress overlay — sits on top */}
      {uploading && (
        <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center z-20 pointer-events-none">
          <div className="w-10 h-10 rounded-full border-4 border-white/30 border-t-white animate-spin mb-2" />
          <span className="text-white text-sm font-bold">{Math.round(progress)}%</span>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/30">
            <div className="h-full bg-white transition-all duration-150" style={{ width: `${progress}%` }} />
          </div>
        </div>
      )}

      {/* Action buttons — absolutely over the cover, z-20 */}
      {!uploading && (
        <div className="absolute bottom-3 right-3 flex items-center gap-2 z-20">
          {/* Upload label — directly bound to file input */}
          <label
            htmlFor="cover-file-input"
            className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-black/55 backdrop-blur text-white text-xs font-bold cursor-pointer select-none active:scale-90 transition-transform"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
              <circle cx="12" cy="13" r="4"/>
            </svg>
            <span>{displayUrl ? 'Change' : 'Upload photo'}</span>
          </label>

          {/* Presets button — opens overlay panel */}
          <button
            type="button"
            onPointerDown={e => { e.preventDefault(); e.stopPropagation() }}
            onClick={e => { e.preventDefault(); e.stopPropagation(); setShowPresets(v => !v) }}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-full text-white text-xs font-bold active:scale-90 transition-all ${showPresets ? 'bg-[#ff4d6d]' : 'bg-black/55 backdrop-blur'}`}
          >
            <span>🎨</span>
            <span>Presets</span>
          </button>
        </div>
      )}

      {/* ── Hidden file input — always in DOM ── */}
      <input
        id="cover-file-input"
        type="file"
        accept="image/jpeg,image/jpg,image/png,image/webp"
        className="hidden"
        onChange={e => {
          const f = e.target.files?.[0]
          if (f) handleFile(f)
          e.target.value = ''
        }}
      />

      {/* ── Preset picker panel — slides up OVER the avatar row (z-30) ── */}
      {showPresets && (
        <>
          {/* Backdrop — tap to close */}
          <div
            className="fixed inset-0 z-[29]"
            onClick={() => setShowPresets(false)}
          />

          {/* Panel — absolute relative to this wrapper, starts at top of cover */}
          <div
            className="absolute top-0 left-0 right-0 z-30 bg-white shadow-2xl rounded-b-3xl"
            style={{ animation: 'slideDownPanel 0.22s cubic-bezier(0.34,1.2,0.64,1) forwards' }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 pt-4 pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <span className="text-xl">🎨</span>
                <div>
                  <p className="font-bold text-gray-900 text-sm">Choose Cover Photo</p>
                  <p className="text-xs text-gray-400">Tap a preset or upload your own</p>
                </div>
              </div>
              <button
                onClick={() => setShowPresets(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 active:scale-90 transition-transform"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth="2.5" strokeLinecap="round">
                  <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
            </div>

            {/* Upload from device option */}
            <div className="px-4 pt-3 pb-2">
              <label
                htmlFor="cover-file-input"
                className="w-full flex items-center gap-3 px-4 py-3 bg-rose-50 border-2 border-[#ff4d6d] rounded-2xl cursor-pointer active:scale-[0.98] transition-transform"
                onClick={() => setShowPresets(false)}
              >
                <div className="w-9 h-9 rounded-xl bg-[#ff4d6d] flex items-center justify-center flex-shrink-0">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                    <circle cx="12" cy="13" r="4"/>
                  </svg>
                </div>
                <div>
                  <p className="font-bold text-[#ff4d6d] text-sm">Upload from Device</p>
                  <p className="text-xs text-gray-400">Gallery or Camera</p>
                </div>
              </label>
            </div>

            {/* Divider */}
            <div className="flex items-center gap-3 px-4 py-1">
              <div className="flex-1 h-px bg-gray-100" />
              <span className="text-xs text-gray-400 font-medium">or pick a preset</span>
              <div className="flex-1 h-px bg-gray-100" />
            </div>

            {/* Preset grid */}
            <div className="grid grid-cols-3 gap-2 px-4 py-3">
              {PRESET_COVERS.map((p, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => pickPreset(p.url)}
                  className={`relative rounded-2xl overflow-hidden border-3 transition-all active:scale-95 ${
                    displayUrl === p.url
                      ? 'ring-3 ring-[#ff4d6d] shadow-lg shadow-rose-200'
                      : 'hover:ring-2 hover:ring-rose-300'
                  }`}
                  style={{ aspectRatio: '16/9', border: displayUrl === p.url ? '3px solid #ff4d6d' : '2px solid transparent' }}
                >
                  <img src={p.url} alt={p.label} className="w-full h-full object-cover" loading="lazy" />
                  {/* Label overlay */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent px-1.5 py-1">
                    <p className="text-white text-[9px] font-bold text-center">{p.label}</p>
                  </div>
                  {/* Selected checkmark */}
                  {displayUrl === p.url && (
                    <div className="absolute top-1 right-1 w-5 h-5 bg-[#ff4d6d] rounded-full flex items-center justify-center">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="20 6 9 17 4 12"/>
                      </svg>
                    </div>
                  )}
                </button>
              ))}
            </div>

            {/* Remove option */}
            {displayUrl && (
              <div className="px-4 pb-4">
                <button
                  type="button"
                  onClick={removeCover}
                  className="w-full py-3 rounded-2xl bg-gray-50 border border-gray-200 text-red-500 text-sm font-bold active:scale-[0.98] transition-transform hover:bg-red-50"
                >
                  🗑️ Remove cover photo
                </button>
              </div>
            )}
          </div>
        </>
      )}

      {/* Error */}
      {error && !showPresets && (
        <div className="flex items-center gap-2 px-4 py-2 bg-red-50 border-b border-red-100">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round">
            <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
          <span className="text-xs text-red-600 font-medium flex-1">{error}</span>
          <button onClick={() => setError(null)} className="text-red-400">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      )}
    </div>
  )

  function removeCover() {
    setPreview(null)
    onUploaded(null)
    setShowPresets(false)
  }
}
