import { useState, useRef, useEffect } from 'react'
import { useCall } from './CallContext'
import { formatDuration } from './callEngine'
import { NetworkQualityBadge, CallReactionOverlay, CALL_REACTIONS } from './CallUI'

export default function VideoCallScreen() {
  const {
    session, callDuration, reactions,
    endCall, toggleMute, toggleCamera, flipCamera, sendReaction,
  } = useCall()

  const localVideoRef  = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)
  const [showControls, setShowControls] = useState(true)
  const [showReactions, setShowReactions] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const { participant, state, isMuted, isCameraOff, isFrontCamera } = session
  const isConnected = state === 'connected'
  const isCalling   = state === 'calling'
  const isDeclined  = state === 'declined'
  const isEnded     = state === 'ended'

  // Attach local stream to video element
  useEffect(() => {
    if (localVideoRef.current && session.localStream) {
      localVideoRef.current.srcObject = session.localStream
    }
  }, [session.localStream])

  // Auto-hide controls after 4s of inactivity
  useEffect(() => {
    if (!isConnected) return
    const reset = () => {
      setShowControls(true)
      if (hideTimer.current) clearTimeout(hideTimer.current)
      hideTimer.current = setTimeout(() => setShowControls(false), 4000)
    }
    reset()
    document.addEventListener('pointerdown', reset)
    return () => {
      document.removeEventListener('pointerdown', reset)
      if (hideTimer.current) clearTimeout(hideTimer.current)
    }
  }, [isConnected])

  return (
    <div
      className="fixed inset-0 z-[500] bg-black overflow-hidden select-none"
      onClick={() => setShowControls(v => !v)}
    >
      {/* ── Remote video (full screen) ── */}
      {isConnected ? (
        <video
          ref={remoteVideoRef}
          autoPlay playsInline muted
          className="absolute inset-0 w-full h-full object-cover"
          // In production: srcObject = remote MediaStream
          // For demo: use a placeholder
          poster={participant.avatar}
        />
      ) : (
        /* Calling / waiting screen */
        <div
          className="absolute inset-0 flex flex-col items-center justify-center"
          style={{ background: 'linear-gradient(160deg,#1a1a2e,#16213e,#0f3460)' }}
        >
          {/* Pulse rings */}
          {isCalling && (
            <>
              <div className="absolute w-56 h-56 rounded-full border border-white/10 animate-ping" style={{ animationDuration: '1.5s' }} />
              <div className="absolute w-72 h-72 rounded-full border border-white/6 animate-ping" style={{ animationDuration: '2s' }} />
            </>
          )}
          <div className="relative" style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)', borderRadius: '50%', padding: 3 }}>
            <img src={participant.avatar} alt={participant.name} className="w-36 h-36 rounded-full object-cover border-4 border-[#1a1a2e]" />
          </div>
          <h2 className="text-white font-black text-3xl mt-6">{participant.name}</h2>
          <p className="text-white/60 text-lg mt-2">
            {isCalling ? 'Video calling…' : isDeclined ? 'Call declined' : isEnded ? 'Call ended' : ''}
          </p>
        </div>
      )}

      {/* ── Floating reactions ── */}
      <CallReactionOverlay reactions={reactions} />

      {/* ── LOCAL (self) video — picture-in-picture ── */}
      {isConnected && (
        <div
          className={`absolute rounded-2xl overflow-hidden shadow-2xl border-2 border-white/20 transition-all ${
            isFullscreen ? 'inset-0 rounded-none border-0' : 'top-16 right-3 w-28 h-40'
          }`}
          style={{ zIndex: 20 }}
        >
          {!isCameraOff ? (
            <video
              ref={localVideoRef}
              autoPlay playsInline muted
              className="w-full h-full object-cover"
              style={{ transform: isFrontCamera ? 'scaleX(-1)' : 'none' }}
            />
          ) : (
            <div className="w-full h-full bg-gray-900 flex items-center justify-center">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="1" y1="1" x2="23" y2="23"/>
                <path d="M21 21H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3m3-3h6l2 3h4a2 2 0 0 1 2 2v9.34m-7.72-2.06A4 4 0 1 1 7.29 8.94"/>
              </svg>
            </div>
          )}

          {/* Expand button */}
          {!isFullscreen && (
            <button
              onClick={e => { e.stopPropagation(); setIsFullscreen(true) }}
              className="absolute top-1 right-1 w-5 h-5 bg-black/50 rounded-full flex items-center justify-center"
            >
              <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                <polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/>
                <line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/>
              </svg>
            </button>
          )}

          {/* Collapse fullscreen */}
          {isFullscreen && (
            <button
              onClick={e => { e.stopPropagation(); setIsFullscreen(false) }}
              className="absolute top-3 right-3 w-9 h-9 bg-black/50 rounded-full flex items-center justify-center"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                <polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/>
                <line x1="10" y1="14" x2="3" y2="21"/><line x1="21" y1="3" x2="14" y2="10"/>
              </svg>
            </button>
          )}
        </div>
      )}

      {/* ── Top overlay (name + quality + timer) ── */}
      <div
        className="absolute top-0 left-0 right-0 px-4 pt-12 pb-6 transition-opacity duration-300"
        style={{
          background: 'linear-gradient(to bottom, rgba(0,0,0,0.7), transparent)',
          opacity: showControls ? 1 : 0,
          zIndex: 15,
        }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-white font-black text-lg">{participant.name}</h3>
            <p className="text-white/70 text-sm">
              {isConnected ? formatDuration(callDuration) : isCalling ? 'Video calling…' : ''}
            </p>
          </div>
          <NetworkQualityBadge quality={session.networkQuality} />
        </div>
      </div>

      {/* ── Bottom controls ── */}
      {!isFullscreen && (
        <div
          className="absolute bottom-0 left-0 right-0 px-6 pb-12 pt-8 transition-opacity duration-300"
          style={{
            background: 'linear-gradient(to top, rgba(0,0,0,0.85), transparent)',
            opacity: showControls ? 1 : 0,
            zIndex: 15,
          }}
        >
          {/* Reactions row */}
          {isConnected && (
            <div className="flex items-center justify-center mb-5">
              {showReactions ? (
                <div className="flex gap-3 bg-white/10 backdrop-blur rounded-full px-4 py-2">
                  {CALL_REACTIONS.map((r: string) => (
                    <button key={r} onClick={e => { e.stopPropagation(); sendReaction(r); setShowReactions(false) }} className="text-2xl active:scale-75 transition-transform">{r}</button>
                  ))}
                  <button onClick={e => { e.stopPropagation(); setShowReactions(false) }} className="text-white/60 text-xl">✕</button>
                </div>
              ) : (
                <button
                  onClick={e => { e.stopPropagation(); setShowReactions(v => !v) }}
                  className="flex items-center gap-2 bg-white/10 backdrop-blur rounded-full px-4 py-2 text-white text-sm font-semibold"
                >
                  😊 React
                </button>
              )}
            </div>
          )}

          {/* Control grid */}
          <div className="flex items-center justify-around">
            {/* Mute */}
            <VideoBtn icon={isMuted ? '🔇' : '🎙️'} label={isMuted ? 'Unmute' : 'Mute'} active={isMuted} onClick={e => { e.stopPropagation(); toggleMute() }} />

            {/* Camera on/off */}
            <VideoBtn icon={isCameraOff ? '📵' : '📹'} label={isCameraOff ? 'Cam Off' : 'Cam On'} active={isCameraOff} onClick={e => { e.stopPropagation(); toggleCamera() }} />

            {/* End call */}
            <button
              onClick={e => { e.stopPropagation(); endCall() }}
              className="w-16 h-16 rounded-full flex items-center justify-center active:scale-90 transition-transform shadow-xl"
              style={{ background: 'linear-gradient(135deg,#ef4444,#dc2626)', boxShadow: '0 0 25px rgba(239,68,68,0.5)' }}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
                <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02L6.6 10.8z"/>
              </svg>
            </button>

            {/* Flip camera */}
            <VideoBtn icon="🔄" label="Flip" onClick={e => { e.stopPropagation(); flipCamera() }} />

            {/* Placeholder: beauty filter */}
            <VideoBtn icon="✨" label="Effects" onClick={e => e.stopPropagation()} />
          </div>
        </div>
      )}
    </div>
  )
}

function VideoBtn({ icon, label, active, onClick }: { icon: string; label: string; active?: boolean; onClick: (e: React.MouseEvent) => void }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1.5 active:scale-90 transition-transform">
      <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl transition-colors ${active ? 'bg-white/30' : 'bg-white/10'}`}>
        {icon}
      </div>
      <span className="text-white/60 text-[10px] font-medium">{label}</span>
    </button>
  )
}
