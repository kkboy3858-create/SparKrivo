import type { NetworkQuality } from './callEngine'

// ─── Network quality badge ────────────────────────────────────────────────────
const QUALITY_CONFIG: Record<NetworkQuality, { label: string; color: string; bars: number; icon: string }> = {
  excellent: { label: 'Excellent',   color: '#22c55e', bars: 4, icon: '📶' },
  good:      { label: 'Good',        color: '#86efac', bars: 3, icon: '📶' },
  fair:      { label: 'Fair',        color: '#f59e0b', bars: 2, icon: '⚠️' },
  poor:      { label: 'Poor',        color: '#ef4444', bars: 1, icon: '⚠️' },
  none:      { label: 'No signal',   color: '#6b7280', bars: 0, icon: '❌' },
}

export function NetworkQualityBadge({ quality }: { quality: NetworkQuality }) {
  const cfg = QUALITY_CONFIG[quality]
  return (
    <div
      className="flex items-center gap-1.5 px-3 py-1 rounded-full"
      style={{ background: `${cfg.color}22`, border: `1px solid ${cfg.color}44` }}
    >
      {/* Signal bars */}
      <div className="flex items-end gap-[2px] h-4">
        {[1, 2, 3, 4].map(b => (
          <div
            key={b}
            className="w-1 rounded-sm transition-all"
            style={{
              height: b * 3 + 4,
              background: b <= cfg.bars ? cfg.color : `${cfg.color}33`,
            }}
          />
        ))}
      </div>
      <span className="text-xs font-bold" style={{ color: cfg.color }}>{cfg.label}</span>
    </div>
  )
}

// ─── Reaction emojis ─────────────────────────────────────────────────────────
export const CALL_REACTIONS = ['❤️', '😂', '😮', '👏', '🔥', '💕', '😍', '✌️']

export interface CallReactionItem {
  id: string
  emoji: string
  at: number
}

// ─── Floating reaction overlay ───────────────────────────────────────────────
export function CallReactionOverlay({ reactions }: { reactions: CallReactionItem[] }) {
  if (reactions.length === 0) return null
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
      {reactions.map(r => (
        <div
          key={r.id}
          className="absolute text-4xl"
          style={{
            left: `${20 + Math.random() * 60}%`,
            bottom: '100px',
            animation: 'floatUp 3s ease-out forwards',
          }}
        >
          {r.emoji}
        </div>
      ))}
    </div>
  )
}

// ─── Connecting / reconnecting overlay ────────────────────────────────────────
export function ReconnectingOverlay() {
  return (
    <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center z-20">
      <div className="w-12 h-12 rounded-full border-4 border-white/20 border-t-white animate-spin mb-4" />
      <p className="text-white font-bold text-lg">Reconnecting…</p>
      <p className="text-white/60 text-sm mt-1">Trying to restore connection</p>
    </div>
  )
}

// ─── End call overlay ────────────────────────────────────────────────────────
export function EndedOverlay({ reason }: { reason: string }) {
  return (
    <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center z-20">
      <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center text-3xl mb-4">📵</div>
      <p className="text-white font-bold text-xl">{reason}</p>
    </div>
  )
}
