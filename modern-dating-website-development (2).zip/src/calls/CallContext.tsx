import { createContext, useContext, type ReactNode } from 'react'
import { useCallStore } from './useCallStore'

type CallCtx = ReturnType<typeof useCallStore>
const Ctx = createContext<CallCtx | null>(null)

export function CallProvider({ children }: { children: ReactNode }) {
  const store = useCallStore()
  return <Ctx.Provider value={store}>{children}</Ctx.Provider>
}

export function useCall(): CallCtx {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useCall must be inside CallProvider')
  return ctx
}
