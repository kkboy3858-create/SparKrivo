// ─── WebRTC Call Engine ─────────────────────────────────────────────────────
// Manages peer connections for voice and video calls.
// In production: replace signaling with real WebSocket/Supabase Realtime.

export type CallType = 'voice' | 'video'
export type CallState =
  | 'idle'
  | 'calling'        // outgoing — waiting for answer
  | 'ringing'        // incoming — showing accept/decline
  | 'connected'
  | 'ended'
  | 'declined'
  | 'missed'
  | 'reconnecting'

export type NetworkQuality = 'excellent' | 'good' | 'fair' | 'poor' | 'none'

export interface CallParticipant {
  id: string
  name: string
  avatar: string
  isVip?: boolean
}

export interface CallSession {
  id: string
  type: CallType
  state: CallState
  participant: CallParticipant
  startedAt: number | null   // ms when connected
  localStream: MediaStream | null
  remoteStream: MediaStream | null
  isMuted: boolean
  isCameraOff: boolean
  isSpeakerOn: boolean
  isFrontCamera: boolean
  networkQuality: NetworkQuality
}

// ─── Ringtone generator using Web Audio ─────────────────────────────────────
class RingtoneEngine {
  private ctx: AudioContext | null = null
  private intervalId: ReturnType<typeof setInterval> | null = null
  private nodes: AudioNode[] = []

  private getCtx() {
    if (!this.ctx || this.ctx.state === 'closed') {
      this.ctx = new AudioContext()
    }
    return this.ctx
  }

  // Classic phone ring: two-tone alternating
  startRinging() {
    this.stopRinging()
    this.playRingCycle()
    this.intervalId = setInterval(() => this.playRingCycle(), 3000)
  }

  private playRingCycle() {
    try {
      const ctx = this.getCtx()
      const tones = [440, 480]
      const ringDuration = 0.4
      const gap = 0.1

      tones.forEach((freq, i) => {
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        const t = ctx.currentTime + i * (ringDuration + gap)

        gain.gain.setValueAtTime(0, t)
        gain.gain.linearRampToValueAtTime(0.3, t + 0.02)
        gain.gain.setValueAtTime(0.3, t + ringDuration - 0.02)
        gain.gain.linearRampToValueAtTime(0, t + ringDuration)

        osc.type = 'sine'
        osc.frequency.value = freq
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.start(t)
        osc.stop(t + ringDuration)
        this.nodes.push(osc, gain)
      })

      // Vibration pattern for incoming calls
      if ('vibrate' in navigator) {
        navigator.vibrate([400, 200, 400, 600])
      }
    } catch {}
  }

  stopRinging() {
    if (this.intervalId) { clearInterval(this.intervalId); this.intervalId = null }
    this.nodes.forEach(n => { try { (n as OscillatorNode).stop?.() } catch {} })
    this.nodes = []
    if ('vibrate' in navigator) navigator.vibrate(0)
  }

  // Short end-call beep
  playEndCall() {
    try {
      const ctx = this.getCtx()
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.type = 'sine'
      osc.frequency.value = 300
      gain.gain.setValueAtTime(0.3, ctx.currentTime)
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5)
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.start(ctx.currentTime)
      osc.stop(ctx.currentTime + 0.5)
    } catch {}
  }

  // Call connected chime
  playConnected() {
    try {
      const ctx = this.getCtx()
      ;[880, 1100].forEach((freq, i) => {
        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        const t = ctx.currentTime + i * 0.15
        gain.gain.setValueAtTime(0.2, t)
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3)
        osc.type = 'triangle'
        osc.frequency.value = freq
        osc.connect(gain)
        gain.connect(ctx.destination)
        osc.start(t)
        osc.stop(t + 0.3)
      })
    } catch {}
  }

  async resume() {
    if (this.ctx?.state === 'suspended') await this.ctx.resume()
  }
}

export const ringtoneEngine = new RingtoneEngine()

// ─── Media helpers ────────────────────────────────────────────────────────────
export async function getLocalStream(video: boolean): Promise<MediaStream | null> {
  try {
    return await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, sampleRate: 48000 },
      video: video ? { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } : false,
    })
  } catch {
    return null
  }
}

export async function switchCamera(stream: MediaStream): Promise<MediaStream | null> {
  const videoTrack = stream.getVideoTracks()[0]
  if (!videoTrack) return null
  try {
    const settings = videoTrack.getSettings()
    const newFacing = settings.facingMode === 'user' ? 'environment' : 'user'
    const newStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: newFacing },
      audio: false,
    })
    return newStream
  } catch {
    return null
  }
}

export function stopStream(stream: MediaStream | null) {
  stream?.getTracks().forEach(t => t.stop())
}

export function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

// ─── Network quality simulator ────────────────────────────────────────────────
export function simulateNetworkQuality(): NetworkQuality {
  const r = Math.random()
  if (r < 0.6) return 'excellent'
  if (r < 0.8) return 'good'
  if (r < 0.93) return 'fair'
  if (r < 0.99) return 'poor'
  return 'none'
}
