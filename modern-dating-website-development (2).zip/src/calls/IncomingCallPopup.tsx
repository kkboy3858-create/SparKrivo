import { useEffect, useState } from 'react'
import { useCall } from './CallContext'

export default function IncomingCallPopup() {
  const { incomingCall, acceptCall, declineCall } = useCall()
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    if (incomingCall) {
      requestAnimationFrame(() => setVisible(true))
    } else {
      setVisible(false)
    }
  }, [incomingCall])

  if (!incomingCall) return null

  const { participant, type } = incomingCall

  return (
    <div
      className="absolute inset-x-0 top-0 z-[600] px-3 pt-3"
      style={{
        transform: visible ? 'translateY(0)' : 'translateY(-100%)',
        transition: 'transform 0.4s cubic-bezier(0.34,1.3,0.64,1)',
      }}
    >
      <div
        className="rounded-2xl overflow-hidden shadow-2xl"
        style={{ background: 'linear-gradient(135deg,#1a1a2e,#16213e)', border: '1px solid rgba(255,255,255,0.1)' }}
      >
        {/* Top: caller info */}
        <div className="flex items-center gap-4 px-5 pt-5 pb-4">
          {/* Pulsing avatar */}
          <div className="relative">
            <div className="absolute inset-0 rounded-full animate-ping" style={{ background: type === 'video' ? 'rgba(99,102,241,0.3)' : 'rgba(255,77,109,0.3)' }} />
            <img
              src={participant.avatar}
              alt={participant.name}
              className="relative w-14 h-14 rounded-full object-cover border-3 border-white/20"
            />
            {/* Call type badge */}
            <div
              className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center text-xs"
              style={{ background: type === 'video' ? 'linear-gradient(135deg,#6366f1,#4f46e5)' : 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
            >
              {type === 'video' ? '🎥' : '📞'}
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <p className="text-white/60 text-xs font-medium mb-0.5">
              Incoming {type === 'video' ? 'Video' : 'Voice'} Call
            </p>
            <h3 className="text-white font-black text-lg truncate">{participant.name}</h3>
            {participant.isVip && (
              <span className="text-amber-300 text-[11px] font-bold">👑 VIP Member</span>
            )}
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-3 px-5 pb-5">
          {/* Decline */}
          <button
            onClick={declineCall}
            className="flex-1 flex flex-col items-center gap-2 active:scale-90 transition-transform"
          >
            <div
              className="w-14 h-14 rounded-full flex items-center justify-center shadow-lg"
              style={{ background: 'linear-gradient(135deg,#ef4444,#dc2626)', boxShadow: '0 0 20px rgba(239,68,68,0.4)' }}
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="white">
                <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02L6.6 10.8z"/>
              </svg>
            </div>
            <span className="text-white/60 text-xs font-semibold">Decline</span>
          </button>

          {/* Accept */}
          <button
            onClick={acceptCall}
            className="flex-1 flex flex-col items-center gap-2 active:scale-90 transition-transform"
          >
            <div
              className="w-14 h-14 rounded-full flex items-center justify-center shadow-lg"
              style={{
                background: type === 'video'
                  ? 'linear-gradient(135deg,#6366f1,#4f46e5)'
                  : 'linear-gradient(135deg,#22c55e,#16a34a)',
                boxShadow: type === 'video'
                  ? '0 0 20px rgba(99,102,241,0.5)'
                  : '0 0 20px rgba(34,197,94,0.5)',
              }}
            >
              {type === 'video' ? (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="23 7 16 12 23 17 23 7"/>
                  <rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
                </svg>
              ) : (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="white">
                  <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02L6.6 10.8z"/>
                </svg>
              )}
            </div>
            <span className="text-white/60 text-xs font-semibold">
              {type === 'video' ? 'Accept Video' : 'Accept'}
            </span>
          </button>
        </div>

        {/* Swipe hint */}
        <div className="pb-3 flex justify-center">
          <p className="text-white/30 text-[10px] font-medium">Tap to manage call</p>
        </div>
      </div>
    </div>
  )
}
