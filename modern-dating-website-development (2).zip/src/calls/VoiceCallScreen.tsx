import { useState } from 'react'
import { useCall } from './CallContext'
import { formatDuration } from './callEngine'
import { NetworkQualityBadge, CallReactionOverlay, CALL_REACTIONS } from './CallUI'

export default function VoiceCallScreen() {
  const { session, callDuration, reactions, endCall, toggleMute, toggleSpeaker, sendReaction } = useCall()
  const [showReactions, setShowReactions] = useState(false)
  const { participant, state, isMuted, isSpeakerOn } = session

  const isConnected = state === 'connected'
  const isCalling   = state === 'calling'
  const isDeclined  = state === 'declined'
  const isEnded     = state === 'ended'


  return (
    <div
      className="fixed inset-0 z-[500] flex flex-col items-center justify-between pb-12 pt-20 select-none"
      style={{ background: 'linear-gradient(160deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%)' }}
    >
      {/* ── Top: network quality + name ── */}
      <div className="flex flex-col items-center gap-3 w-full px-6">
        <div className="flex items-center gap-2">
          <NetworkQualityBadge quality={session.networkQuality} />
        </div>

        {/* Avatar with pulse ring */}
        <div className="relative mt-4">
          {/* Outer pulse rings — calling state */}
          {isCalling && (
            <>
              <div className="absolute inset-0 rounded-full border-2 border-white/20 animate-ping" style={{ transform: 'scale(1.4)' }} />
              <div className="absolute inset-0 rounded-full border-2 border-white/15 animate-ping" style={{ transform: 'scale(1.7)', animationDelay: '0.3s' }} />
              <div className="absolute inset-0 rounded-full border-2 border-white/10 animate-ping" style={{ transform: 'scale(2.0)', animationDelay: '0.6s' }} />
            </>
          )}

          {/* Avatar */}
          <div className="relative rounded-full p-1" style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}>
            <img
              src={participant.avatar}
              alt={participant.name}
              className="w-36 h-36 rounded-full object-cover border-4 border-[#1a1a2e]"
            />
          </div>

          {/* Audio wave indicator when connected */}
          {isConnected && (
            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 flex items-end gap-[3px]">
              {[4, 8, 12, 8, 4].map((h, i) => (
                <div
                  key={i}
                  className="w-1.5 rounded-full bg-green-400"
                  style={{
                    height: h,
                    animation: `waveBar 0.8s ease-in-out infinite`,
                    animationDelay: `${i * 0.12}s`,
                  }}
                />
              ))}
            </div>
          )}
        </div>

        {/* Name */}
        <h2 className="text-white font-black text-3xl mt-2 tracking-tight">{participant.name}</h2>

        {/* Status line */}
        <p className="text-white/60 text-base font-medium">
          {isCalling   ? 'Calling…'            :
           isConnected ? formatDuration(callDuration) :
           isDeclined  ? 'Call declined'        :
           isEnded     ? 'Call ended'           : ''}
        </p>

        {/* VIP badge */}
        {participant.isVip && (
          <div className="px-3 py-1 rounded-full bg-amber-400/20 border border-amber-400/30">
            <span className="text-amber-300 text-xs font-bold">👑 VIP Member</span>
          </div>
        )}
      </div>

      {/* ── Reactions floating ── */}
      <CallReactionOverlay reactions={reactions} />

      {/* ── Bottom controls ── */}
      <div className="w-full px-8 space-y-6">
        {/* Reaction strip */}
        {isConnected && (
          <div className="flex items-center justify-center gap-3">
            {showReactions ? (
              <div className="flex gap-3 bg-white/10 backdrop-blur rounded-full px-4 py-2">
                {CALL_REACTIONS.map((r: string) => (
                  <button
                    key={r}
                    onClick={() => { sendReaction(r); setShowReactions(false) }}
                    className="text-2xl active:scale-75 transition-transform"
                  >
                    {r}
                  </button>
                ))}
                <button onClick={() => setShowReactions(false)} className="text-white/60 text-xl">✕</button>
              </div>
            ) : (
              <button
                onClick={() => setShowReactions(true)}
                className="flex items-center gap-2 bg-white/10 backdrop-blur rounded-full px-4 py-2 text-white text-sm font-semibold"
              >
                😊 <span>React</span>
              </button>
            )}
          </div>
        )}

        {/* Main control row */}
        <div className="flex items-center justify-around">
          {/* Mute */}
          <CallBtn
            icon={isMuted ? '🔇' : '🎙️'}
            label={isMuted ? 'Unmute' : 'Mute'}
            active={isMuted}
            onClick={toggleMute}
          />

          {/* End call — center, big red */}
          <button
            onClick={endCall}
            className="w-20 h-20 rounded-full flex items-center justify-center shadow-2xl active:scale-90 transition-all"
            style={{ background: 'linear-gradient(135deg,#ef4444,#dc2626)', boxShadow: '0 0 30px rgba(239,68,68,0.6)' }}
          >
            <svg width="28" height="28" viewBox="0 0 24 24" fill="white">
              <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02L6.6 10.8z"/>
            </svg>
          </button>

          {/* Speaker */}
          <CallBtn
            icon={isSpeakerOn ? '🔊' : '🔈'}
            label={isSpeakerOn ? 'Speaker' : 'Earpiece'}
            active={isSpeakerOn}
            onClick={toggleSpeaker}
          />
        </div>
      </div>
    </div>
  )
}

function CallBtn({ icon, label, active, onClick }: { icon: string; label: string; active?: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-2 active:scale-90 transition-transform"
    >
      <div className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl transition-colors ${active ? 'bg-white/30' : 'bg-white/10'}`}>
        {icon}
      </div>
      <span className="text-white/60 text-xs font-medium">{label}</span>
    </button>
  )
}
