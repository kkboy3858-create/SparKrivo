import { Component, type ReactNode } from 'react'

interface Props { children: ReactNode }
interface State { hasError: boolean; error: string }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, error: '' }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error: error?.message || 'Unknown error' }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: '100vh', display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center', padding: 24,
          background: '#fff0f4', fontFamily: 'system-ui, sans-serif',
        }}>
          <div style={{ fontSize: 56, marginBottom: 16 }}>💕</div>
          <h1 style={{ fontSize: 24, fontWeight: 900, color: '#ff4d6d', margin: '0 0 8px' }}>
            SparkMatch
          </h1>
          <p style={{ color: '#374151', fontWeight: 700, marginBottom: 8 }}>
            Something went wrong
          </p>
          <p style={{ color: '#9ca3af', fontSize: 12, marginBottom: 24, textAlign: 'center' }}>
            {this.state.error}
          </p>
          <button
            onClick={() => { this.setState({ hasError: false, error: '' }); window.location.reload() }}
            style={{
              padding: '12px 32px', borderRadius: 16, border: 'none',
              background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)',
              color: '#fff', fontWeight: 800, fontSize: 15, cursor: 'pointer',
            }}
          >
            Reload App
          </button>
        </div>
      )
    }
    return this.props.children
  }
}
