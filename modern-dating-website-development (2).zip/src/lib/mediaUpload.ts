// ─── Shared Media Upload Utility ───────────────────────────────────────────
// Handles file validation, compression preview, and simulated upload progress.
// Replace simulateUpload() with real Supabase Storage calls when backend is ready.

export type MediaType = 'image' | 'video' | 'avatar'

export interface UploadResult {
  localUrl: string    // blob URL for immediate preview
  remoteUrl: string   // final URL after upload
  mimeType: string
  sizeMB: number
  width?: number
  height?: number
}

const ACCEPTED: Record<MediaType, string> = {
  image:  'image/jpeg,image/jpg,image/png,image/webp,image/gif',
  video:  'video/mp4,video/mov,video/quicktime,video/webm',
  avatar: 'image/jpeg,image/jpg,image/png,image/webp',
}

const MAX_SIZE_MB: Record<MediaType, number> = {
  image:  10,
  video:  100,
  avatar: 5,
}

export function getAcceptString(types: MediaType[]): string {
  return types.map(t => ACCEPTED[t]).join(',')
}

export function validateFile(file: File, type: MediaType): string | null {
  const accepted = ACCEPTED[type].split(',')
  if (!accepted.includes(file.type)) {
    return `File type not supported. Accepted: ${accepted.join(', ')}`
  }
  const sizeMB = file.size / 1024 / 1024
  if (sizeMB > MAX_SIZE_MB[type]) {
    return `File too large. Max size: ${MAX_SIZE_MB[type]}MB`
  }
  return null
}

export function getImageDimensions(url: string): Promise<{ width: number; height: number }> {
  return new Promise(resolve => {
    const img = new Image()
    img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight })
    img.onerror = () => resolve({ width: 0, height: 0 })
    img.src = url
  })
}

// Simulate upload with progress callback — replace body with real Supabase upload
export async function simulateUpload(
  file: File,
  onProgress: (pct: number) => void
): Promise<string> {
  return new Promise(resolve => {
    let progress = 0
    const speed = 8 + Math.random() * 14      // % per tick
    const interval = setInterval(() => {
      progress = Math.min(99, progress + speed)
      onProgress(Math.round(progress))
      if (progress >= 99) {
        clearInterval(interval)
        setTimeout(() => {
          onProgress(100)
          // In production: return Supabase public URL
          // For now: return the blob URL as the "remote" URL
          resolve(URL.createObjectURL(file))
        }, 200)
      }
    }, 120)
  })
}

export async function processFile(
  file: File,
  _type: MediaType,
  onProgress: (pct: number) => void
): Promise<UploadResult> {
  const localUrl = URL.createObjectURL(file)
  const sizeMB = file.size / 1024 / 1024

  let width: number | undefined
  let height: number | undefined
  if (file.type.startsWith('image/')) {
    const dims = await getImageDimensions(localUrl)
    width = dims.width
    height = dims.height
  }

  const remoteUrl = await simulateUpload(file, onProgress)

  return { localUrl, remoteUrl, mimeType: file.type, sizeMB, width, height }
}
