// ─── Payment Sandbox / Test Mode ────────────────────────────────────────────
// Simulates Paystack, Flutterwave, Stripe, PayPal test environments

export type PaymentMode = 'sandbox' | 'live'
export type PaymentProvider = 'paystack' | 'flutterwave' | 'stripe' | 'paypal'

// ─── Test cards per provider ─────────────────────────────────────────────────
export const TEST_CARDS: Record<PaymentProvider, Array<{
  number: string
  expiry: string
  cvv: string
  pin?: string
  label: string
  outcome: 'success' | 'declined' | 'insufficient' | 'stolen'
  outcomeLabel: string
  icon: string
}>> = {
  paystack: [
    { number: '4084 0840 8408 4081', expiry: '01/99', cvv: '408', pin: '0000', label: 'Success — Visa (NGN)', outcome: 'success',      outcomeLabel: '✅ Payment approved', icon: '✅' },
    { number: '5060 6666 6666 6666', expiry: '01/99', cvv: '123', pin: '1234', label: 'Success — Verve',      outcome: 'success',      outcomeLabel: '✅ Payment approved', icon: '✅' },
    { number: '4084 0840 8408 4081', expiry: '01/21', cvv: '408', label: 'Declined — Expired',               outcome: 'declined',     outcomeLabel: '❌ Card declined',    icon: '❌' },
    { number: '4000 0000 0000 0002', expiry: '01/99', cvv: '123', label: 'Declined — Generic',               outcome: 'declined',     outcomeLabel: '❌ Card declined',    icon: '❌' },
    { number: '4000 0000 0000 9995', expiry: '01/99', cvv: '123', label: 'Insufficient Funds',               outcome: 'insufficient', outcomeLabel: '⚠️ Insufficient funds', icon: '⚠️' },
  ],
  flutterwave: [
    { number: '5531 8866 5214 2950', expiry: '09/32', cvv: '564', pin: '3310', label: 'Success — Mastercard', outcome: 'success',  outcomeLabel: '✅ Payment approved', icon: '✅' },
    { number: '4187 4274 1556 4246', expiry: '09/32', cvv: '828', pin: '3310', label: 'Success — Visa',       outcome: 'success',  outcomeLabel: '✅ Payment approved', icon: '✅' },
    { number: '5258 5859 2266 6581', expiry: '09/32', cvv: '883', pin: '3310', label: 'Declined',             outcome: 'declined', outcomeLabel: '❌ Card declined',    icon: '❌' },
  ],
  stripe: [
    { number: '4242 4242 4242 4242', expiry: '12/34', cvv: '424', label: 'Success — Visa',             outcome: 'success',      outcomeLabel: '✅ Payment approved',    icon: '✅' },
    { number: '5555 5555 5555 4444', expiry: '12/34', cvv: '424', label: 'Success — Mastercard',       outcome: 'success',      outcomeLabel: '✅ Payment approved',    icon: '✅' },
    { number: '4000 0000 0000 9995', expiry: '12/34', cvv: '424', label: 'Insufficient Funds',         outcome: 'insufficient', outcomeLabel: '⚠️ Insufficient funds', icon: '⚠️' },
    { number: '4000 0000 0000 0002', expiry: '12/34', cvv: '424', label: 'Card Declined',              outcome: 'declined',     outcomeLabel: '❌ Card declined',       icon: '❌' },
    { number: '4000 0000 0000 0069', expiry: '12/34', cvv: '424', label: 'Expired Card',               outcome: 'declined',     outcomeLabel: '❌ Expired card',        icon: '❌' },
    { number: '4000 0000 0000 0127', expiry: '12/34', cvv: '424', label: 'Incorrect CVC',              outcome: 'declined',     outcomeLabel: '❌ Incorrect CVC',       icon: '❌' },
  ],
  paypal: [
    { number: 'test-success@example.com', expiry: '', cvv: '', label: 'PayPal — Success',    outcome: 'success',  outcomeLabel: '✅ Payment approved', icon: '✅' },
    { number: 'test-decline@example.com', expiry: '', cvv: '', label: 'PayPal — Declined',   outcome: 'declined', outcomeLabel: '❌ Payment declined', icon: '❌' },
  ],
}

// ─── Simulate payment processing ─────────────────────────────────────────────
export interface PaymentResult {
  success: boolean
  transactionId: string
  reference: string
  amount: number
  currency: string
  provider: PaymentProvider
  mode: PaymentMode
  timestamp: number
  error?: string
  gatewayResponse?: string
}

export async function processPayment(opts: {
  provider: PaymentProvider
  mode: PaymentMode
  cardNumber?: string
  amount: number
  currency?: string
  email?: string
}): Promise<PaymentResult> {
  const { provider, mode, cardNumber, amount } = opts
  const currency = opts.currency || (provider === 'paystack' || provider === 'flutterwave' ? 'NGN' : 'USD')
  const txRef = `${provider.toUpperCase()}-${mode.toUpperCase()}-${Date.now()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`

  // Simulate network delay
  const delay = mode === 'sandbox' ? 1500 + Math.random() * 800 : 2500 + Math.random() * 1000
  await new Promise(r => setTimeout(r, delay))

  // Sandbox mode: determine outcome from card number
  if (mode === 'sandbox' && cardNumber) {
    const clean = cardNumber.replace(/\s/g, '')
    const testCard = TEST_CARDS[provider]?.find(c => c.number.replace(/\s/g, '') === clean || c.number === cardNumber)

    if (testCard) {
      if (testCard.outcome === 'success') {
        return {
          success: true,
          transactionId: txRef,
          reference: txRef,
          amount,
          currency,
          provider,
          mode,
          timestamp: Date.now(),
          gatewayResponse: testCard.outcomeLabel,
        }
      } else {
        const errors: Record<string, string> = {
          declined:     'Your card was declined. Please try a different payment method.',
          insufficient: 'Insufficient funds. Please use a card with sufficient balance.',
          stolen:       'This card has been flagged. Please contact your bank.',
        }
        return {
          success: false,
          transactionId: '',
          reference: txRef,
          amount,
          currency,
          provider,
          mode,
          timestamp: Date.now(),
          error: errors[testCard.outcome] || 'Payment failed.',
          gatewayResponse: testCard.outcomeLabel,
        }
      }
    }
  }

  // Live mode or unknown card: simulate 96% success
  if (Math.random() < 0.04) {
    return {
      success: false,
      transactionId: '',
      reference: txRef,
      amount,
      currency,
      provider,
      mode,
      timestamp: Date.now(),
      error: 'Payment was declined by your bank. Please try another method.',
    }
  }

  return {
    success: true,
    transactionId: txRef,
    reference: txRef,
    amount,
    currency,
    provider,
    mode,
    timestamp: Date.now(),
    gatewayResponse: 'Approved',
  }
}

// ─── Webhook event simulation ─────────────────────────────────────────────────
export type WebhookEvent =
  | 'charge.success'
  | 'subscription.create'
  | 'subscription.disable'
  | 'charge.failed'
  | 'refund.processed'

export function simulateWebhook(event: WebhookEvent, txRef: string): object {
  const base = { event, data: { reference: txRef, status: 'success' } }
  const events: Record<WebhookEvent, object> = {
    'charge.success':       { ...base, data: { ...base.data, gateway_response: 'Approved', channel: 'card' } },
    'subscription.create':  { ...base, event: 'subscription.create', data: { ...base.data, plan: 'VIP', next_payment_date: new Date(Date.now() + 30 * 86400000).toISOString() } },
    'subscription.disable': { ...base, event: 'subscription.disable', data: { ...base.data, reason: 'user_cancelled' } },
    'charge.failed':        { ...base, event: 'charge.failed', data: { ...base.data, status: 'failed', gateway_response: 'Declined' } },
    'refund.processed':     { ...base, event: 'refund.processed', data: { ...base.data, amount_refunded: 500, currency: 'NGN' } },
  }
  return events[event]
}
