import { createContext, useContext, type ReactNode } from 'react'
import { useVipStore } from './vipStore'

type VipCtx = ReturnType<typeof useVipStore>
const Ctx = createContext<VipCtx | null>(null)

export function VipProvider({ children }: { children: ReactNode }) {
  const store = useVipStore()
  return <Ctx.Provider value={store}>{children}</Ctx.Provider>
}

export function useVip(): VipCtx {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useVip must be inside VipProvider')
  return ctx
}
