

interface Props {
  size?: 'sm' | 'md' | 'lg'
  animated?: boolean
  label?: boolean
}

export function VipBadge({ size = 'md', animated = true, label = true }: Props) {
  const sizes = {
    sm: { badge: 'px-2 py-0.5 text-[9px] gap-1', crown: '10', glow: '8px' },
    md: { badge: 'px-3 py-1   text-[11px] gap-1.5', crown: '13', glow: '12px' },
    lg: { badge: 'px-4 py-1.5 text-[13px] gap-2',  crown: '16', glow: '18px' },
  }
  const s = sizes[size]

  return (
    <span
      className={`inline-flex items-center font-black rounded-full ${s.badge} ${animated ? 'vip-badge-glow' : ''}`}
      style={{
        background: 'linear-gradient(135deg,#f59e0b,#fbbf24,#fde68a,#f59e0b)',
        backgroundSize: '200% auto',
        animation: animated ? 'vip-shimmer 2.5s linear infinite' : undefined,
        boxShadow: animated ? `0 0 ${s.glow} rgba(245,158,11,0.7), 0 0 ${s.glow} rgba(251,191,36,0.5)` : undefined,
        color: '#7c2d12',
        letterSpacing: '0.03em',
      }}
    >
      <span style={{ fontSize: parseInt(s.crown) }}>👑</span>
      {label && <span>VIP</span>}
    </span>
  )
}

// Glowing avatar ring for VIP users
interface AvatarRingProps {
  src: string
  alt: string
  size?: number   // px
  className?: string
}

export function VipAvatar({ src, alt, size = 56, className = '' }: AvatarRingProps) {
  return (
    <div
      className={`relative flex-shrink-0 rounded-full p-[2.5px] ${className}`}
      style={{
        background: 'linear-gradient(135deg,#f59e0b,#fbbf24,#fde68a,#f59e0b)',
        backgroundSize: '200% auto',
        animation: 'vip-shimmer 2.5s linear infinite',
        boxShadow: '0 0 12px rgba(245,158,11,0.6), 0 0 24px rgba(251,191,36,0.3)',
      }}
    >
      <img
        src={src}
        alt={alt}
        style={{ width: size, height: size }}
        className="rounded-full object-cover block border-2 border-white"
      />
    </div>
  )
}

// Full-screen glow overlay used on profile when VIP
export function VipGlowOverlay() {
  return (
    <div
      className="absolute inset-0 pointer-events-none rounded-3xl"
      style={{
        background: 'linear-gradient(135deg,rgba(245,158,11,0.08) 0%,transparent 60%)',
        border: '2px solid rgba(245,158,11,0.25)',
        borderRadius: 'inherit',
      }}
    />
  )
}

// Countdown pill
export function VipCountdownPill({ daysLeft }: { daysLeft: number }) {
  const urgent = daysLeft <= 3
  return (
    <div
      className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold ${
        urgent ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-800'
      }`}
    >
      <span>{urgent ? '⚠️' : '⏳'}</span>
      <span>{daysLeft > 0 ? `${daysLeft} day${daysLeft !== 1 ? 's' : ''} left` : 'Expired today'}</span>
      {urgent && <span className="text-red-500">· Renew now</span>}
    </div>
  )
}

// Boost active pill
export function BoostActivePill({ minutesLeft }: { minutesLeft: number }) {
  return (
    <div
      className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold text-white"
      style={{ background: 'linear-gradient(135deg,#8b5cf6,#6d28d9)', boxShadow: '0 0 10px rgba(139,92,246,0.5)' }}
    >
      <span>🚀</span>
      <span>Boost active · {minutesLeft}m left</span>
    </div>
  )
}

// Small "Ad" pill for free users
export function AdPill() {
  return (
    <span className="px-1.5 py-0.5 bg-gray-200 text-gray-500 text-[9px] font-bold rounded uppercase tracking-wide">
      Ad
    </span>
  )
}
