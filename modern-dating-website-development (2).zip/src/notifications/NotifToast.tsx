import type { AppNotification } from '../data/mockData'

interface StackProps {
  toasts: AppNotification[]
  onDismiss: (id: string) => void
}

export function ToastStack({ toasts, onDismiss }: StackProps) {
  if (!toasts || toasts.length === 0) return null
  return (
    <div className="absolute top-0 left-0 right-0 z-[200] pt-2 flex flex-col gap-2 pointer-events-none">
      {toasts.slice(-2).map(t => (
        <div
          key={t.id}
          className="mx-3 pointer-events-auto"
          onClick={() => onDismiss(t.id)}
        >
          <div className="bg-white rounded-2xl shadow-xl border border-gray-100 px-4 py-3 flex items-center gap-3">
            {t.avatar ? (
              <img src={t.avatar} alt="" className="w-10 h-10 rounded-full object-cover flex-shrink-0" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center text-lg flex-shrink-0">🔔</div>
            )}
            <div className="flex-1 min-w-0">
              <p className="font-bold text-gray-900 text-sm truncate">{t.name}</p>
              <p className="text-gray-500 text-xs truncate">{t.text}</p>
            </div>
            <span className="text-gray-300 text-xs flex-shrink-0">now</span>
          </div>
        </div>
      ))}
    </div>
  )
}
