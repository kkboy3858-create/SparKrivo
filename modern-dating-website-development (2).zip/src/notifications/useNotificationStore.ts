import { useState, useCallback } from 'react'
import { notificationsData, type AppNotification } from '../data/mockData'

export interface BadgeCounts {
  feed: number
  matches: number
  likes: number
  discover: number
  profile: number
  total: number
}

export interface SoundSettings {
  enabled: boolean
  style: 'default' | 'soft' | 'loud' | 'silent'
  vibration: boolean
}

export function useNotificationStore(_activeTab: string) {
  const [notifications, setNotifications] = useState<AppNotification[]>(notificationsData)

  const unread = notificationsData.filter(n => !n.isRead).length
  const [badges] = useState<BadgeCounts>({
    feed: 2,
    matches: notificationsData.filter(n => !n.isRead && n.type === 'message').length,
    likes: notificationsData.filter(n => !n.isRead && (n.type === 'like' || n.type === 'superlike')).length,
    discover: 0,
    profile: 0,
    total: unread,
  })

  const [toastQueue] = useState<AppNotification[]>([])
  const [soundSettings] = useState<SoundSettings>({ enabled: false, style: 'default', vibration: false })
  const [pushPermission] = useState('default')

  const markAllRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })))
  }, [])

  const markRead = useCallback((id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n))
  }, [])

  const dismiss = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
  }, [])

  const dismissToast = useCallback((_id: string) => {}, [])
  const requestPushPermission = useCallback(async () => false, [])
  const updateSoundSettings = useCallback((_patch: Partial<SoundSettings>) => {}, [])

  return {
    notifications,
    badges,
    toastQueue,
    soundSettings,
    pushPermission,
    markAllRead,
    markRead,
    dismiss,
    dismissToast,
    requestPushPermission,
    updateSoundSettings,
  }
}
