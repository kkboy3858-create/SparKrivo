export type PushNotifPayload = {
  title: string
  body: string
  icon?: string
  badge?: string
  tag?: string
  data?: Record<string, string>
}

export const pushService = {
  init: async () => {},
  requestPermission: async (): Promise<boolean> => false,
  isGranted: () => false,
  isSupported: () => false,
  getPermission: () => 'default',
  show: async (_payload: PushNotifPayload) => {},
  showIfHidden: async (_payload: PushNotifPayload) => {},
}
