import type { SoundSettings } from './useNotificationStore'

interface Props {
  settings: SoundSettings
  pushPermission: string
  onUpdate: (patch: Partial<SoundSettings>) => void
  onRequestPush: () => Promise<boolean>
  onClose: () => void
}

export function SoundSettingsModal({ onClose }: Props) {
  return (
    <div className="absolute inset-0 z-[300] flex flex-col bg-white animate-slide-up">
      <div className="flex items-center gap-3 px-4 py-4 border-b border-gray-100">
        <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <h2 className="font-bold text-gray-900 text-lg">Notification Settings</h2>
      </div>
      <div className="flex-1 flex items-center justify-center px-8 text-center">
        <div>
          <div className="text-5xl mb-4">🔔</div>
          <p className="font-bold text-gray-800 mb-2">Sound Settings</p>
          <p className="text-sm text-gray-500">Notification sounds are managed by your device settings.</p>
        </div>
      </div>
    </div>
  )
}
