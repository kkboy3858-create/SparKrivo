export type SoundStyle = 'default' | 'soft' | 'loud' | 'silent'

export const soundEngine = {
  resume: () => {},
  playMessage: () => {},
  playMatch: () => {},
  playLike: () => {},
  playVoiceNote: () => {},
  playGeneral: () => {},
  setEnabled: (_v: boolean) => {},
  setStyle: (_s: SoundStyle) => {},
  setVibration: (_v: boolean) => {},
  isEnabled: () => true,
  getStyle: (): SoundStyle => 'default',
  isVibrationEnabled: () => true,
}
