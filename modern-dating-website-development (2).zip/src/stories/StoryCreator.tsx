import { useState, useRef, useCallback } from 'react'
import type { StorySlide, StorySlideType } from '../data/mockData'
import { processFile, validateFile, getAcceptString } from '../lib/mediaUpload'

interface Props {
  onPublish: (slide: StorySlide) => void
  onClose: () => void
}

const TEXT_GRADIENTS = [
  { id: 'g1', value: 'from-rose-400 via-pink-500 to-fuchsia-500',      preview: 'linear-gradient(135deg,#fb7185,#ec4899,#d946ef)' },
  { id: 'g2', value: 'from-orange-400 via-pink-500 to-rose-500',       preview: 'linear-gradient(135deg,#fb923c,#ec4899,#f43f5e)' },
  { id: 'g3', value: 'from-blue-500 via-indigo-600 to-purple-700',     preview: 'linear-gradient(135deg,#3b82f6,#4f46e5,#7e22ce)' },
  { id: 'g4', value: 'from-emerald-400 via-teal-500 to-cyan-600',      preview: 'linear-gradient(135deg,#34d399,#14b8a6,#0891b2)' },
  { id: 'g5', value: 'from-slate-800 via-gray-900 to-black',           preview: 'linear-gradient(135deg,#1e293b,#111827,#000)' },
  { id: 'g6', value: 'from-yellow-400 via-amber-500 to-orange-600',    preview: 'linear-gradient(135deg,#facc15,#f59e0b,#ea580c)' },
  { id: 'g7', value: 'from-violet-500 via-purple-600 to-indigo-700',   preview: 'linear-gradient(135deg,#8b5cf6,#9333ea,#4338ca)' },
  { id: 'g8', value: 'from-cyan-400 via-sky-500 to-blue-600',          preview: 'linear-gradient(135deg,#22d3ee,#0ea5e9,#2563eb)' },
]

const TEXT_COLORS = ['#ffffff', '#000000', '#ff4d6d', '#facc15', '#34d399', '#60a5fa', '#f97316', '#a78bfa']
const FONT_SIZES  = ['text-2xl', 'text-3xl', 'text-4xl']
const FONT_LABELS = ['S', 'M', 'L']

type Mode = 'choose' | 'text' | 'media'

export default function StoryCreator({ onPublish, onClose }: Props) {
  const [mode, setMode]         = useState<Mode>('choose')
  const [textContent, setTextContent] = useState('')
  const [textColor, setTextColor]     = useState('#ffffff')
  const [bgGradient, setBgGradient]   = useState(TEXT_GRADIENTS[0].value)
  const [fontSize, setFontSize]       = useState(FONT_SIZES[1])
  const [overlayText, setOverlayText] = useState('')
  const [mediaPreview, setMediaPreview] = useState<string | null>(null)
  const [mediaType, setMediaType]     = useState<'image' | 'video'>('image')
  const [uploading, setUploading]     = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [error, setError]             = useState<string | null>(null)
  const [fontIdx, setFontIdx]         = useState(1)

  const fileRef  = useRef<HTMLInputElement>(null)
  const textaRef = useRef<HTMLTextAreaElement>(null)

  /* ── Pick / drop file ───────────────────────────────── */
  const handleFile = useCallback(async (file: File) => {
    setError(null)
    const isVid = file.type.startsWith('video/')
    const mType = isVid ? 'video' : 'image'
    const err = validateFile(file, mType)
    if (err) { setError(err); return }

    const local = URL.createObjectURL(file)
    setMediaPreview(local)
    setMediaType(mType)
    setMode('media')
    setUploading(true)

    try {
      await processFile(file, mType, pct => setUploadProgress(pct))
    } catch {
      setError('Upload failed. Please try again.')
    } finally {
      setUploading(false)
      setUploadProgress(0)
    }
  }, [])

  const openPicker = (capture?: 'environment' | 'user', accept = getAcceptString(['image', 'video'])) => {
    const inp = fileRef.current!
    if (capture) inp.setAttribute('capture', capture)
    else inp.removeAttribute('capture')
    inp.setAttribute('accept', accept)
    inp.click()
  }

  /* ── Publish ────────────────────────────────────────── */
  const canPublish =
    (mode === 'text' && textContent.trim().length > 0) ||
    (mode === 'media' && mediaPreview !== null && !uploading)

  const publish = () => {
    if (!canPublish) return
    const slide: StorySlide = {
      id: `new-${Date.now()}`,
      type: (mode === 'text' ? 'text' : mediaType) as StorySlideType,
      duration: mode === 'text' ? 6000 : 7000,
      createdAt: Date.now(),
      ...(mode === 'text' ? {
        textContent: textContent.trim(),
        textColor,
        bgGradient,
      } : {
        mediaUrl: mediaPreview!,
        overlayText: overlayText.trim() || undefined,
        overlayTextColor: '#ffffff',
      }),
    }
    onPublish(slide)
  }

  /* ── Render ──────────────────────────────────────────── */
  return (
    <div className="absolute inset-0 z-[110] bg-black flex flex-col select-none">

      {/* ── Top bar ── */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 pt-5 pb-2 z-10">
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-white/10 backdrop-blur flex items-center justify-center active:scale-90 transition-transform"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>

        <h2 className="text-white font-bold text-sm tracking-wide">YOUR STORY</h2>

        {canPublish ? (
          <button
            onClick={publish}
            className="px-4 py-2 rounded-full text-white text-sm font-bold active:scale-95 transition-transform"
            style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
          >
            Share ✨
          </button>
        ) : (
          <div className="w-16" />
        )}
      </div>

      {/* ── Canvas ── */}
      <div className="flex-1 relative overflow-hidden mx-3 rounded-3xl mb-2">

        {/* CHOOSE mode */}
        {mode === 'choose' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 bg-gradient-to-br from-rose-500 via-pink-600 to-fuchsia-700">
            <div className="text-center mb-2">
              <div className="text-5xl mb-3">✨</div>
              <p className="text-white font-bold text-xl">Create your Story</p>
              <p className="text-white/60 text-sm mt-1">Share a moment with your matches</p>
            </div>

            <div className="flex flex-col gap-3 w-64">
              <ChoiceBtn emoji="📝" label="Text" sub="Write something expressive" onClick={() => { setMode('text'); setTimeout(() => textaRef.current?.focus(), 100) }} />
              <ChoiceBtn emoji="📷" label="Camera" sub="Take a photo or video now" onClick={() => openPicker('environment')} />
              <ChoiceBtn emoji="🖼️" label="Gallery" sub="Pick from your photos or videos" onClick={() => openPicker(undefined)} />
            </div>
          </div>
        )}

        {/* TEXT mode */}
        {mode === 'text' && (
          <div className={`absolute inset-0 bg-gradient-to-br ${bgGradient} flex flex-col items-center justify-center px-6`}>
            <textarea
              ref={textaRef}
              value={textContent}
              onChange={e => setTextContent(e.target.value)}
              placeholder="Type something..."
              maxLength={220}
              rows={5}
              autoFocus
              className={`w-full bg-transparent text-center font-black leading-tight outline-none resize-none placeholder-white/40 ${fontSize}`}
              style={{ color: textColor, textShadow: '0 2px 14px rgba(0,0,0,0.3)' }}
            />
          </div>
        )}

        {/* MEDIA mode */}
        {mode === 'media' && mediaPreview && (
          <div className="absolute inset-0 bg-black">
            {mediaType === 'video' ? (
              <video
                src={mediaPreview}
                className="w-full h-full object-contain"
                autoPlay muted playsInline loop
              />
            ) : (
              <img src={mediaPreview} alt="" className="w-full h-full object-cover" />
            )}
            {/* Bottom gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />

            {/* Upload progress overlay */}
            {uploading && (
              <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center gap-3">
                <div className="w-12 h-12 rounded-full border-4 border-white/20 border-t-white animate-spin" />
                <p className="text-white font-bold">{uploadProgress}%</p>
              </div>
            )}

            {/* Caption input */}
            {!uploading && (
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-center gap-2 bg-black/40 backdrop-blur-sm rounded-2xl px-4 py-3">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                  </svg>
                  <input
                    value={overlayText}
                    onChange={e => setOverlayText(e.target.value)}
                    placeholder="Add a caption…"
                    maxLength={120}
                    className="flex-1 bg-transparent text-white text-sm outline-none placeholder-white/50"
                  />
                </div>
              </div>
            )}

            {/* Change media button */}
            <button
              onClick={() => openPicker(undefined)}
              className="absolute top-3 left-3 flex items-center gap-1.5 bg-black/40 backdrop-blur rounded-full px-3 py-1.5"
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.49"/>
              </svg>
              <span className="text-white text-xs font-semibold">Change</span>
            </button>
          </div>
        )}

        {/* Error overlay */}
        {error && (
          <div className="absolute bottom-16 left-4 right-4 bg-red-500/90 backdrop-blur rounded-2xl px-4 py-3 flex items-center gap-2 z-10">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <p className="text-white text-xs font-semibold flex-1">{error}</p>
            <button onClick={() => setError(null)}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>
        )}
      </div>

      {/* ── Bottom toolbar ── */}
      <div className="flex-shrink-0 px-4 pb-7 space-y-3">

        {/* TEXT tools */}
        {mode === 'text' && (
          <>
            {/* Gradient swatches */}
            <div className="flex gap-2.5 overflow-x-auto scrollbar-none pb-1">
              {TEXT_GRADIENTS.map(g => (
                <button
                  key={g.id}
                  onClick={() => setBgGradient(g.value)}
                  className={`flex-shrink-0 w-9 h-9 rounded-full border-[3px] active:scale-90 transition-all ${bgGradient === g.value ? 'border-white scale-[1.15]' : 'border-transparent'}`}
                  style={{ background: g.preview }}
                />
              ))}
            </div>

            {/* Text color + font size row */}
            <div className="flex items-center gap-3">
              <span className="text-white/50 text-xs font-medium flex-shrink-0">Color</span>
              <div className="flex gap-2 flex-1 overflow-x-auto scrollbar-none">
                {TEXT_COLORS.map(c => (
                  <button
                    key={c}
                    onClick={() => setTextColor(c)}
                    className={`flex-shrink-0 w-7 h-7 rounded-full border-[2.5px] active:scale-90 transition-all ${textColor === c ? 'border-white scale-110' : 'border-white/30'}`}
                    style={{ background: c }}
                  />
                ))}
              </div>
              {/* Font size cycle */}
              <button
                onClick={() => { const n = (fontIdx + 1) % 3; setFontIdx(n); setFontSize(FONT_SIZES[n]) }}
                className="flex-shrink-0 w-8 h-8 rounded-full bg-white/15 flex items-center justify-center text-white font-black text-sm"
              >
                {FONT_LABELS[fontIdx]}
              </button>
            </div>
          </>
        )}

        {/* Bottom action row */}
        <div className="flex items-center gap-3">
          {mode !== 'choose' && (
            <button
              onClick={() => { setMode('choose'); setMediaPreview(null); setTextContent(''); setError(null) }}
              className="py-3 px-5 rounded-full bg-white/10 text-white text-sm font-semibold active:scale-95 transition-transform"
            >
              ← Back
            </button>
          )}

          {mode === 'choose' && (
            <>
              <button
                onClick={() => openPicker('environment')}
                className="flex-1 py-3 rounded-full bg-white/10 text-white text-sm font-semibold flex items-center justify-center gap-2 active:scale-95 transition-transform"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                  <circle cx="12" cy="13" r="4"/>
                </svg>
                Camera
              </button>
              <button
                onClick={() => setMode('text')}
                className="flex-1 py-3 rounded-full bg-white/10 text-white text-sm font-semibold flex items-center justify-center gap-2 active:scale-95 transition-transform"
              >
                Aa Text
              </button>
            </>
          )}
        </div>
      </div>

      <input
        ref={fileRef}
        type="file"
        className="hidden"
        onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); e.target.value = '' }}
      />
    </div>
  )
}

function ChoiceBtn({ emoji, label, sub, onClick }: { emoji: string; label: string; sub: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-4 px-5 py-4 bg-white/10 backdrop-blur rounded-2xl active:scale-95 transition-transform text-left"
    >
      <span className="text-2xl">{emoji}</span>
      <div>
        <p className="text-white font-bold text-sm">{label}</p>
        <p className="text-white/50 text-xs">{sub}</p>
      </div>
    </button>
  )
}
